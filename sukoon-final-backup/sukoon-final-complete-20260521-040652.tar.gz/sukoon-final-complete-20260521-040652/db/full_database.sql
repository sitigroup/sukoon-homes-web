/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.10-MariaDB, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: sql_admin_homes
-- ------------------------------------------------------
-- Server version	10.11.10-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ad_banners`
--

DROP TABLE IF EXISTS `ad_banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ad_banners` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `page` enum('homepage','property_listing','property_detail') NOT NULL,
  `platform` enum('app','web') NOT NULL,
  `placement` enum('below_categories','above_all_properties','above_facilities','above_similar_properties','below_slider','sidebar_below_filters','below_breadcrumb','sidebar_below_mortgage_loan_calculator','above_footer','above_breadcrumb') NOT NULL,
  `image` varchar(191) NOT NULL,
  `type` enum('external_link','property','banner_only') NOT NULL,
  `external_link_url` varchar(191) DEFAULT NULL,
  `property_id` bigint(20) unsigned DEFAULT NULL,
  `duration_days` int(11) NOT NULL DEFAULT 1,
  `starts_at` datetime DEFAULT NULL,
  `ends_at` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ad_banners_property_id_foreign` (`property_id`),
  CONSTRAINT `ad_banners_property_id_foreign` FOREIGN KEY (`property_id`) REFERENCES `propertys` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ad_banners`
--

LOCK TABLES `ad_banners` WRITE;
/*!40000 ALTER TABLE `ad_banners` DISABLE KEYS */;
/*!40000 ALTER TABLE `ad_banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `advertisements`
--

DROP TABLE IF EXISTS `advertisements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advertisements` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `for` enum('property','project') NOT NULL DEFAULT 'property' COMMENT 'Property or Project',
  `type` varchar(191) NOT NULL COMMENT 'Slider,HomeScreen,ProductListing',
  `slider_id` int(11) DEFAULT NULL,
  `title` varchar(191) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `property_id` int(11) DEFAULT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `package_id` int(11) DEFAULT NULL,
  `is_enable` tinyint(1) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0=approved,1=pending,2=rejected,3=expired',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `role_context` enum('user','agent','general') NOT NULL DEFAULT 'user',
  PRIMARY KEY (`id`),
  KEY `advertisements_project_id_foreign` (`project_id`),
  KEY `advertisements_role_context_index` (`role_context`),
  CONSTRAINT `advertisements_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `advertisements`
--

LOCK TABLES `advertisements` WRITE;
/*!40000 ALTER TABLE `advertisements` DISABLE KEYS */;
/*!40000 ALTER TABLE `advertisements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_availabilities`
--

DROP TABLE IF EXISTS `agent_availabilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agent_availabilities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `is_admin_data` tinyint(1) NOT NULL DEFAULT 0,
  `agent_id` bigint(20) unsigned DEFAULT NULL,
  `admin_id` bigint(20) unsigned DEFAULT NULL,
  `day_of_week` enum('monday','tuesday','wednesday','thursday','friday','saturday','sunday') NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `agent_availabilities_agent_id_foreign` (`agent_id`),
  KEY `agent_availabilities_admin_id_foreign` (`admin_id`),
  CONSTRAINT `agent_availabilities_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `agent_availabilities_agent_id_foreign` FOREIGN KEY (`agent_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_availabilities`
--

LOCK TABLES `agent_availabilities` WRITE;
/*!40000 ALTER TABLE `agent_availabilities` DISABLE KEYS */;
INSERT INTO `agent_availabilities` VALUES
(1,0,15,NULL,'tuesday','03:30:00','16:00:00',1,'2026-05-21 01:57:04','2026-05-21 01:57:04'),
(2,0,15,NULL,'wednesday','03:30:00','16:00:00',1,'2026-05-21 01:57:04','2026-05-21 01:57:04'),
(3,0,15,NULL,'thursday','03:30:00','16:00:00',1,'2026-05-21 01:57:04','2026-05-21 01:57:04'),
(4,0,15,NULL,'friday','03:30:00','16:00:00',1,'2026-05-21 01:57:04','2026-05-21 01:57:04'),
(5,0,15,NULL,'saturday','03:30:00','16:00:00',1,'2026-05-21 01:57:04','2026-05-21 01:57:04'),
(6,0,15,NULL,'sunday','03:30:00','16:00:00',1,'2026-05-21 01:57:04','2026-05-21 01:57:04');
/*!40000 ALTER TABLE `agent_availabilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_booking_preferences`
--

DROP TABLE IF EXISTS `agent_booking_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agent_booking_preferences` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `is_admin_data` tinyint(1) NOT NULL DEFAULT 0,
  `agent_id` bigint(20) unsigned DEFAULT NULL,
  `admin_id` bigint(20) unsigned DEFAULT NULL,
  `meeting_duration_minutes` int(11) DEFAULT NULL,
  `lead_time_minutes` int(11) DEFAULT NULL COMMENT 'Minimum Advance Booking Time',
  `buffer_time_minutes` int(11) DEFAULT NULL,
  `auto_confirm` tinyint(1) NOT NULL DEFAULT 0,
  `cancel_reschedule_buffer_minutes` int(11) DEFAULT NULL,
  `auto_cancel_after_minutes` int(11) DEFAULT NULL,
  `auto_cancel_message` text DEFAULT NULL,
  `daily_booking_limit` int(11) DEFAULT NULL,
  `availability_types` text DEFAULT NULL COMMENT 'allowed values: phone, virtual, in_person',
  `anti_spam_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `timezone` varchar(100) NOT NULL DEFAULT 'UTC',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_data` (`is_admin_data`,`admin_id`),
  UNIQUE KEY `agent_booking_preferences_agent_id_unique` (`agent_id`),
  UNIQUE KEY `agent_booking_preferences_admin_id_unique` (`admin_id`),
  CONSTRAINT `agent_booking_preferences_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `agent_booking_preferences_agent_id_foreign` FOREIGN KEY (`agent_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_booking_preferences`
--

LOCK TABLES `agent_booking_preferences` WRITE;
/*!40000 ALTER TABLE `agent_booking_preferences` DISABLE KEYS */;
INSERT INTO `agent_booking_preferences` VALUES
(1,1,NULL,1,30,60,15,0,60,1440,'Appointment auto-cancelled due to no response.',0,'phone,virtual,in_person',1,'Asia/Kolkata','2026-05-21 01:12:50','2026-05-21 01:12:50'),
(2,0,15,NULL,30,120,58,1,59,10,NULL,5,'phone,in_person',1,'Asia/Kolkata','2026-05-21 01:56:28','2026-05-21 01:57:43');
/*!40000 ALTER TABLE `agent_booking_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_extra_time_slots`
--

DROP TABLE IF EXISTS `agent_extra_time_slots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agent_extra_time_slots` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `is_admin_data` tinyint(1) NOT NULL DEFAULT 0,
  `agent_id` bigint(20) unsigned DEFAULT NULL,
  `admin_id` bigint(20) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `reason` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `agent_extra_time_slots_agent_id_foreign` (`agent_id`),
  KEY `agent_extra_time_slots_admin_id_foreign` (`admin_id`),
  CONSTRAINT `agent_extra_time_slots_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `agent_extra_time_slots_agent_id_foreign` FOREIGN KEY (`agent_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_extra_time_slots`
--

LOCK TABLES `agent_extra_time_slots` WRITE;
/*!40000 ALTER TABLE `agent_extra_time_slots` DISABLE KEYS */;
/*!40000 ALTER TABLE `agent_extra_time_slots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_profiles`
--

DROP TABLE IF EXISTS `agent_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agent_profiles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned NOT NULL,
  `agent_name` varchar(191) DEFAULT NULL,
  `agent_email` varchar(191) DEFAULT NULL,
  `agent_address` text DEFAULT NULL,
  `agent_mobile` varchar(191) DEFAULT NULL,
  `agent_country_code` varchar(191) DEFAULT NULL,
  `agent_profile_photo` varchar(191) DEFAULT NULL,
  `instagram_id` varchar(191) DEFAULT NULL,
  `youtube_id` varchar(191) DEFAULT NULL,
  `twitter_id` varchar(191) DEFAULT NULL,
  `facebook_id` varchar(191) DEFAULT NULL,
  `about_me` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `agent_profiles_customer_id_unique` (`customer_id`),
  CONSTRAINT `agent_profiles_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_profiles`
--

LOCK TABLES `agent_profiles` WRITE;
/*!40000 ALTER TABLE `agent_profiles` DISABLE KEYS */;
INSERT INTO `agent_profiles` VALUES
(1,15,'Hs','hemssarda@gmail.com','barmer','9990687827','91','1779008978-0023.jpg',NULL,NULL,NULL,NULL,NULL,'2026-05-17 03:28:49','2026-05-17 09:09:38');
/*!40000 ALTER TABLE `agent_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_unavailabilities`
--

DROP TABLE IF EXISTS `agent_unavailabilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agent_unavailabilities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `is_admin_data` tinyint(1) NOT NULL DEFAULT 0,
  `agent_id` bigint(20) unsigned DEFAULT NULL,
  `admin_id` bigint(20) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `unavailability_type` enum('full_day','specific_time') NOT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `agent_unavailabilities_agent_id_foreign` (`agent_id`),
  KEY `agent_unavailabilities_admin_id_foreign` (`admin_id`),
  CONSTRAINT `agent_unavailabilities_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `agent_unavailabilities_agent_id_foreign` FOREIGN KEY (`agent_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_unavailabilities`
--

LOCK TABLES `agent_unavailabilities` WRITE;
/*!40000 ALTER TABLE `agent_unavailabilities` DISABLE KEYS */;
/*!40000 ALTER TABLE `agent_unavailabilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_verification_form_sections`
--

DROP TABLE IF EXISTS `agent_verification_form_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agent_verification_form_sections` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `form_type` varchar(191) NOT NULL COMMENT 'become_agent, verify_agent',
  `sequence` int(11) NOT NULL DEFAULT 0,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_verification_form_sections`
--

LOCK TABLES `agent_verification_form_sections` WRITE;
/*!40000 ALTER TABLE `agent_verification_form_sections` DISABLE KEYS */;
INSERT INTO `agent_verification_form_sections` VALUES
(1,'Become agent','become_agent',0,'active','2026-05-17 03:27:32','2026-05-17 03:27:32'),
(2,'test new','verify_agent',0,'active','2026-05-17 09:12:43','2026-05-17 09:12:43');
/*!40000 ALTER TABLE `agent_verification_form_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_verification_form_values`
--

DROP TABLE IF EXISTS `agent_verification_form_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agent_verification_form_values` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `agent_verification_form_id` bigint(20) unsigned NOT NULL,
  `value` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `agent_ver_form_vals_form_fk` (`agent_verification_form_id`),
  CONSTRAINT `agent_ver_form_vals_form_fk` FOREIGN KEY (`agent_verification_form_id`) REFERENCES `agent_verification_forms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_verification_form_values`
--

LOCK TABLES `agent_verification_form_values` WRITE;
/*!40000 ALTER TABLE `agent_verification_form_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `agent_verification_form_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_verification_forms`
--

DROP TABLE IF EXISTS `agent_verification_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agent_verification_forms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `agent_verification_form_section_id` bigint(20) unsigned NOT NULL,
  `name` varchar(191) NOT NULL,
  `field_type` varchar(191) NOT NULL,
  `sequence` int(11) NOT NULL DEFAULT 0,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `agent_ver_form_section_fk` (`agent_verification_form_section_id`),
  CONSTRAINT `agent_ver_form_section_fk` FOREIGN KEY (`agent_verification_form_section_id`) REFERENCES `agent_verification_form_sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_verification_forms`
--

LOCK TABLES `agent_verification_forms` WRITE;
/*!40000 ALTER TABLE `agent_verification_forms` DISABLE KEYS */;
INSERT INTO `agent_verification_forms` VALUES
(1,1,'Documents','file',0,'active','2026-05-17 03:27:55','2026-05-17 03:27:55'),
(3,2,'Pan Card Number','text',0,'active','2026-05-17 09:14:13','2026-05-17 09:14:13');
/*!40000 ALTER TABLE `agent_verification_forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_verification_values`
--

DROP TABLE IF EXISTS `agent_verification_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agent_verification_values` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `agent_verification_id` bigint(20) unsigned NOT NULL,
  `agent_verification_form_id` bigint(20) unsigned NOT NULL,
  `value` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `agent_ver_vals_ver_fk` (`agent_verification_id`),
  KEY `agent_ver_vals_form_fk` (`agent_verification_form_id`),
  CONSTRAINT `agent_ver_vals_form_fk` FOREIGN KEY (`agent_verification_form_id`) REFERENCES `agent_verification_forms` (`id`) ON DELETE CASCADE,
  CONSTRAINT `agent_ver_vals_ver_fk` FOREIGN KEY (`agent_verification_id`) REFERENCES `agent_verifications` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_verification_values`
--

LOCK TABLES `agent_verification_values` WRITE;
/*!40000 ALTER TABLE `agent_verification_values` DISABLE KEYS */;
INSERT INTO `agent_verification_values` VALUES
(1,1,1,'1778988510-img-0287.jpeg','2026-05-17 03:28:30','2026-05-17 03:28:30'),
(2,2,3,'AEDPH3897R','2026-05-17 09:14:33','2026-05-17 09:14:33');
/*!40000 ALTER TABLE `agent_verification_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_verifications`
--

DROP TABLE IF EXISTS `agent_verifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agent_verifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned NOT NULL,
  `form_type` enum('become_agent','verify_agent') NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `agent_verifications_customer_id_foreign` (`customer_id`),
  CONSTRAINT `agent_verifications_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_verifications`
--

LOCK TABLES `agent_verifications` WRITE;
/*!40000 ALTER TABLE `agent_verifications` DISABLE KEYS */;
INSERT INTO `agent_verifications` VALUES
(1,15,'become_agent','approved','2026-05-17 03:28:30','2026-05-17 03:28:49'),
(2,15,'verify_agent','approved','2026-05-17 09:14:33','2026-05-17 09:14:45');
/*!40000 ALTER TABLE `agent_verifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appointment_cancellations`
--

DROP TABLE IF EXISTS `appointment_cancellations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appointment_cancellations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `appointment_id` bigint(20) unsigned NOT NULL,
  `cancelled_by` enum('user','agent','system','admin') NOT NULL,
  `reason` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `appointment_cancellations_appointment_id_foreign` (`appointment_id`),
  CONSTRAINT `appointment_cancellations_appointment_id_foreign` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointment_cancellations`
--

LOCK TABLES `appointment_cancellations` WRITE;
/*!40000 ALTER TABLE `appointment_cancellations` DISABLE KEYS */;
/*!40000 ALTER TABLE `appointment_cancellations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appointment_reschedules`
--

DROP TABLE IF EXISTS `appointment_reschedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appointment_reschedules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `appointment_id` bigint(20) unsigned NOT NULL,
  `old_start_at` datetime NOT NULL,
  `old_end_at` datetime NOT NULL,
  `new_start_at` datetime NOT NULL,
  `new_end_at` datetime NOT NULL,
  `reason` text DEFAULT NULL,
  `rescheduled_by` enum('user','agent','system','admin') NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `appointment_reschedules_appointment_id_foreign` (`appointment_id`),
  CONSTRAINT `appointment_reschedules_appointment_id_foreign` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointment_reschedules`
--

LOCK TABLES `appointment_reschedules` WRITE;
/*!40000 ALTER TABLE `appointment_reschedules` DISABLE KEYS */;
/*!40000 ALTER TABLE `appointment_reschedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appointments`
--

DROP TABLE IF EXISTS `appointments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appointments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `is_admin_appointment` tinyint(1) NOT NULL DEFAULT 0,
  `admin_id` bigint(20) unsigned DEFAULT NULL,
  `agent_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `property_id` bigint(20) unsigned DEFAULT NULL,
  `meeting_type` enum('phone','virtual','in_person') NOT NULL,
  `start_at` datetime NOT NULL,
  `end_at` datetime NOT NULL,
  `status` enum('pending','confirmed','cancelled','rescheduled','completed','auto_cancelled') NOT NULL DEFAULT 'pending',
  `is_auto_confirmed` tinyint(1) NOT NULL DEFAULT 0,
  `last_status_updated_by` enum('user','agent','system') DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `appointments_admin_id_foreign` (`admin_id`),
  KEY `appointments_agent_id_foreign` (`agent_id`),
  KEY `appointments_user_id_foreign` (`user_id`),
  KEY `appointments_property_id_foreign` (`property_id`),
  CONSTRAINT `appointments_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `appointments_agent_id_foreign` FOREIGN KEY (`agent_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `appointments_property_id_foreign` FOREIGN KEY (`property_id`) REFERENCES `propertys` (`id`) ON DELETE SET NULL,
  CONSTRAINT `appointments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointments`
--

LOCK TABLES `appointments` WRITE;
/*!40000 ALTER TABLE `appointments` DISABLE KEYS */;
/*!40000 ALTER TABLE `appointments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `area_listing_areas`
--

DROP TABLE IF EXISTS `area_listing_areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area_listing_areas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `state_id` bigint(20) unsigned DEFAULT NULL,
  `city_id` bigint(20) unsigned DEFAULT NULL,
  `city_name` varchar(191) DEFAULT NULL,
  `city` varchar(191) DEFAULT NULL,
  `state` varchar(191) DEFAULT NULL,
  `country` varchar(191) DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `normalized_name` varchar(191) DEFAULT NULL,
  `slug` varchar(191) NOT NULL,
  `center_lat` decimal(10,7) DEFAULT NULL,
  `center_lng` decimal(10,7) DEFAULT NULL,
  `radius_meters` int(10) unsigned DEFAULT NULL,
  `polygon_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`polygon_json`)),
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `workflow_status` varchar(20) NOT NULL DEFAULT 'active',
  `archived_at` timestamp NULL DEFAULT NULL,
  `seo_title` varchar(191) DEFAULT NULL,
  `seo_description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `area_listing_areas_city_state_name_unique` (`city`,`state`,`name`),
  UNIQUE KEY `area_listing_areas_city_state_country_normalized_unique` (`city`,`state`,`country`,`normalized_name`),
  KEY `area_listing_areas_city_index` (`city`),
  KEY `area_listing_areas_state_index` (`state`),
  KEY `area_listing_areas_country_index` (`country`),
  KEY `area_listing_areas_name_index` (`name`),
  KEY `area_listing_areas_slug_index` (`slug`),
  KEY `area_listing_areas_status_index` (`status`),
  KEY `area_listing_areas_state_id_index` (`state_id`),
  KEY `area_listing_areas_city_id_index` (`city_id`),
  KEY `area_listing_areas_workflow_status_index` (`workflow_status`),
  KEY `area_listing_areas_city_name_index` (`city_name`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area_listing_areas`
--

LOCK TABLES `area_listing_areas` WRITE;
/*!40000 ALTER TABLE `area_listing_areas` DISABLE KEYS */;
INSERT INTO `area_listing_areas` VALUES
(2,1,1,'Barmer','Barmer','Rajasthan','India','Rai Colony Road','rai colony road','rai-colony-road',NULL,NULL,NULL,NULL,0,1,'active',NULL,NULL,NULL,'2026-05-14 08:36:27','2026-05-14 20:18:10'),
(3,1,1,'Barmer','Barmer','Rajasthan','India','Mahaveer Nagar','mahaveer nagar','mahaveer-nagar',NULL,NULL,NULL,NULL,0,1,'active',NULL,NULL,NULL,'2026-05-14 18:22:52','2026-05-14 20:18:10'),
(42,1,1,'Barmer','Barmer','Rajasthan','India','Baldev Nagar','baldev nagar','baldev-nagar',NULL,NULL,NULL,NULL,0,1,'active','2026-05-20 20:50:21',NULL,NULL,'2026-05-20 19:51:29','2026-05-20 21:51:37'),
(43,NULL,NULL,'Udaipur','Udaipur','Rajasthan','India','Maharana Udai Singh Market','maharana udai singh market','maharana-udai-singh-market',NULL,NULL,NULL,NULL,0,1,'active',NULL,NULL,NULL,'2026-05-20 21:14:29','2026-05-20 21:14:29'),
(45,1,1,'Barmer','Barmer','Rajasthan','India','Krishna Nagar','krishna nagar','krishna-nagar',NULL,NULL,NULL,NULL,0,1,'active',NULL,NULL,NULL,'2026-05-21 03:16:16','2026-05-21 03:16:16');
/*!40000 ALTER TABLE `area_listing_areas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `area_listing_cities`
--

DROP TABLE IF EXISTS `area_listing_cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area_listing_cities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `state_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `normalized_name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `state` varchar(191) NOT NULL DEFAULT '',
  `country` varchar(191) NOT NULL DEFAULT 'India',
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `area_listing_cities_normalized_state_country_unique` (`normalized_name`,`state`,`country`),
  UNIQUE KEY `area_listing_cities_state_id_slug_unique` (`state_id`,`slug`),
  KEY `area_listing_cities_state_id_index` (`state_id`),
  KEY `area_listing_cities_slug_index` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area_listing_cities`
--

LOCK TABLES `area_listing_cities` WRITE;
/*!40000 ALTER TABLE `area_listing_cities` DISABLE KEYS */;
INSERT INTO `area_listing_cities` VALUES
(1,1,'Barmer','barmer','barmer','Rajasthan','India',0,1,'2026-05-14 20:18:10','2026-05-14 20:18:10'),
(7,6,'Bhuj','bhuj','bhuj','Gujarat','India',0,1,'2026-05-20 16:52:51','2026-05-20 16:52:51'),
(8,6,'ઢોંસા','ઢોંસા','','Gujarat','India',0,1,'2026-05-20 16:52:51','2026-05-20 16:52:51'),
(9,7,'New Delhi','new delhi','new-delhi','Delhi','India',0,1,'2026-05-20 16:52:51','2026-05-20 16:52:51'),
(10,1,'Udaipur','udaipur','udaipur','Rajasthan','India',0,1,'2026-05-20 21:15:23','2026-05-20 21:15:23'),
(11,1,'Jaipur','jaipur','jaipur','Rajasthan','India',0,1,'2026-05-20 21:29:36','2026-05-20 21:29:36');
/*!40000 ALTER TABLE `area_listing_cities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `area_listing_merge_audits`
--

DROP TABLE IF EXISTS `area_listing_merge_audits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area_listing_merge_audits` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `entity_type` varchar(20) NOT NULL,
  `old_id` bigint(20) unsigned NOT NULL,
  `new_id` bigint(20) unsigned NOT NULL,
  `affected_properties` int(10) unsigned NOT NULL DEFAULT 0,
  `affected_projects` int(10) unsigned NOT NULL DEFAULT 0,
  `admin_user_id` bigint(20) unsigned DEFAULT NULL,
  `snapshot` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`snapshot`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `area_listing_merge_audit_lookup` (`entity_type`,`old_id`,`new_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area_listing_merge_audits`
--

LOCK TABLES `area_listing_merge_audits` WRITE;
/*!40000 ALTER TABLE `area_listing_merge_audits` DISABLE KEYS */;
INSERT INTO `area_listing_merge_audits` VALUES
(5,'sub_area',30,27,0,0,1,'{\"source\":\"suggestion_merge\",\"suggested_name\":\"Taliyo Ka Was\",\"review_note\":null,\"merged_at\":\"2026-05-20 20:58:58\"}','2026-05-20 20:58:58','2026-05-20 20:58:58');
/*!40000 ALTER TABLE `area_listing_merge_audits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `area_listing_project_locations`
--

DROP TABLE IF EXISTS `area_listing_project_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area_listing_project_locations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint(20) unsigned NOT NULL,
  `state_id` bigint(20) unsigned DEFAULT NULL,
  `city_id` bigint(20) unsigned DEFAULT NULL,
  `area_id` bigint(20) unsigned DEFAULT NULL,
  `sub_area_id` bigint(20) unsigned DEFAULT NULL,
  `state` varchar(191) DEFAULT NULL,
  `city` varchar(191) DEFAULT NULL,
  `area_name` varchar(191) DEFAULT NULL,
  `sub_area_name` varchar(191) DEFAULT NULL,
  `detected_area_name` varchar(191) DEFAULT NULL,
  `detected_sub_area_name` varchar(191) DEFAULT NULL,
  `full_address` text DEFAULT NULL,
  `manual_address` text DEFAULT NULL,
  `display_address` varchar(191) DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `location_source` varchar(191) NOT NULL DEFAULT 'manual',
  `is_verified` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `source` varchar(191) NOT NULL DEFAULT 'manual',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `area_listing_project_locations_project_id_unique` (`project_id`),
  KEY `area_listing_project_locations_sub_area_id_foreign` (`sub_area_id`),
  KEY `area_listing_project_locations_area_id_sub_area_id_index` (`area_id`,`sub_area_id`),
  KEY `area_listing_project_locations_state_id_index` (`state_id`),
  KEY `area_listing_project_locations_city_id_index` (`city_id`),
  CONSTRAINT `area_listing_project_locations_area_id_foreign` FOREIGN KEY (`area_id`) REFERENCES `area_listing_areas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `area_listing_project_locations_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `area_listing_project_locations_sub_area_id_foreign` FOREIGN KEY (`sub_area_id`) REFERENCES `area_listing_sub_areas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area_listing_project_locations`
--

LOCK TABLES `area_listing_project_locations` WRITE;
/*!40000 ALTER TABLE `area_listing_project_locations` DISABLE KEYS */;
/*!40000 ALTER TABLE `area_listing_project_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `area_listing_property_locations`
--

DROP TABLE IF EXISTS `area_listing_property_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area_listing_property_locations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `property_id` bigint(20) unsigned NOT NULL,
  `state_id` bigint(20) unsigned DEFAULT NULL,
  `city_id` bigint(20) unsigned DEFAULT NULL,
  `area_id` bigint(20) unsigned DEFAULT NULL,
  `sub_area_id` bigint(20) unsigned DEFAULT NULL,
  `state` varchar(191) DEFAULT NULL,
  `city` varchar(191) DEFAULT NULL,
  `area_name` varchar(191) DEFAULT NULL,
  `sub_area_name` varchar(191) DEFAULT NULL,
  `detected_area_name` varchar(191) DEFAULT NULL,
  `detected_sub_area_name` varchar(191) DEFAULT NULL,
  `full_address` text DEFAULT NULL,
  `manual_address` text DEFAULT NULL,
  `display_address` varchar(191) DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `location_source` varchar(191) NOT NULL DEFAULT 'manual',
  `is_verified` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `source` varchar(191) NOT NULL DEFAULT 'manual',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `area_listing_property_locations_property_id_unique` (`property_id`),
  KEY `area_listing_property_locations_sub_area_id_foreign` (`sub_area_id`),
  KEY `area_listing_property_locations_area_id_sub_area_id_index` (`area_id`,`sub_area_id`),
  KEY `area_listing_property_locations_state_id_index` (`state_id`),
  KEY `area_listing_property_locations_city_id_index` (`city_id`),
  CONSTRAINT `area_listing_property_locations_area_id_foreign` FOREIGN KEY (`area_id`) REFERENCES `area_listing_areas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `area_listing_property_locations_property_id_foreign` FOREIGN KEY (`property_id`) REFERENCES `propertys` (`id`) ON DELETE CASCADE,
  CONSTRAINT `area_listing_property_locations_sub_area_id_foreign` FOREIGN KEY (`sub_area_id`) REFERENCES `area_listing_sub_areas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area_listing_property_locations`
--

LOCK TABLES `area_listing_property_locations` WRITE;
/*!40000 ALTER TABLE `area_listing_property_locations` DISABLE KEYS */;
INSERT INTO `area_listing_property_locations` VALUES
(1,11,1,10,43,NULL,'Rajasthan','Udaipur','Maharana Udai Singh Market',NULL,'Maharana Udai Singh Market',NULL,'HPG2+86W, Maharana Udai Singh Market, Ganesh Ghati, Udaipur, Rajasthan 313001, India','Opp lalit shop gaur chatrawas','Maharana Udai Singh Market, Udaipur, Rajasthan',24.5761000,73.7005000,'google',0,NULL,15,'google','2026-05-20 21:15:23','2026-05-20 21:20:12'),
(2,12,1,1,2,2,'Rajasthan','Barmer','Rai Colony Road','Bariyon Ka Vas','Rai Colony Road','Bariyon Ka Vas','new Barmer, Rajasthan 344001, India','rai colony krishna nagar barmer','Bariyon Ka Vas, Rai Colony Road, Barmer, Rajasthan',25.7521467,71.3966865,'google',0,NULL,1,'google','2026-05-20 11:45:55','2026-05-20 11:45:55'),
(8,13,1,1,42,27,'Rajasthan','Barmer','Baldev Nagar','Nichla Was','Baldev Nagar','Nichla Was','krishna Nagar, Barmer, Rajasthan 344001, India','opp lalit store gaur chatravas','Nichla Was, Baldev Nagar, Barmer, Rajasthan',25.7514820,71.3924730,'google',0,NULL,15,'google','2026-05-20 21:07:03','2026-05-20 21:07:03'),
(19,1,6,7,NULL,NULL,'Gujarat','Bhuj',NULL,NULL,NULL,NULL,NULL,NULL,'Bhuj, Gujarat',23.1831890,69.6840750,'manual',0,NULL,NULL,'manual','2026-05-20 16:52:51','2026-05-20 16:52:51'),
(20,2,6,7,NULL,NULL,'Gujarat','Bhuj',NULL,NULL,NULL,NULL,NULL,NULL,'Bhuj, Gujarat',23.1930230,69.7351100,'manual',0,NULL,NULL,'manual','2026-05-20 16:52:51','2026-05-20 16:52:51'),
(21,3,6,8,NULL,NULL,'Gujarat','ઢોંસા',NULL,NULL,NULL,NULL,NULL,NULL,'ઢોંસા, Gujarat',23.3169170,69.6198280,'manual',0,NULL,NULL,'manual','2026-05-20 16:52:51','2026-05-20 16:52:51'),
(22,4,1,1,NULL,NULL,'Rajasthan','Barmer',NULL,NULL,NULL,NULL,NULL,NULL,'Barmer, Rajasthan',25.7522057,71.3865196,'manual',0,NULL,NULL,'manual','2026-05-20 16:52:51','2026-05-20 16:52:51'),
(23,5,6,8,NULL,NULL,'Gujarat','કુરબાઈ',NULL,NULL,NULL,NULL,NULL,NULL,'કુરબાઈ, Gujarat',23.1973620,69.6090700,'manual',0,NULL,NULL,'manual','2026-05-20 16:52:51','2026-05-20 16:52:51'),
(24,6,1,1,42,27,'Rajasthan','Barmer','Baldev Nagar','Nichla Was','Baldev Nagar','Nichla Was','Barmer, Rajasthan 344001, India','Barmer Rajasthan','Nichla Was, Baldev Nagar, Barmer, Rajasthan',25.7521467,71.3966865,'manual',0,NULL,1,'manual','2026-05-20 20:53:54','2026-05-20 20:53:54'),
(25,7,6,8,NULL,NULL,'Gujarat','પાલારા',NULL,NULL,NULL,NULL,NULL,NULL,'પાલારા, Gujarat',23.2989810,69.6604120,'manual',0,NULL,NULL,'manual','2026-05-20 16:52:51','2026-05-20 16:52:51'),
(26,8,1,1,NULL,NULL,'Rajasthan','Barmer',NULL,NULL,NULL,NULL,NULL,NULL,'Barmer, Rajasthan',25.7461698,71.3971774,'manual',0,NULL,NULL,'manual','2026-05-20 16:52:51','2026-05-20 16:52:51'),
(27,9,7,9,NULL,NULL,'Delhi','New Delhi',NULL,NULL,NULL,NULL,NULL,NULL,'New Delhi, Delhi',28.7577147,77.1952590,'manual',0,NULL,NULL,'manual','2026-05-20 16:52:51','2026-05-20 16:52:51'),
(28,10,7,9,NULL,NULL,'Delhi','New Delhi',NULL,NULL,NULL,NULL,NULL,NULL,'New Delhi, Delhi',28.7801407,77.1794183,'manual',0,NULL,NULL,'manual','2026-05-20 16:52:51','2026-05-20 16:52:51');
/*!40000 ALTER TABLE `area_listing_property_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `area_listing_states`
--

DROP TABLE IF EXISTS `area_listing_states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area_listing_states` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `country` varchar(191) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `area_listing_states_country_slug_unique` (`country`,`slug`),
  KEY `area_listing_states_slug_index` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area_listing_states`
--

LOCK TABLES `area_listing_states` WRITE;
/*!40000 ALTER TABLE `area_listing_states` DISABLE KEYS */;
INSERT INTO `area_listing_states` VALUES
(1,'Rajasthan','rajasthan','India',0,1,'2026-05-14 20:18:10','2026-05-14 20:18:10'),
(2,'Test State 6A0De0F383551','test-state-6a0de0f383551','India',0,1,'2026-05-20 16:27:32','2026-05-20 16:27:32'),
(3,'Test State 6A0De1F097Ce0','test-state-6a0de1f097ce0','India',0,1,'2026-05-20 16:31:45','2026-05-20 16:31:45'),
(6,'Gujarat','gujarat','India',0,1,'2026-05-20 16:52:51','2026-05-20 16:52:51'),
(7,'Delhi','delhi','India',0,1,'2026-05-20 16:52:51','2026-05-20 16:52:51');
/*!40000 ALTER TABLE `area_listing_states` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `area_listing_sub_areas`
--

DROP TABLE IF EXISTS `area_listing_sub_areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area_listing_sub_areas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `area_id` bigint(20) unsigned NOT NULL,
  `name` varchar(191) NOT NULL,
  `normalized_name` varchar(191) DEFAULT NULL,
  `slug` varchar(191) NOT NULL,
  `center_lat` decimal(10,7) DEFAULT NULL,
  `center_lng` decimal(10,7) DEFAULT NULL,
  `radius_meters` int(10) unsigned DEFAULT NULL,
  `polygon_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`polygon_json`)),
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `workflow_status` varchar(20) NOT NULL DEFAULT 'active',
  `archived_at` timestamp NULL DEFAULT NULL,
  `seo_title` varchar(191) DEFAULT NULL,
  `seo_description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `area_listing_sub_areas_area_slug_unique` (`area_id`,`slug`),
  UNIQUE KEY `area_listing_sub_areas_area_normalized_unique` (`area_id`,`normalized_name`),
  KEY `area_listing_sub_areas_name_index` (`name`),
  KEY `area_listing_sub_areas_slug_index` (`slug`),
  KEY `area_listing_sub_areas_status_index` (`status`),
  KEY `area_listing_sub_areas_workflow_status_index` (`workflow_status`),
  CONSTRAINT `area_listing_sub_areas_area_id_foreign` FOREIGN KEY (`area_id`) REFERENCES `area_listing_areas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area_listing_sub_areas`
--

LOCK TABLES `area_listing_sub_areas` WRITE;
/*!40000 ALTER TABLE `area_listing_sub_areas` DISABLE KEYS */;
INSERT INTO `area_listing_sub_areas` VALUES
(2,2,'Bariyon Ka Vas','bariyon ka vas','bariyon-ka-vas',NULL,NULL,NULL,NULL,0,1,'active',NULL,NULL,NULL,'2026-05-14 08:36:27','2026-05-17 12:14:11'),
(27,42,'Nichla Was','nichla was','nichla-was',25.7521467,71.3966865,NULL,NULL,0,1,'active',NULL,NULL,NULL,'2026-05-20 20:53:49','2026-05-20 20:53:49'),
(29,45,'Rai Colony Road','rai colony road','rai-colony-road',NULL,NULL,NULL,NULL,0,1,'active',NULL,NULL,NULL,'2026-05-21 03:16:39','2026-05-21 03:16:39');
/*!40000 ALTER TABLE `area_listing_sub_areas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `area_listing_suggestions`
--

DROP TABLE IF EXISTS `area_listing_suggestions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area_listing_suggestions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  `area_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `normalized_name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `city` varchar(191) DEFAULT NULL,
  `state` varchar(191) DEFAULT NULL,
  `country` varchar(191) DEFAULT NULL,
  `suggested_by` bigint(20) unsigned DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `review_note` text DEFAULT NULL,
  `reviewed_by` bigint(20) unsigned DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `area_listing_suggestions_type_status` (`type`,`status`),
  KEY `area_listing_suggestions_status_index` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area_listing_suggestions`
--

LOCK TABLES `area_listing_suggestions` WRITE;
/*!40000 ALTER TABLE `area_listing_suggestions` DISABLE KEYS */;
INSERT INTO `area_listing_suggestions` VALUES
(29,'sub_area',42,'Nichla Was','nichla was','nichla-was',NULL,NULL,'India',15,'approved',NULL,1,'2026-05-20 19:52:38','2026-05-20 19:52:21','2026-05-20 19:52:38'),
(30,'sub_area',42,'Taliyo Ka Was','taliyo ka was','taliyo-ka-was',NULL,NULL,'India',15,'merged',NULL,1,'2026-05-20 20:58:58','2026-05-20 20:58:30','2026-05-20 20:58:58'),
(31,'area',NULL,'Maharana Udai Singh Market','maharana udai singh market','maharana-udai-singh-market','Udaipur','Rajasthan','India',15,'approved',NULL,1,'2026-05-20 21:14:29','2026-05-20 21:14:13','2026-05-20 21:14:29'),
(32,'sub_area',42,'Dsdsfds','dsdsfds','dsdsfds',NULL,NULL,'India',15,'rejected','fake',1,'2026-05-20 21:41:28','2026-05-20 21:41:03','2026-05-20 21:41:28');
/*!40000 ALTER TABLE `area_listing_suggestions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) NOT NULL,
  `image` varchar(191) NOT NULL,
  `description` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `category_id` varchar(191) NOT NULL DEFAULT '0',
  `slug_id` varchar(191) NOT NULL,
  `meta_title` text DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `meta_keywords` text DEFAULT NULL,
  `meta_image` varchar(191) DEFAULT NULL,
  `view_count` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `articles_slug_id_unique` (`slug_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles`
--

LOCK TABLES `articles` WRITE;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assign_parameters`
--

DROP TABLE IF EXISTS `assign_parameters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assign_parameters` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `modal_type` varchar(191) NOT NULL,
  `modal_id` bigint(20) unsigned NOT NULL,
  `property_id` int(11) NOT NULL,
  `parameter_id` int(11) NOT NULL,
  `value` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `assign_parameters_modal_type_modal_id_index` (`modal_type`,`modal_id`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assign_parameters`
--

LOCK TABLES `assign_parameters` WRITE;
/*!40000 ALTER TABLE `assign_parameters` DISABLE KEYS */;
INSERT INTO `assign_parameters` VALUES
(1,'App\\Models\\Property',1,0,1,'5','2026-04-02 18:17:32','2026-04-02 18:17:32'),
(2,'App\\Models\\Property',1,0,2,'4','2026-04-02 18:17:32','2026-04-02 18:17:32'),
(3,'App\\Models\\Property',1,0,3,'2','2026-04-02 18:17:32','2026-04-02 18:17:32'),
(4,'App\\Models\\Property',1,0,4,'3','2026-04-02 18:17:32','2026-04-02 18:17:32'),
(5,'App\\Models\\Property',1,0,5,'6500','2026-04-02 18:17:32','2026-04-02 18:17:32'),
(6,'App\\Models\\Property',2,0,1,'4','2026-04-02 18:17:33','2026-04-02 18:17:33'),
(7,'App\\Models\\Property',2,0,2,'3','2026-04-02 18:17:33','2026-04-02 18:17:33'),
(8,'App\\Models\\Property',2,0,3,'1','2026-04-02 18:17:33','2026-04-02 18:17:33'),
(9,'App\\Models\\Property',2,0,4,'2','2026-04-02 18:17:33','2026-04-02 18:17:33'),
(10,'App\\Models\\Property',2,0,5,'3200','2026-04-02 18:17:33','2026-04-02 18:17:33'),
(11,'App\\Models\\Property',3,0,1,'2','2026-04-02 18:17:34','2026-04-02 18:17:34'),
(12,'App\\Models\\Property',3,0,2,'2','2026-04-02 18:17:34','2026-04-02 18:17:34'),
(13,'App\\Models\\Property',3,0,3,'1','2026-04-02 18:17:34','2026-04-02 18:17:34'),
(14,'App\\Models\\Property',3,0,4,'1','2026-04-02 18:17:34','2026-04-02 18:17:34'),
(15,'App\\Models\\Property',3,0,5,'1200','2026-04-02 18:17:34','2026-04-02 18:17:34'),
(19,'App\\Models\\Property',5,0,5,'8000','2026-04-02 18:17:35','2026-04-02 18:17:35'),
(25,'App\\Models\\Property',7,0,1,'3','2026-04-02 18:17:36','2026-04-02 18:17:36'),
(26,'App\\Models\\Property',7,0,2,'2','2026-04-02 18:17:36','2026-04-02 18:17:36'),
(27,'App\\Models\\Property',7,0,3,'1','2026-04-02 18:17:36','2026-04-02 18:17:36'),
(28,'App\\Models\\Property',7,0,4,'2','2026-04-02 18:17:36','2026-04-02 18:17:36'),
(29,'App\\Models\\Property',7,0,5,'1800','2026-04-02 18:17:36','2026-04-02 18:17:36'),
(35,'App\\Models\\Property',8,0,1,'1','2026-04-07 16:08:29','2026-04-07 16:08:29'),
(36,'App\\Models\\Property',8,0,2,'1','2026-04-07 16:08:29','2026-04-07 16:08:29'),
(37,'App\\Models\\Property',8,0,3,'1','2026-04-07 16:08:29','2026-04-07 16:08:29'),
(38,'App\\Models\\Property',8,0,4,'1','2026-04-07 16:08:29','2026-04-07 16:08:29'),
(39,'App\\Models\\Property',8,0,5,'600','2026-04-07 16:08:29','2026-04-07 16:08:29'),
(40,'App\\Models\\Property',4,0,4,'10','2026-04-08 04:10:49','2026-04-08 04:10:49'),
(41,'App\\Models\\Property',4,0,5,'5000','2026-04-08 04:10:49','2026-04-08 04:10:49'),
(42,'App\\Models\\Property',9,0,1,'1','2026-04-25 05:36:53','2026-04-25 05:36:53'),
(43,'App\\Models\\Property',9,0,2,'1','2026-04-25 05:36:53','2026-04-25 05:36:53'),
(44,'App\\Models\\Property',9,0,3,'1','2026-04-25 05:36:53','2026-04-25 05:36:53'),
(45,'App\\Models\\Property',9,0,4,'1','2026-04-25 05:36:53','2026-04-25 05:36:53'),
(46,'App\\Models\\Property',9,0,5,'600','2026-04-25 05:36:53','2026-04-25 05:36:53'),
(51,'App\\Models\\Property',10,0,5,NULL,'2026-04-25 05:56:38','2026-04-25 05:56:38'),
(52,'App\\Models\\Property',10,0,6,NULL,'2026-04-25 05:56:38','2026-04-25 05:56:38'),
(67,'App\\Models\\Property',12,0,1,NULL,'2026-05-20 11:45:55','2026-05-20 11:45:55'),
(68,'App\\Models\\Property',12,0,2,NULL,'2026-05-20 11:45:55','2026-05-20 11:45:55'),
(69,'App\\Models\\Property',12,0,3,NULL,'2026-05-20 11:45:55','2026-05-20 11:45:55'),
(70,'App\\Models\\Property',12,0,4,NULL,'2026-05-20 11:45:55','2026-05-20 11:45:55'),
(71,'App\\Models\\Property',12,0,5,NULL,'2026-05-20 11:45:55','2026-05-20 11:45:55'),
(72,'App\\Models\\Property',13,0,1,'2','2026-05-20 15:13:22','2026-05-20 15:13:22'),
(73,'App\\Models\\Property',13,0,2,'1','2026-05-20 15:13:22','2026-05-20 15:13:22'),
(74,'App\\Models\\Property',13,0,3,'1','2026-05-20 15:13:22','2026-05-20 15:13:22'),
(75,'App\\Models\\Property',13,0,4,'1','2026-05-20 15:13:22','2026-05-20 15:13:22'),
(76,'App\\Models\\Property',13,0,5,'850','2026-05-20 15:13:22','2026-05-20 15:13:22'),
(97,'App\\Models\\Property',6,0,1,'6','2026-05-20 20:53:54','2026-05-20 20:53:54'),
(98,'App\\Models\\Property',6,0,2,'5','2026-05-20 20:53:54','2026-05-20 20:53:54'),
(99,'App\\Models\\Property',6,0,3,'2','2026-05-20 20:53:54','2026-05-20 20:53:54'),
(100,'App\\Models\\Property',6,0,4,'4','2026-05-20 20:53:54','2026-05-20 20:53:54'),
(101,'App\\Models\\Property',6,0,5,'7500','2026-05-20 20:53:54','2026-05-20 20:53:54'),
(102,'App\\Models\\Property',11,0,5,'450','2026-05-20 20:55:23','2026-05-20 20:55:23'),
(103,'App\\Models\\Property',11,0,6,'2 BHK','2026-05-20 20:55:23','2026-05-20 20:55:23');
/*!40000 ALTER TABLE `assign_parameters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assigned_outdoor_facilities`
--

DROP TABLE IF EXISTS `assigned_outdoor_facilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assigned_outdoor_facilities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `property_id` int(11) NOT NULL,
  `facility_id` int(11) NOT NULL,
  `distance` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assigned_outdoor_facilities`
--

LOCK TABLES `assigned_outdoor_facilities` WRITE;
/*!40000 ALTER TABLE `assigned_outdoor_facilities` DISABLE KEYS */;
INSERT INTO `assigned_outdoor_facilities` VALUES
(1,9,2,2,'2026-04-25 05:36:53','2026-04-25 05:36:53'),
(8,12,2,1.2,'2026-05-20 11:45:55','2026-05-20 11:45:55'),
(15,13,2,1.5,'2026-05-20 21:07:03','2026-05-20 21:07:03'),
(16,11,2,1.2,'2026-05-20 21:15:23','2026-05-20 21:15:23');
/*!40000 ALTER TABLE `assigned_outdoor_facilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bank_receipt_files`
--

DROP TABLE IF EXISTS `bank_receipt_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bank_receipt_files` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `payment_transaction_id` bigint(20) unsigned NOT NULL,
  `file` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bank_receipt_files_payment_transaction_id_foreign` (`payment_transaction_id`),
  CONSTRAINT `bank_receipt_files_payment_transaction_id_foreign` FOREIGN KEY (`payment_transaction_id`) REFERENCES `payment_transactions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank_receipt_files`
--

LOCK TABLES `bank_receipt_files` WRITE;
/*!40000 ALTER TABLE `bank_receipt_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `bank_receipt_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blocked_chat_users`
--

DROP TABLE IF EXISTS `blocked_chat_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blocked_chat_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `by_user_id` bigint(20) unsigned DEFAULT NULL COMMENT 'Block by user',
  `by_admin` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Block by admin',
  `user_id` bigint(20) unsigned DEFAULT NULL COMMENT 'Block to user',
  `admin` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Block to admin',
  `reason` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blocked_chat_users_by_user_id_foreign` (`by_user_id`),
  KEY `blocked_chat_users_user_id_foreign` (`user_id`),
  CONSTRAINT `blocked_chat_users_by_user_id_foreign` FOREIGN KEY (`by_user_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `blocked_chat_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blocked_chat_users`
--

LOCK TABLES `blocked_chat_users` WRITE;
/*!40000 ALTER TABLE `blocked_chat_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `blocked_chat_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blocked_users_for_appointments`
--

DROP TABLE IF EXISTS `blocked_users_for_appointments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blocked_users_for_appointments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `blocked_by_admin_id` bigint(20) unsigned NOT NULL,
  `report_id` bigint(20) unsigned DEFAULT NULL,
  `block_type` enum('agent_specific','global') NOT NULL DEFAULT 'agent_specific',
  `agent_id` bigint(20) unsigned DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `blocked_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `unblocked_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blocked_users_for_appointments_blocked_by_admin_id_foreign` (`blocked_by_admin_id`),
  KEY `blocked_users_for_appointments_report_id_foreign` (`report_id`),
  KEY `blocked_users_for_appointments_user_id_block_type_status_index` (`user_id`,`block_type`,`status`),
  KEY `blocked_users_for_appointments_agent_id_status_index` (`agent_id`,`status`),
  CONSTRAINT `blocked_users_for_appointments_agent_id_foreign` FOREIGN KEY (`agent_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `blocked_users_for_appointments_blocked_by_admin_id_foreign` FOREIGN KEY (`blocked_by_admin_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `blocked_users_for_appointments_report_id_foreign` FOREIGN KEY (`report_id`) REFERENCES `report_user_by_agents` (`id`) ON DELETE SET NULL,
  CONSTRAINT `blocked_users_for_appointments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blocked_users_for_appointments`
--

LOCK TABLES `blocked_users_for_appointments` WRITE;
/*!40000 ALTER TABLE `blocked_users_for_appointments` DISABLE KEYS */;
/*!40000 ALTER TABLE `blocked_users_for_appointments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `key` varchar(191) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES
('sukoon_infratech_innovation_group_cache_329b373eb2d2b2faa2e8096da21426dc','i:1;',1779312242),
('sukoon_infratech_innovation_group_cache_329b373eb2d2b2faa2e8096da21426dc:timer','i:1779312242;',1779312242),
('sukoon_infratech_innovation_group_cache_ads_expired_today','b:1;',1779321599),
('sukoon_infratech_innovation_group_cache_scheduler_running','b:1;',1779312242);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_locks` (
  `key` varchar(191) NOT NULL,
  `owner` varchar(191) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category` varchar(191) NOT NULL,
  `parameter_types` varchar(191) NOT NULL,
  `image` text NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0:DeActive 1:Active',
  `sequence` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `slug_id` varchar(191) NOT NULL,
  `meta_title` text DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `meta_keywords` text DEFAULT NULL,
  `meta_image` varchar(191) DEFAULT NULL,
  `is_demo` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_slug_id_unique` (`slug_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES
(1,'Villa','1,2,3,4,5','1775153851-villa.svg',1,0,'2026-04-02 18:17:31','2026-04-02 18:17:31','villa','Villa','Explore our diverse range of villas, curated for every lifestyle. From luxurious residences to charming investment opportunities.','Lifestyle Homes,Luxury Residences,Investment Properties,Family-Friendly Homes,Urban Living Spaces',NULL,1),
(2,'House','1,2,3,4,5','1775153851-house.svg',1,0,'2026-04-02 18:17:31','2026-04-02 18:17:31','house','House','Discover comfortable houses perfect for families and individuals looking for a place to call home.','Family Homes,Residential Properties,Modern Houses,Suburban Living',NULL,1),
(3,'Apartment','1,2,3,4,5','1775153851-apartment.svg',1,0,'2026-04-02 18:17:31','2026-04-02 18:17:31','apartment','Apartment','Find the perfect apartment in prime locations with modern amenities and great connectivity.','Urban Living,City Apartments,Modern Flats,Residential Units',NULL,1),
(4,'Commercial','4,5','1775153851-commercial.svg',1,0,'2026-04-02 18:17:31','2026-04-02 18:17:31','commercial','Commercial','Explore commercial properties ideal for businesses, offices, and retail establishments.','Commercial Properties,Office Spaces,Retail Spaces,Business Properties',NULL,1),
(5,'Plot','5,6','1775153851-plot.svg',1,0,'2026-04-02 18:17:31','2026-04-09 04:44:00','plot','Plot','Invest in prime plots of land perfect for building your dream property or investment purposes.','Land,Plot,Investment Land,Residential Plot,Commercial Plot',NULL,1);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chats`
--

DROP TABLE IF EXISTS `chats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chats` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `message` varchar(191) DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'by receiver',
  `file` varchar(191) DEFAULT NULL,
  `audio` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `sender_role_context` varchar(255) NOT NULL DEFAULT 'user',
  `receiver_role_context` enum('user','agent','admin') NOT NULL DEFAULT 'user',
  PRIMARY KEY (`id`),
  KEY `chats_role_context_index` (`sender_role_context`),
  KEY `chats_receiver_role_context_index` (`receiver_role_context`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chats`
--

LOCK TABLES `chats` WRITE;
/*!40000 ALTER TABLE `chats` DISABLE KEYS */;
INSERT INTO `chats` VALUES
(1,15,0,4,'Hi',1,NULL,NULL,'2026-05-14 05:37:54','2026-05-14 05:38:09','user','admin'),
(2,0,15,4,'how may i help you',1,NULL,NULL,'2026-05-14 05:38:17','2026-05-14 08:29:45','admin','user'),
(3,16,0,2,'Hi',1,NULL,NULL,'2026-05-14 05:40:53','2026-05-14 05:41:06','user','admin'),
(4,0,16,2,'hi',1,NULL,NULL,'2026-05-14 05:41:12','2026-05-14 05:42:21','admin','user'),
(5,16,0,2,'Hi',1,NULL,NULL,'2026-05-14 07:51:00','2026-05-14 07:51:09','user','agent'),
(6,0,16,2,'hi',0,NULL,NULL,'2026-05-14 07:51:15','2026-05-14 07:51:15','user','user');
/*!40000 ALTER TABLE `chats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `city_images`
--

DROP TABLE IF EXISTS `city_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `city_images` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `city` varchar(191) NOT NULL,
  `image` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `city_images_city_unique` (`city`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `city_images`
--

LOCK TABLES `city_images` WRITE;
/*!40000 ALTER TABLE `city_images` DISABLE KEYS */;
INSERT INTO `city_images` VALUES
(1,'Barmer',NULL,1,'2026-04-07 16:08:29','2026-04-07 16:08:29',NULL),
(2,'New Delhi',NULL,1,'2026-04-25 05:36:53','2026-04-25 05:36:53',NULL),
(3,'Udaipur',NULL,1,'2026-05-20 21:15:23','2026-05-20 21:15:23',NULL);
/*!40000 ALTER TABLE `city_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contactrequests`
--

DROP TABLE IF EXISTS `contactrequests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contactrequests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) NOT NULL,
  `last_name` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `message` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contactrequests`
--

LOCK TABLES `contactrequests` WRITE;
/*!40000 ALTER TABLE `contactrequests` DISABLE KEYS */;
/*!40000 ALTER TABLE `contactrequests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_pages`
--

DROP TABLE IF EXISTS `custom_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_pages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) NOT NULL,
  `slug_id` varchar(191) NOT NULL,
  `icon` varchar(191) DEFAULT NULL,
  `content` longtext NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `custom_pages_slug_id_unique` (`slug_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_pages`
--

LOCK TABLES `custom_pages` WRITE;
/*!40000 ALTER TABLE `custom_pages` DISABLE KEYS */;
INSERT INTO `custom_pages` VALUES
(1,'Cancellation and refund policy','cancellation-and-refund-policy',NULL,'<p><strong>Cancellation and Refund Policy</strong></p>\r\n<p>At Sukoon Homes (a unit of Sukoon Infratech Innovation Group), we prioritize transparency and professional service. This policy outlines our procedures regarding cancellations and refunds for services offered on homes.sukoon.group.</p>\r\n<p>1. Scope of Services</p>\r\n<p>homes.sukoon.group serves as a real estate listing and consultancy platform. As we primarily offer digital listings and information services, the following rules apply to any financial transactions processed through our platform.</p>\r\n<p>2. Subscription and Listing Services</p>\r\n<p>Non-Refundable: Payments made for property listings, premium placement, or advertisement packages are considered \"consumed\" once the listing goes live. Therefore, these payments are non-refundable.</p>\r\n<p>Cancellation: You may cancel a recurring subscription at any time. The cancellation will take effect at the end of the current billing cycle, and no partial refunds will be issued for unused days.</p>\r\n<p>3. Property Bookings and Token Money</p>\r\n<p>Direct Transactions: Please note that Sukoon Homes does not process final property sale amounts or large security deposits through this website.</p>\r\n<p>Offline Agreements: Any token money or booking amounts paid offline to an agent or the company are governed by the specific Booking Agreement or Memorandum of Understanding (MOU) signed at that time. These are generally non-refundable unless the seller/company fails to fulfill their commitment.</p>\r\n<p>4. Consultancy and Visit Fees</p>\r\n<p>If a fee is charged for \"Premium Property Visits\" or \"Document Verification,\" a refund will only be granted if Sukoon Homes is unable to provide the service.</p>\r\n<p>Client-side cancellations made within 24 hours of a scheduled appointment are not eligible for a refund.</p>\r\n<p>5. Refund Processing</p>\r\n<p>Where a refund is deemed applicable by management:</p>\r\n<p>The amount will be credited back to the original payment source (Bank Account, Credit Card, or Wallet).</p>\r\n<p>Please allow 5 to 7 business days for the refund to reflect in your statement.</p>\r\n<p>6. Customer Support</p>\r\n<p>For any queries related to cancellations, please reach out to us:</p>\r\n<p>Email: sitigroup.co@gmail.com</p>\r\n<p>Phone: +91 85948-82948</p>\r\n<p>Business Address: Barmer, Rajasthan</p>',1,'2026-04-10 18:08:20','2026-04-10 18:32:24');
/*!40000 ALTER TABLE `custom_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `slug_id` varchar(191) NOT NULL COMMENT 'Slug of name',
  `auth_id` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `password` varchar(191) DEFAULT NULL,
  `full_mobile` varchar(191) DEFAULT NULL,
  `country_code` varchar(10) DEFAULT NULL,
  `default_language` varchar(191) DEFAULT NULL,
  `mobile` varchar(256) DEFAULT NULL,
  `profile` text DEFAULT NULL,
  `address` text NOT NULL,
  `fcm_id` text DEFAULT NULL,
  `logintype` varchar(191) NOT NULL COMMENT '0 - Gmail, 1 - Number, 2 - Apple, 3 - Email',
  `is_admin_added` tinyint(1) NOT NULL DEFAULT 0,
  `is_email_verified` tinyint(1) NOT NULL DEFAULT 0,
  `isActive` tinyint(4) NOT NULL COMMENT '0:No 1:Yes',
  `is_agent` tinyint(1) NOT NULL DEFAULT 0,
  `is_agent_verified` tinyint(1) NOT NULL DEFAULT 0,
  `can_manage_area_listing` tinyint(1) NOT NULL DEFAULT 0,
  `api_token` text DEFAULT NULL,
  `notification` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0:disable,1:enable',
  `subscription` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `twiiter_id` varchar(191) DEFAULT NULL,
  `latitude` varchar(191) DEFAULT NULL,
  `longitude` varchar(191) DEFAULT NULL,
  `city` varchar(191) DEFAULT NULL,
  `state` varchar(191) DEFAULT NULL,
  `country` varchar(191) DEFAULT NULL,
  `is_premium` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_ids` (`mobile`,`email`,`logintype`,`country_code`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES
(1,'hs','hs','dsQm1OFX5VVtEdeTIIdHM0aF7RD3','hemssarda@gmail.com','$2y$10$HgiXVYb9ho4/bQoDBwuK..zip74fYB2CMRSM8hE0Fw8Q5eXhjYS.2',NULL,'91','en','9958989958',NULL,'',NULL,'1',0,0,1,0,0,0,NULL,1,0,'2026-04-06 03:09:52','2026-05-14 20:02:43',NULL,NULL,NULL,NULL,NULL,NULL,0),
(3,'Hetvi Shah','hetvi-shah','LNjftUmpJJZMThXlCOWCzgrFFxr2','hetvis06@gmail.com',NULL,NULL,NULL,'en',NULL,NULL,'',NULL,'0',0,0,1,0,0,0,NULL,1,0,'2026-04-06 12:35:14','2026-04-16 16:36:40','','','',NULL,NULL,NULL,0),
(4,'Burhanuddin Tinwala','burhanuddin-tinwala','aBtj8JE8MiWfVsFKgwtYFMY3b6F3','burhanwrteam5253@gmail.com',NULL,NULL,'91','en','8469361539','1777101415-wrteam.jpg','Bhuj, Gujarat, India',NULL,'0',0,0,1,0,0,0,NULL,1,0,'2026-04-06 13:09:25','2026-05-14 06:52:07','','23.2419997','69.6669324','Bhuj','Gujarat','India',0),
(5,'Test','test','c797029b-3e49-4e57-8cd8-8d3c2f44b60d','Hemssarda@gmail.com','$2y$10$WTNcHvIcOPNIKYFXyc/Sfuo581UY5QKfw7HX6MPPlUbXihGN1cLJi',NULL,NULL,'en',NULL,NULL,'',NULL,'3',1,1,1,0,0,0,NULL,1,0,'2026-04-10 02:45:08','2026-05-17 03:04:36',NULL,NULL,NULL,NULL,NULL,NULL,0),
(6,'hetvi','hetvi','6d303526-f218-4565-8ef6-143a27be1bce','hetviwork06@gmail.com','$2y$10$P.o0vHQLzFbBiUUREUP/ie/p/ZUGhXJSC2ApTRoX0RKfTGgYA47Ta',NULL,'91',NULL,'9106914972',NULL,'',NULL,'3',0,0,1,0,0,0,NULL,1,0,'2026-04-10 04:38:06','2026-04-10 04:38:06',NULL,NULL,NULL,NULL,NULL,NULL,0),
(7,'hetvi shah','hetvi-shah-1','Oh2n1JIiuTdV3fU3W9KYcmpRl0t1','hetviwork06@gmail.com',NULL,NULL,NULL,'en',NULL,NULL,'',NULL,'0',0,0,1,0,0,0,NULL,1,0,'2026-04-10 04:41:28','2026-04-10 04:41:30','','','',NULL,NULL,NULL,0),
(8,'hs','hs-1','b5c82202-e71e-4563-9d50-06b6ef08bfb3','sukoongroup.co@gmail.com','$2y$10$1bxxWTVeF9Ro3IwUFzZbuu/x.GchYD6gOJWOBbWRKVB/38PP98O/i',NULL,NULL,NULL,NULL,NULL,'',NULL,'3',0,0,1,0,0,0,NULL,1,0,'2026-04-10 05:12:52','2026-04-10 05:12:52',NULL,NULL,NULL,NULL,NULL,NULL,0),
(9,'test','test-1','513ae45e-d858-49c1-b1d9-52c8a2f623aa','hemantsardadl@gmail.com','$2y$10$lzvjol7XduNNMl4a5p4g.OUbecoFtWAqxMeiB/6XZmX25pOnjelcy',NULL,NULL,'en',NULL,NULL,'',NULL,'3',0,1,1,0,0,0,NULL,1,0,'2026-04-10 05:25:09','2026-04-10 05:39:03',NULL,NULL,NULL,NULL,NULL,NULL,0),
(10,'siti group','siti-group','ESgRhxbKOxa1P3ctn5de08XAAdl2','sitigroup.co@gmail.com',NULL,NULL,'91','en','9958989958','1776850716-vat.png','rai colony barmer',NULL,'0',0,0,1,0,0,0,NULL,1,0,'2026-04-10 05:40:11','2026-04-22 10:05:27','','25.7521467','71.3966865','Barmer','Rajasthan','India',0),
(11,'hetvi','hetvi-1','iJIxE5w0uKOIpuhwMRfgOwYKMWP2','hetviwork06@gmail.com','$2y$10$jJKM4SK76jG3vUb4Lb21nO4B73U9vg8GGA8.RZnBzGFiI8oGDywSq',NULL,'91',NULL,'9106914972',NULL,'',NULL,'1',0,0,1,0,0,0,NULL,1,0,'2026-04-11 12:26:27','2026-04-11 12:26:27',NULL,NULL,NULL,NULL,NULL,NULL,0),
(12,'Heti','heti','P0MfE7Wij3TnbUk4YSfbttYPw6I2','shetvi08@gmail.com','$2y$10$9clB2oGj0hJUOncfD3dydewL5RA9v4WUKTah4QIN9dppI3lAh13TS',NULL,'91',NULL,'9924549747',NULL,'',NULL,'1',0,0,1,0,0,0,NULL,1,0,'2026-04-12 11:50:00','2026-04-12 11:50:00',NULL,NULL,NULL,NULL,NULL,NULL,0),
(13,'Hemanshu Parmar','hemanshu-parmar','AZlvXCVmQ8ROwOLEWeC7PQWrsZ82','hemanshu.wrteam@gmail.com',NULL,NULL,'91','en','6359021290','1776253862-wrteam-white.jpg','address',NULL,'0',0,0,1,0,0,0,NULL,1,0,'2026-04-15 08:14:39','2026-04-15 12:00:15','','','',NULL,NULL,NULL,0),
(14,'Hemanshu Parmar','hemanshu-parmar-1','LRER1K2Ah4ZgretNSzMBjAHBUat2','hemanshup2002@gmail.com',NULL,NULL,NULL,'en',NULL,NULL,'',NULL,'0',0,0,1,0,0,0,NULL,1,0,'2026-04-15 12:00:41','2026-04-15 12:01:07','','','',NULL,NULL,NULL,0),
(15,'Hs','hs-2','nePo4NaE71al5WcHJIl1LKO6KIp2','hemssarda@gmail.com','$2y$10$teV9Gq/yYzdg3VduonCYe.hQDWM7H2YIqlNj39xSvYG0brGVr0e32',NULL,'91','en','9990687827','1777099513-n.png','rai colony krishna nagar barmer',NULL,'1',0,0,1,1,1,1,NULL,1,0,'2026-04-17 09:58:31','2026-05-21 03:58:53',NULL,'25.7522057','71.3865196','Barmer','Rajasthan','India',0),
(16,'HEMS SARDA','hems-sarda','TuuI2e5z7sU51iaSP5TciTQ9pNG2','hemssarda@gmail.com',NULL,NULL,'91','en','9990687827','1776853211-image-cropper-1776853202728.jpg','Rai Colony',NULL,'0',0,0,1,0,0,0,NULL,1,0,'2026-04-17 11:20:20','2026-05-14 10:39:04','','25.7521467','71.3966865','Barmer','Rajasthan','India',0),
(17,'Raj','raj','NE18CXRqVBSajHeX9ejOkcA9CPz2','wrteam.raj@gmail.com',NULL,NULL,'91',NULL,'9988665522','1777526933-image-cropper-1777526885997.jpg','Asd',NULL,'0',0,0,1,0,0,0,NULL,1,0,'2026-04-30 05:27:46','2026-04-30 05:28:53','','','',NULL,NULL,NULL,0),
(18,'Hemant Sarda','hemant-sarda','u87wsTSkCyXogC47HoHY8XNWyeP2','hemantsardadl@gmail.com',NULL,NULL,NULL,'en',NULL,NULL,'',NULL,'0',0,0,1,0,0,0,NULL,1,0,'2026-05-14 01:50:27','2026-05-14 05:40:12','','','',NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faqs`
--

DROP TABLE IF EXISTS `faqs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faqs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `user_type` enum('user','agent') NOT NULL DEFAULT 'user',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faqs`
--

LOCK TABLES `faqs` WRITE;
/*!40000 ALTER TABLE `faqs` DISABLE KEYS */;
/*!40000 ALTER TABLE `faqs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favourites`
--

DROP TABLE IF EXISTS `favourites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `favourites` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role_context` enum('user','agent','general') NOT NULL DEFAULT 'user',
  PRIMARY KEY (`id`),
  KEY `favourites_role_context_index` (`role_context`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favourites`
--

LOCK TABLES `favourites` WRITE;
/*!40000 ALTER TABLE `favourites` DISABLE KEYS */;
/*!40000 ALTER TABLE `favourites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `features`
--

DROP TABLE IF EXISTS `features`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `features` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `type` enum('property_list','project_list','property_feature','project_feature','mortgage_calculator_detail','premium_properties','project_access','premium_projects') DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `user_type` enum('all','user','agent') DEFAULT 'all',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `features`
--

LOCK TABLES `features` WRITE;
/*!40000 ALTER TABLE `features` DISABLE KEYS */;
INSERT INTO `features` VALUES
(1,'Property List','property_list',1,'all','2026-04-01 12:38:22','2026-04-01 12:38:22',NULL),
(2,'Property Feature List','property_feature',1,'all','2026-04-01 12:38:22','2026-04-01 12:38:22',NULL),
(3,'Project List','project_list',1,'all','2026-04-01 12:38:22','2026-04-01 12:38:22',NULL),
(4,'Project Feature List','project_feature',1,'all','2026-04-01 12:38:22','2026-04-01 12:38:22',NULL),
(5,'Mortgage Calculator Detail Access','mortgage_calculator_detail',1,'user','2026-04-01 12:38:22','2026-04-01 12:38:22',NULL),
(6,'Premium Properties Access','premium_properties',1,'user','2026-04-01 12:38:22','2026-04-01 12:38:22',NULL),
(7,'Premium Projects Access','premium_projects',1,'user','2026-04-01 12:38:22','2026-04-01 12:38:22',NULL);
/*!40000 ALTER TABLE `features` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gemini_usage`
--

DROP TABLE IF EXISTS `gemini_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gemini_usage` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL COMMENT 'Customer ID or User ID',
  `user_type` varchar(50) NOT NULL DEFAULT 'customer' COMMENT 'customer or admin',
  `type` varchar(50) NOT NULL COMMENT 'description, meta, search',
  `entity_type` varchar(50) DEFAULT NULL COMMENT 'property, project',
  `entity_id` bigint(20) unsigned DEFAULT NULL,
  `prompt_hash` varchar(191) NOT NULL COMMENT 'MD5 hash of prompt for caching',
  `tokens_used` int(11) DEFAULT NULL,
  `ip_address` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `gemini_usage_index` (`user_id`,`user_type`,`type`,`created_at`),
  KEY `gemini_usage_prompt_hash_index` (`prompt_hash`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gemini_usage`
--

LOCK TABLES `gemini_usage` WRITE;
/*!40000 ALTER TABLE `gemini_usage` DISABLE KEYS */;
INSERT INTO `gemini_usage` VALUES
(1,1,'admin','description','property',8,'486d4278f8fc41c8d36e1d3a6ad0f458',464,'172.70.108.241','2026-04-07 13:41:50','2026-04-07 13:41:50'),
(2,1,'admin','meta','property',8,'45bdf67c27cf1301317a7acd63936e2d',264,'172.70.108.241','2026-04-07 13:42:09','2026-04-07 13:42:09'),
(3,1,'admin','description','property',NULL,'f6a9ff109e9c54b3d8580a861cac3b0c',498,'104.22.48.159','2026-04-25 05:37:46','2026-04-25 05:37:46'),
(4,15,'customer','description','property',NULL,'8ab3dd2a4d3fe74cf4785b7271673ff1',427,'172.70.108.241','2026-04-26 04:53:49','2026-04-26 04:53:49'),
(5,15,'customer','meta','property',NULL,'9d92e2fa08cba044c188e7c9d058e6ad',281,'172.70.108.241','2026-04-26 05:03:07','2026-04-26 05:03:07');
/*!40000 ALTER TABLE `gemini_usage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `homepage_sections`
--

DROP TABLE IF EXISTS `homepage_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `homepage_sections` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) NOT NULL,
  `section_type` enum('agents_list_section','articles_section','categories_section','faqs_section','featured_properties_section','featured_projects_section','most_liked_properties_section','most_viewed_properties_section','nearby_properties_section','projects_section','premium_properties_section','user_recommendations_section','properties_by_cities_section','properties_on_map_section') DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `homepage_sections`
--

LOCK TABLES `homepage_sections` WRITE;
/*!40000 ALTER TABLE `homepage_sections` DISABLE KEYS */;
INSERT INTO `homepage_sections` VALUES
(1,'Meet Our Top Real Estate Agents Ready to Help You Find Your Dream Property','agents_list_section',1,5,'2026-04-01 12:38:22','2026-04-01 12:38:22'),
(2,'Explore Our Blog: Everything You Need to Know About Real Estate','articles_section',1,13,'2026-04-01 12:38:22','2026-04-01 12:38:22'),
(3,'Unlock the Best Real Estate Opportunities with Category-Wise Listings','categories_section',1,2,'2026-04-01 12:38:22','2026-04-01 12:38:22'),
(4,'Got Questions About Your Next Real Estate Move? We\'ve Got Answers!','faqs_section',1,14,'2026-04-01 12:38:22','2026-04-01 12:38:22'),
(5,'Experience Luxury Living with Our Featured Properties','featured_properties_section',1,3,'2026-04-01 12:38:22','2026-04-01 12:38:22'),
(6,'Featured Projects That Define Modern Living and Exceptional Design','featured_projects_section',1,9,'2026-04-01 12:38:22','2026-04-01 12:38:22'),
(7,'Trending Properties Loved by Many: See What\'s Capturing Attention in Real Estate','most_liked_properties_section',1,10,'2026-04-01 12:38:22','2026-04-01 12:38:22'),
(8,'The Most Viewed Properties That Homebuyers Can\'t Stop Looking At!','most_viewed_properties_section',1,4,'2026-04-01 12:38:22','2026-04-01 12:38:22'),
(9,'Experience Comfortable Living with Top Properties in','nearby_properties_section',1,1,'2026-04-01 12:38:22','2026-04-01 12:38:22'),
(10,'The Next Era of Living: Explore Upcoming & Under-Construction Projects','projects_section',1,8,'2026-04-01 12:38:22','2026-04-01 12:38:22'),
(11,'Discover Handpicked Premium Properties for Discerning Buyers','premium_properties_section',1,11,'2026-04-01 12:38:22','2026-04-01 12:38:22'),
(12,'Discover Handpicked Properties Perfectly Tailored to Your Unique Interests','user_recommendations_section',1,6,'2026-04-01 12:38:22','2026-04-01 12:38:22'),
(13,'Your Dream Property Might Be Closer Than You Think: Check Nearby Cities','properties_by_cities_section',1,12,'2026-04-01 12:38:22','2026-04-01 12:38:22'),
(14,'Find Homes, Apartments & More with Real-Time Listings on the Map','properties_on_map_section',1,7,'2026-04-01 12:38:22','2026-04-01 12:38:22');
/*!40000 ALTER TABLE `homepage_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interested_users`
--

DROP TABLE IF EXISTS `interested_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `interested_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0-No,1-Yes',
  `property_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interested_users`
--

LOCK TABLES `interested_users` WRITE;
/*!40000 ALTER TABLE `interested_users` DISABLE KEYS */;
INSERT INTO `interested_users` VALUES
(1,0,4,10,'2026-04-15 03:00:02','2026-04-15 03:00:02');
/*!40000 ALTER TABLE `interested_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `languages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(512) NOT NULL,
  `code` varchar(64) NOT NULL,
  `file_name` varchar(512) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0 COMMENT '1=>active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `rtl` tinyint(1) NOT NULL COMMENT '0=false,1=true',
  PRIMARY KEY (`id`),
  UNIQUE KEY `languages_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `languages`
--

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` VALUES
(1,'English','en','en.json',1,NULL,'2026-04-12 07:18:12',NULL,0),
(2,'Hindi','hi','hi.json',1,'2026-04-09 11:22:35','2026-04-09 11:22:40',NULL,0);
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'2018_08_08_100000_create_telescope_entries_table',1),
(2,'2019_12_14_000001_create_personal_access_tokens_table',1),
(3,'2023_03_18_033231_create_users_table',1),
(4,'2023_03_18_033352_create_password_resets_table',1),
(5,'2023_03_18_033442_create_failed_jobs_table',1),
(6,'2023_03_18_033634_create_categories_table',1),
(7,'2023_03_18_033727_create_settings_table',1),
(8,'2023_03_18_033816_create_customers_table',1),
(9,'2023_03_18_033916_create_sliders_table',1),
(10,'2023_03_18_034006_create_propertys_table',1),
(11,'2023_03_18_034055_create_property_images_table',1),
(12,'2023_03_18_034200_create_notification_table',1),
(13,'2023_03_18_034245_create_parameters_table',1),
(14,'2023_03_18_034321_create_favourites_table',1),
(15,'2023_03_18_034420_create_assign_parameters_table',1),
(16,'2023_03_18_034454_create_articles_table',1),
(17,'2023_03_18_034735_create_packages_table',1),
(18,'2023_03_18_034813_create_user_purchased_packages_table',1),
(19,'2023_03_18_034855_create_languages_table',1),
(20,'2023_03_18_034939_cretate_advertisements_table',1),
(21,'2023_03_18_035027_create_interested_users_table',1),
(22,'2023_03_18_035059_create_payments_table',1),
(23,'2023_03_18_035130_create_chats_table',1),
(24,'2023_04_07_054100_rename_file_column_in_languages_table',1),
(25,'2023_04_07_055215_alter_table_propertys_change_latitude_latitude',1),
(26,'2023_04_25_091951_alter_table_payments_change_amount',1),
(27,'2023_04_26_060301_alter_tabele_propertys_change_price',1),
(28,'2023_05_11_055149_add_rtl__to_languages_table',1),
(29,'2023_06_13_100955_create_users_tokens_table',1),
(30,'2023_06_28_104556_create_outdoor_facilities_table',1),
(31,'2023_06_28_112848_create_assigned_outdoor_facilities_table',1),
(32,'2023_07_04_085912_add_rentduration_to_propertys_table',1),
(33,'2023_07_17_122324_create_report_reasons_table',1),
(34,'2023_07_17_122354_create_user_reports_table',1),
(35,'2023_08_02_130025_make_email_value_in_assign_parameters_table',1),
(36,'2023_08_22_054625_add_category_to_article__table',1),
(37,'2023_08_22_062456_create_user_interests_table',1),
(38,'2023_11_07_081457_add_columns_to_customers',1),
(39,'2023_11_17_052005_create_contactrequests_table',1),
(40,'2023_11_23_042600_make_data_column_nullable_in_settings_table',1),
(41,'2023_12_18_103036_add_column_to_categories_table',1),
(42,'2023_12_18_103148_add_column_to_articles_table',1),
(43,'2023_12_18_103226_add_column_to_propertys_table',1),
(44,'2023_12_18_103514_change_datatype_to_settings_table',1),
(45,'2024_01_02_053848_create_seo_settings_table',1),
(46,'2024_01_02_054734_add_columns_to_propertys_table',1),
(47,'2024_01_02_054837_add_columns_to_articles_table',1),
(48,'2024_01_02_055754_add_columns_to_categories_table',1),
(49,'2024_01_24_121526_make_message_column_nullable_in_chats_table',1),
(50,'2024_02_07_124810_add_coumns_to_customers_table',1),
(51,'2024_02_16_121015_add_coumns_to_packages_table',1),
(52,'2024_02_26_055053_add_coumns_to_packages_table',1),
(53,'2024_02_26_055535_add_coumns_to_user_purchased_packages_table',1),
(54,'2024_02_26_061106_add_coumns_to_customers_table',1),
(55,'2024_02_26_085212_add_coumns_to_propertys_table',1),
(56,'2024_02_27_100246_create_projects_table',1),
(57,'2024_02_27_101454_create_project_documents_table',1),
(58,'2024_03_01_113401_create_project_plans_table',1),
(59,'2024_03_20_095532_make_seo_columns_nullable',1),
(60,'2024_03_28_070334_add_columns_to_projects_table',1),
(61,'2024_04_19_084914_version_1.1.4',1),
(62,'2024_05_25_054809_version_1.1.5',1),
(63,'2024_06_07_085606_1_1_6_version',1),
(64,'2024_08_08_053034_1_1_7_version',1),
(65,'2024_09_08_084744_1_1_8_version',1),
(66,'2024_09_26_112115_1_1_9_version',1),
(67,'2024_11_12_114051_1_2_0_version',1),
(68,'2024_12_10_102159_1_2_5_version',1),
(69,'2025_01_07_062042_1_2_2_version',1),
(70,'2025_02_14_054054_1_2_3_version',1),
(71,'2025_04_13_121951_1_2_4_version',1),
(72,'2025_04_13_121951_1_2_5_version',1),
(73,'2025_06_28_044244_create_jobs_table',1),
(74,'2025_08_20_143737_1_2_6_version',1),
(75,'2025_10_13_100008_1_2_7_version',1),
(76,'2025_10_15_112836_1_2_8_version',1),
(77,'2025_12_02_045304_1_2_9_version',1),
(78,'2026_01_19_082939_1_3_0_version',1),
(79,'2026_02_17_102552_add_is_premium_to_project_table',1),
(80,'2026_02_17_102643_add_video_fields_to_propertys_table',1),
(81,'2026_02_17_102710_add_video_type_to_projects_table',1),
(82,'2026_02_18_042806_add_listing_duration_columns_to_packages_properties_projects',1),
(83,'2026_02_20_064710_create_pay_as_you_gos_table',1),
(84,'2026_02_20_065241_add_pay_as_you_go_id_to_payment_transactions',1),
(85,'2026_02_20_072556_create_user_pay_as_you_go_credits_table',1),
(86,'2026_02_27_034740_backfill_expiry_date_for_old_listings',1),
(87,'2026_02_27_064712_add_premium_projects_access_feature_to_features_table',1),
(88,'2026_03_02_102725_create_custom_pages_table',1),
(89,'2026_03_06_000001_add_property_id_project_id_to_payment_transactions',1),
(90,'2026_03_23_112848_1_4_0_version',2),
(91,'2026_04_08_100000_create_service_health_logs_table',2),
(92,'2026_05_14_080000_create_area_listing_tables',3),
(93,'2026_05_16_000001_add_manual_address_to_area_listing_locations',4),
(94,'2026_05_17_154500_harden_area_listing_tables',5),
(95,'2026_05_20_120000_create_nearby_places_tables',6),
(96,'2026_05_21_100000_create_travel_time_cache_table',7),
(97,'2026_05_20_150000_add_nearby_quality_fields',8),
(98,'2026_05_21_120000_create_nearby_place_overrides_table',9),
(99,'2026_05_22_120000_add_cache_ttl_hours_to_nearby_categories',10),
(100,'2026_05_20_212239_create_cache_table',11),
(101,'2026_05_23_100000_add_nearby_public_directions_setting',12),
(102,'2026_05_21_000001_add_area_sub_area_to_user_interests_table',13);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nearby_categories`
--

DROP TABLE IF EXISTS `nearby_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nearby_categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `google_place_type` varchar(191) DEFAULT NULL,
  `icon` varchar(191) DEFAULT NULL,
  `default_radius_m` int(10) unsigned NOT NULL DEFAULT 2000,
  `max_results` tinyint(3) unsigned NOT NULL DEFAULT 5,
  `min_rating` decimal(2,1) NOT NULL DEFAULT 3.5,
  `min_reviews` smallint(5) unsigned NOT NULL DEFAULT 3,
  `allow_unrated` tinyint(1) NOT NULL DEFAULT 0,
  `hide_generic_places` tinyint(1) NOT NULL DEFAULT 1,
  `hide_suspicious_same_location` tinyint(1) NOT NULL DEFAULT 1,
  `max_distance_m` int(10) unsigned DEFAULT NULL,
  `max_results_after_filter` tinyint(3) unsigned DEFAULT NULL,
  `cache_ttl_hours` int(10) unsigned DEFAULT NULL,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nearby_categories_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nearby_categories`
--

LOCK TABLES `nearby_categories` WRITE;
/*!40000 ALTER TABLE `nearby_categories` DISABLE KEYS */;
INSERT INTO `nearby_categories` VALUES
(1,'Hospital','hospital','hospital','fa-hospital',2000,5,3.5,3,0,1,1,NULL,NULL,8760,1,1,NULL,'2026-05-20 07:00:10','2026-05-20 13:57:26'),
(2,'School','school','school','fa-school',2000,5,3.5,3,0,1,1,NULL,NULL,NULL,2,1,NULL,'2026-05-20 07:00:10','2026-05-20 07:00:10'),
(3,'Restaurant','restaurant','restaurant','fa-utensils',3000,5,3.5,3,0,1,1,NULL,NULL,NULL,3,1,NULL,'2026-05-20 07:00:10','2026-05-20 13:33:53'),
(4,'Bank','bank','bank','fa-university',2000,5,3.5,3,0,1,1,NULL,NULL,NULL,4,1,NULL,'2026-05-20 07:00:10','2026-05-20 07:00:10'),
(5,'Market','market','supermarket','fa-shopping-basket',2000,5,3.5,3,0,1,1,NULL,NULL,NULL,5,1,NULL,'2026-05-20 07:00:10','2026-05-20 11:24:40'),
(6,'Park','park','park','fa-tree',2000,5,3.5,3,0,1,1,NULL,NULL,NULL,6,1,NULL,'2026-05-20 07:00:10','2026-05-20 07:00:10'),
(7,'Gym','gym','gym','fa-dumbbell',2000,5,3.5,3,0,1,1,NULL,NULL,NULL,7,1,NULL,'2026-05-20 07:00:10','2026-05-20 07:00:10'),
(8,'Bus Stand','bus-stand','bus_station','fa-bus',2500,5,3.5,3,0,1,1,NULL,NULL,NULL,8,1,NULL,'2026-05-20 07:00:10','2026-05-20 07:00:10'),
(9,'Railway Station','railway-station','train_station','fa-train',5000,5,3.5,3,0,1,1,NULL,NULL,NULL,9,1,NULL,'2026-05-20 07:00:10','2026-05-20 07:00:10');
/*!40000 ALTER TABLE `nearby_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nearby_place_cache`
--

DROP TABLE IF EXISTS `nearby_place_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nearby_place_cache` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `property_id` bigint(20) unsigned NOT NULL,
  `nearby_category_id` bigint(20) unsigned NOT NULL,
  `google_place_id` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `rating` decimal(3,1) DEFAULT NULL,
  `user_ratings_total` int(10) unsigned DEFAULT NULL,
  `business_status` varchar(40) DEFAULT NULL,
  `distance_m` int(10) unsigned NOT NULL DEFAULT 0,
  `distance_text` varchar(191) DEFAULT NULL,
  `is_open` tinyint(1) DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `vicinity` varchar(191) DEFAULT NULL,
  `place_types` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`place_types`)),
  `quality_passed` tinyint(1) NOT NULL DEFAULT 1,
  `hidden_reason` varchar(80) DEFAULT NULL,
  `fetched_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nearby_place_cache_unique` (`property_id`,`nearby_category_id`,`google_place_id`),
  KEY `nearby_place_cache_property_id_nearby_category_id_index` (`property_id`,`nearby_category_id`),
  KEY `nearby_place_cache_expires_at_index` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2639 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nearby_place_cache`
--

LOCK TABLES `nearby_place_cache` WRITE;
/*!40000 ALTER TABLE `nearby_place_cache` DISABLE KEYS */;
INSERT INTO `nearby_place_cache` VALUES
(1948,11,1,'ChIJG7ArZnflZzkRXT2kacnQ7IU','Dr. Prakash Sharma Hospital and Dental Unit',5.0,308,'OPERATIONAL',1016,'1.0 km away',0,24.5844484,73.6964190,'117, Bapu Bazar, Bapu Bazar Main Road, Nada Khada, Udaipur','[\"dentist\",\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:23:28','2027-05-20 21:23:28','2026-05-20 21:23:28','2026-05-20 21:23:28'),
(1949,11,1,'ChIJ19zZjoblZzkRUpmI9rqI9aA','J.P. Orthopedic Hospital',4.8,1020,'OPERATIONAL',1138,'1.1 km away',1,24.5793496,73.7111733,'100, College Road, Kumharon Ka Bhatta, Central Area, Udaipur','[\"hospital\",\"doctor\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:23:28','2027-05-20 21:23:28','2026-05-20 21:23:28','2026-05-20 21:23:28'),
(1950,11,1,'ChIJy0iQO4_lZzkR7ByyOZJVCUM','Indira IVF Fertility Centre in Udaipur - Best IVF Centre',4.8,1553,'OPERATIONAL',1088,'1.1 km away',0,24.5792828,73.7106732,'opp. College Road, 44, Amar Niwas, opp. College Road, Kumharon Ka Bhatta, Central Area, Udaipur','[\"hospital\",\"doctor\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:23:28','2027-05-20 21:23:28','2026-05-20 21:23:28','2026-05-20 21:23:28'),
(1951,11,1,'ChIJgaN_jHXlZzkR_HqNpOGF6tI','Bhandari Children Hospital in Udaipur | Child Hospital in Udaipur | Best Pediatrician | NICU Neonatal Care',4.3,497,'OPERATIONAL',1714,'1.7 km away',1,24.5915148,73.7004360,'90, L Rd, Bhupalpura, Udaipur','[\"hospital\",\"doctor\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:23:28','2027-05-20 21:23:28','2026-05-20 21:23:28','2026-05-20 21:23:28'),
(1952,11,1,'ChIJHzRzJJvlZzkR5ubzFx53_ZI','Alakh Nayan Mandir',4.0,149,'OPERATIONAL',1408,'1.4 km away',0,24.5859992,73.7091878,'Durga Nursery Road, Ashok Nagar, Udaipur','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:23:28','2027-05-20 21:23:28','2026-05-20 21:23:28','2026-05-20 21:23:28'),
(1953,11,1,'ChIJLVHU4HjlZzkR_WmSJ1OTdC4','Stree Clinic (A Clinic of Parivar Seva Sanstha)',4.3,8,'OPERATIONAL',453,'453 m away',0,24.5796089,73.6982184,'near Fateh Memorial, 23, Thakkar Baba Road, Surajpole, Udaipur','[\"hospital\",\"doctor\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:23:28','2027-05-20 21:23:28','2026-05-20 21:23:28','2026-05-20 21:23:28'),
(1954,11,1,'ChIJvwtCDJvlZzkRSZ58v-ECtOw','Dr. Dalal Eye Hospital',4.0,39,'OPERATIONAL',1433,'1.4 km away',0,24.5885544,73.7041603,'397/9, Road Number 10, Near Vidhyaniketan School, Ashok Nagar, Udaipur','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:23:28','2027-05-20 21:23:28','2026-05-20 21:23:28','2026-05-20 21:23:28'),
(1955,11,1,'ChIJy0Ufc3TlZzkRFWdwWC04Jo8','Dr. Kanchan Agrawal Hospital',3.9,15,'OPERATIONAL',1701,'1.7 km away',0,24.5906900,73.6954520,'16, Hazareshwar Mahadeo, Udaipur','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:23:28','2027-05-20 21:23:28','2026-05-20 21:23:28','2026-05-20 21:23:28'),
(1956,11,1,'ChIJ3eZCf3HlZzkRwbPaOUKKK2k','Department of Neurology, MB Hospital',4.2,22,'CLOSED_TEMPORARILY',1644,'1.6 km away',NULL,24.5886611,73.6919332,'HMQR+FQ7, RNT Medical College, Chetak Circle, Udaipur','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:23:28','2027-05-20 21:23:28','2026-05-20 21:23:28','2026-05-20 21:23:28'),
(1957,11,1,'ChIJjQWl1JrlZzkR3prDQtioldI','Click4Doctor',4.2,5,'CLOSED_TEMPORARILY',1379,'1.4 km away',NULL,24.5852595,73.7096927,'304,Mehta Sadan,, Durga Nursery Road, Udaipur','[\"hospital\",\"doctor\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:23:28','2027-05-20 21:23:28','2026-05-20 21:23:28','2026-05-20 21:23:28'),
(1958,11,1,'ChIJJcQMRHnlZzkRDDZaE_YwJFs','Mahaveer Hospital',4.0,2,'CLOSED_TEMPORARILY',543,'543 m away',NULL,24.5786281,73.6959010,'Brahmpuri, Udaipur','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:23:28','2027-05-20 21:23:28','2026-05-20 21:23:28','2026-05-20 21:23:28'),
(1959,11,1,'ChIJZ5chOXflZzkR_RZK-nx-_nw','Health Is Wealth',2.0,1,'OPERATIONAL',1126,'1.1 km away',0,24.5853007,73.6958399,'7, Bapu Bazar Rd, Mastan Pan Gali, Behind A To Z Medical,Delhi Gate, Nada Khada, Udaipur','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:23:28','2027-05-20 21:23:28','2026-05-20 21:23:28','2026-05-20 21:23:28'),
(1960,11,1,'ChIJ891hGYTvZzkRaWbg3W9Vcb0','Dr. Kothari maternity home and Kothari eye hospital',3.2,195,'OPERATIONAL',1350,'1.4 km away',0,24.5656991,73.6936177,'Kothari maternity home and reaserch center, near Patel circle, Udaipur','[\"hospital\",\"doctor\",\"point_of_interest\",\"health\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:23:28','2027-05-20 21:23:28','2026-05-20 21:23:28','2026-05-20 21:23:28'),
(1961,11,1,'ChIJNS72SZzlZzkRLhviAtMuz0Y','Star Health Bazar',2.6,5,'OPERATIONAL',1390,'1.4 km away',0,24.5885913,73.7010499,'near Khadi Show Room, 462-D, Star Health Bazar, Road Number 9, BhopalPura, Shastri Circle, Ashok Nagar, near Khadi Show Room, Udaipur','[\"insurance_agency\",\"hospital\",\"doctor\",\"clothing_store\",\"food\",\"point_of_interest\",\"health\",\"store\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:23:28','2027-05-20 21:23:28','2026-05-20 21:23:28','2026-05-20 21:23:28'),
(1962,11,1,'ChIJn9HmHXblZzkRnzCWpVEYMo0','Ahuja Hospital',1.0,1,'CLOSED_TEMPORARILY',1417,'1.4 km away',NULL,24.5888462,73.7006305,'HPQ2+G7J, near LOTUS THE GARMENT MALL UDAIPUR, Bhopalpura, Udaipur','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:23:28','2027-05-20 21:23:28','2026-05-20 21:23:28','2026-05-20 21:23:28'),
(1963,11,2,'ChIJvURnW3_lZzkREI5pO6bOxBQ','Shree Maharshi College Of Vedic Astrology Love Numerology Palmistry Tarot Card Palm Reading Vastu',4.8,581,'OPERATIONAL',135,'135 m away',0,24.5772485,73.7000683,'Arihant, 306, Udaipole Road, Udaipur','[\"jewelry_store\",\"university\",\"school\",\"store\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1964,11,2,'ChIJrasdJJvlZzkRyGfZJ7AKbzQ','American Institute Of English Language (AIEL), Udaipur',4.9,283,'OPERATIONAL',1420,'1.4 km away',0,24.5861202,73.7092013,'20-21, Durga Nursery Road, Ashok Nagar, Udaipur','[\"embassy\",\"school\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1965,11,2,'ChIJw65uEHTlZzkRkyR59MvWJN0','Kidzee - Bhupalpura',4.7,58,'OPERATIONAL',1754,'1.8 km away',0,24.5918759,73.7007507,'next to Bhandari Child Hospital, 317, L-1 Road, Bhupalpura, Udaipur','[\"school\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1966,11,2,'ChIJq3HGgxDlZzkRzsI4znHWqS8','Ark Montessori',5.0,23,'OPERATIONAL',1543,'1.5 km away',0,24.5898902,73.7022417,'C, House No, near Sankalp Kidney Hospital, 30/A, I Road, Bhupalpura, Udaipur','[\"school\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1967,11,2,'ChIJsQrx6pzlZzkRhE53uk7tSyY','The Einstein Kids Preschool',4.6,16,'OPERATIONAL',1200,'1.2 km away',0,24.5861289,73.7048771,'54, Shastri Marg, Ashok Nagar Main Road, Opp. Sukh Sagar Palace, Udaipur','[\"school\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1968,11,2,'ChIJZVF6m3vlZzkRPfKcIUMq7zw','CITY PRIDE PUBLIC SCHOOL',NULL,NULL,'CLOSED_TEMPORARILY',870,'870 m away',NULL,24.5785736,73.6923397,'Amal Ka Kanta Road, Old City, Brahmpuri, Udaipur','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1969,11,2,'ChIJwVlunn7vZzkR1SYaXLUobfY','Rajasthan Academy Secondary School',NULL,NULL,'OPERATIONAL',986,'986 m away',0,24.5691364,73.7065425,'HP94+MJ3, Police Line Road, Tekri, Gayariawas, Central Area, Udaipur','[\"secondary_school\",\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1970,11,2,'ChIJZ3FWNWPlZzkRvHGX14LQkLE','Eden International School',NULL,NULL,'OPERATIONAL',1172,'1.2 km away',0,24.5757184,73.6889191,'18, Badi Sadri Haveli, Naiyo ki Talai, Udaipur','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1971,11,2,'ChIJPZtAHoXlZzkRIj7xX59N1uY','City Infotech',NULL,NULL,'CLOSED_TEMPORARILY',1176,'1.2 km away',NULL,24.5827265,73.7095597,'Durga Plaza, Durga Nursery Road, Shiv Park Colony, Shakti Nagar, Udaipur','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1972,11,2,'ChIJzf5OannvZzkReILtQJKVqzU','Abhinav School Udaipur',NULL,NULL,'OPERATIONAL',1250,'1.3 km away',0,24.5656337,73.7050230,'9, Adarsh Nagar Bh. Police Line, Savina Main Road, Gayariawas, Udaipur','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1973,11,2,'ChIJf1SYM3flZzkRi2SW49MhYLA','THE SEEMIN REPUBLIC School',NULL,NULL,'CLOSED_TEMPORARILY',1319,'1.3 km away',NULL,24.5854965,73.6925435,'173, Ashwini Bazaar Road, City\'s Prime Health Care Area, Udaipur','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1974,11,2,'ChIJV-WPZ3nvZzkRXKL25-pvvTk','Shree Kardhar Computer Academy',NULL,NULL,'OPERATIONAL',1355,'1.4 km away',0,24.5652664,73.7066430,'Gariyawas main road, opp. Jain temple, udaipur, Udaipur','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1975,11,2,'ChIJlcVAJ4_lZzkRoY4K6TOz6DU','Heritage International Secondary School',NULL,NULL,'OPERATIONAL',1599,'1.6 km away',0,24.5810091,73.7153626,'Front Of M.B. College Grant, 19, Govindpura, Subhash Nagar, Udaipur','[\"secondary_school\",\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1976,11,2,'ChIJhxep1Z3lZzkR2wZMGAQzy6g','ST. Joseph\'s Secondary School',NULL,NULL,'OPERATIONAL',1607,'1.6 km away',0,24.5902574,73.7037134,'behind Maharashtra Bhawan, 1-B, behind Maharashtra Bhawan, Ashok Nagar, Udaipur','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1977,11,2,'ChIJkzydrYblZzkReplMsKUs1I0','Bhupal Nobles Senior Secondary School',NULL,NULL,'OPERATIONAL',1726,'1.7 km away',0,24.5804414,73.7168856,'HPJ8+5QC, National Highway 27, Kumharon Ka Bhatta, Central Area, Udaipur','[\"secondary_school\",\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1978,11,3,'ChIJvYZHWX_lZzkRYQWZAF9Yu18','Hotel Shree Narayana',4.4,2215,'OPERATIONAL',140,'140 m away',1,24.5773594,73.7005732,'opp. ICICI Bank, No.2-B, Hotel Street, Udaipole, Ganesh Ghati, Udaipur','[\"lodging\",\"parking\",\"bar\",\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1979,11,3,'ChIJHxRjjH7lZzkRl0Z96r5O75A','Hotel Gold Leaf - 1 Kms from City Palace & Railway Station',4.1,775,'OPERATIONAL',452,'452 m away',1,24.5754644,73.6960836,'Gold Leaf Hotel, 13, Sarvritu Villas, Gulab Bagh Road, Near Ice Factory, Udaipur','[\"lodging\",\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1980,11,3,'ChIJk1t0smXlZzkRT4w6QtjcDOY','Hotel Kotra Haveli',4.6,963,'OPERATIONAL',1591,'1.6 km away',0,24.5797277,73.6852792,'12 Surya Marg Opp. Jagdish Temple Kasaro Ki Ol, Udaipur','[\"cafe\",\"lodging\",\"restaurant\",\"food\",\"point_of_interest\",\"store\",\"establishment\"]',1,NULL,'2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1981,11,3,'ChIJ3YpwxXzlZzkRSI3yAZSMm9Q','Hotel Boheda Palace by Amazing Hospitality',4.3,722,'OPERATIONAL',1142,'1.1 km away',NULL,24.5752600,73.6892415,'9, Lake Palace Road, Kalaji Goraji, Udaipur','[\"lodging\",\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1982,11,3,'ChIJ8-KpToDPbDkRmn78-WuA6yE','The Oberoi Udaivilas, Udaipur',4.8,7406,'OPERATIONAL',2841,'2.8 km away',1,24.5773827,73.6724412,'HMGC+VVV, Badi-Gorela-Mulla Talai Road, Haridas Ji Ki Magri, Pichola, Udaipur','[\"lodging\",\"bar\",\"restaurant\",\"food\",\"spa\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1983,11,3,'ChIJd3q9h2blZzkRbzN5sbOOdL4','Jagat Niwas Palace Hotel',4.2,4051,'OPERATIONAL',1836,'1.8 km away',1,24.5784095,73.6825250,'23-25, Lal Ghat Behind Jagdish Temple, Udaipur','[\"lodging\",\"bar\",\"restaurant\",\"food\",\"spa\",\"point_of_interest\",\"store\",\"establishment\"]',1,NULL,'2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1984,11,3,'ChIJW5NRgYfvZzkRObaJLOcNluA','Jaiwana Haveli - Lake Facing Hotel',4.4,1649,'OPERATIONAL',1852,'1.9 km away',0,24.5791205,73.6824866,'near Jagdish Mandir, 14, Lal Ghat Road, Udaipur','[\"cafe\",\"lodging\",\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1985,11,3,'ChIJPThigWblZzkRFAHsqIB7HOk','Udaigarh Udaipur - Heritage Hotel with Lake View Rooftop',4.1,1462,'OPERATIONAL',1818,'1.8 km away',1,24.5789306,73.6827909,'behind Jagdish Temple, 21, Lal Ghat Road, Udaipur','[\"lodging\",\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1986,11,3,'ChIJo_yDy2XlZzkRYF_DjLTGOMw','Baba Palace a Heritage Hotel by Vasundhara Corporation',4.0,609,'OPERATIONAL',1684,'1.7 km away',1,24.5797072,73.6843258,'opposite Jagdish Temple, 01, Surya Marg, Jagdish Chowk, Udaipur','[\"cafe\",\"lodging\",\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1987,11,3,'ChIJ1XGj6A3lZzkRubPK1ZaAhp4','Hotel The Archi',4.5,570,'OPERATIONAL',2808,'2.8 km away',1,24.5995141,73.6900956,'near Mumbaiya Chat Bazar, Plot No. 61-A, Sukhadia Circle, New Fatehpura, Udaipur','[\"cafe\",\"lodging\",\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1988,11,3,'ChIJ15dos2flZzkR9QNFGJdKpww','Hotel Mewari Villa Udaipur | Lake View Hotel in Udaipur',4.3,688,'OPERATIONAL',1974,'2.0 km away',0,24.5843630,73.6832198,'302,imli gath,purohito ka khurra before chandpole parking hotel no 302','[\"cafe\",\"lodging\",\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1989,11,3,'ChIJz6Tfh2blZzkREHQbr5iwAT8','Hotel Devraj Niwas on Lake Pichola Udaipur',3.9,503,'OPERATIONAL',1856,'1.9 km away',1,24.5791830,73.6824570,'32, Lal Ghat Road, Old City, Silawatwari, Udaipur','[\"lodging\",\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1990,11,3,'ChIJxySH-p_vZzkRfxA-Alb-_J8','jüSTa Rajputana Resort and Convention Centre, Udaipur',4.2,4586,'OPERATIONAL',2578,'2.6 km away',1,24.5530013,73.7026536,'near Savina, Sector 11, Hiran Magri, Math','[\"lodging\",\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1991,11,3,'ChIJn949q2flZzkRLPCbEwmt3KI','THAMLA HAVELI - Heritage Lake View Hotel',3.9,301,'OPERATIONAL',2085,'2.1 km away',1,24.5800799,73.6803481,'Nr. Hanuman Ghat, Outside Chandpole, Udaipur','[\"lodging\",\"restaurant\",\"food\",\"spa\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1992,11,3,'ChIJVVVVZA7lZzkRNTB6cDRCWoc','Radiant Globus Hotels & Resorts',3.9,2270,'OPERATIONAL',2454,'2.5 km away',1,24.5973495,73.6939528,'Avenue 63rd, Sardarpura, Udaipur','[\"cafe\",\"lodging\",\"restaurant\",\"food\",\"point_of_interest\",\"store\",\"establishment\"]',1,NULL,'2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1993,11,4,'ChIJPU2gZnflZzkRDEWELlEPOlg','Punjab National Bank',3.5,55,'OPERATIONAL',1021,'1.0 km away',0,24.5847414,73.6971002,'Shramjiwi Collage Building, Ashoka Cinema Road, Udaipur','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1994,11,4,'ChIJTdGTJXnlZzkRYbxh7T6h7PM','DCB Bank - Udaipur',3.7,12,'OPERATIONAL',441,'441 m away',0,24.5786981,73.6972104,'nearby New Jyoti Hotel, Plot No 2163, City Station Road, Surajpole, Udaipur','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1995,11,4,'ChIJ4RToll3lZzkRWAZLcRdkxJo','Indian Overseas Bank',3.9,9,'OPERATIONAL',832,'832 m away',0,24.5825660,73.6963680,'opposite Town Hall, 10, Panchsheel Marg, Udaipur','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1996,11,4,'ChIJS9gUmnflZzkRb7k5LAAsUrE','Andhra Bank - Shakti Nagar',3.6,17,'OPERATIONAL',999,'999 m away',0,24.5848851,73.6984220,'Ground Floor, Banthia Bhawan, Shakti Nagar Road, Moti Kunj, Shakti Nagar, Udaipur','[\"bank\",\"atm\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1997,11,4,'ChIJRTYtLn_lZzkRhHlKAE_OPxM','IndusInd Bank ATM',3.5,2,'OPERATIONAL',265,'265 m away',1,24.5775994,73.6984682,'s/0, Surendra Prakash Neelam HandiCraft 18, Gangaur Ghat, Ram Mohan Sandhay, Udaipur','[\"atm\",\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1998,11,4,'ChIJpW1MQH_lZzkR6XrW9cOEovo','ICICI Bank Udiapole, Udaipur-Branch & ATM',3.1,8,'OPERATIONAL',296,'296 m away',0,24.5761650,73.6975751,'General Hospital, Udiapole Building 1F, Udaipur','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(1999,11,4,'ChIJV1vOgIfvZzkR9QEOEWOTZEs','Adarsh Co-operative Bank Ltd',2.0,3,'OPERATIONAL',432,'432 m away',0,24.5786856,73.6973125,'Jeevan Jyoti Complex, Surajpole, Udaipur','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(2000,11,4,'ChIJ209_fkTkZzkRWkzpM1FC-W4','Bank of Baroda Udaipur Main Branch',2.8,15,'OPERATIONAL',960,'960 m away',0,24.5839892,73.6966397,'opp. Town Hall, National Highway No.8, opp. Town Hall, Udaipur','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(2001,11,4,'ChIJz3Te8HzlZzkRX-Gpljg2wiQ','Punjab National Bank',2.8,20,'OPERATIONAL',994,'994 m away',0,24.5750773,73.6907315,'No 8, Maharaja Apartment, Sheetla Marg, Kalaji Goraji, Udaipur','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(2002,11,4,'ChIJNSXSfnflZzkRGbvEW-DjMj8','The Udaipur Central Co-Operative Bank Ltd',3.3,11,'OPERATIONAL',1005,'1.0 km away',0,24.5842613,73.6962237,'HMMW+PF5, Main Office,Bapu Bazar, Nagar Palika Link Road, Shakti Nagar, Udaipur','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(2003,11,4,'ChIJL6s0OH_lZzkRO61NmvZy3sU','YES BANK',2.6,8,'OPERATIONAL',1045,'1.0 km away',0,24.5846627,73.6962492,'Ground Floor, Delhi Gate, Plot No 6A, Surajpole, Scheme, Udaipur','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(2004,11,4,'ChIJJam9a3flZzkRaxgRogn7x8E','Bank of Baroda - Bank Corner',1.5,2,'OPERATIONAL',1052,'1.1 km away',NULL,24.5848219,73.6964597,'HMMW+WHG, Nada Khada, Udaipur','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(2005,11,4,'ChIJmX_lQHflZzkR5Eo3N6fyz2c','SBI Cash Deposit Machine',3.4,11,'OPERATIONAL',1080,'1.1 km away',1,24.5849348,73.6960537,'HMMW+XCF, Nada Khada, Udaipur','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(2006,11,4,'ChIJs2fOuXDlZzkRQqeY0YcnrWA','Rajasthan Marudhara Gramin Bank - Dhanmandi',3.3,3,'CLOSED_TEMPORARILY',1155,'1.2 km away',NULL,24.5846389,73.6939926,'HMMV+VH5, Dholibawri Rd, Dholibawri, Borawadi, Udaipur','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(2007,11,4,'ChIJbWQ0JoXlZzkReI0dq-H1B64','Kotak Mahindra Bank',3.0,46,'OPERATIONAL',1187,'1.2 km away',0,24.5830627,73.7093933,'Mangalam Fun Square, Durga Nursery Road, Udaipur','[\"bank\",\"insurance_agency\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:23:29','2026-05-27 21:23:29','2026-05-20 21:23:29','2026-05-20 21:23:29'),
(2008,11,5,'ChIJJfm1SXblZzkRdPc0fIoKBts','Udaipur Sahakari Upbhokta Thok Bhandar',4.2,476,'OPERATIONAL',1261,'1.3 km away',1,24.5873747,73.6991446,'Post Office Road, Shastri Circle, Ashok Nagar, Udaipur','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2009,11,5,'ChIJERo-1JzlZzkRAnWJKNyCC3Q','Swastik Food Store',5.0,7,'OPERATIONAL',714,'714 m away',0,24.5794023,73.6944467,'K Samne, inside Surajpole, Asthal Mandir Road, Suraj pole, Udaipur','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2010,11,5,'ChIJaUnaWeblZzkRUNg8F6GsvB0','Khanchand Lakhmichand Food Products',5.0,5,'OPERATIONAL',881,'881 m away',0,24.5839419,73.6992695,'Townhall, J37, Nagar Palika Link Road, Town Hall, Bapu Bazar, Shakti Nagar, Udaipur','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2011,11,5,'ChIJnQB4uH3lZzkRpJxmOZKBZEA','Vishal Mega Mart',3.9,2780,'OPERATIONAL',1762,'1.8 km away',0,24.5618660,73.6928370,'138 139 Machla Magra, next to Vishal Mega Mart, near Paras Circle, 139, Machla Magra, Udaipur','[\"supermarket\",\"grocery_or_supermarket\",\"clothing_store\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2012,11,5,'ChIJ36ZCrH_lZzkRh7JXptrQLk0','Agarwal General Store',4.4,9,'OPERATIONAL',288,'288 m away',0,24.5747390,73.6980822,'Udaipole Road, Agrasen Nagar, Jawahar Nagar, Ganga Gali, Udaipur','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2013,11,5,'ChIJuWefl5zlZzkRwW97cgztNhY','Laxmi Kirana Store',4.5,33,'OPERATIONAL',1257,'1.3 km away',0,24.5863059,73.7058464,'48, Ashok Nagar Main Road, Udaipur','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2014,11,5,'ChIJSw6ComnlZzkRjlQ-ScFCAjE','BG COMPANY',4.4,12,'OPERATIONAL',582,'582 m away',NULL,24.5792468,73.6959028,'Plot No. 45, Sarang Marg, Surajpole, Udaipur','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2015,11,5,'ChIJS3ccigvvZzkR9BzgwSuGmYI','Crazy 4 deals',4.8,4,'CLOSED_TEMPORARILY',300,'300 m away',NULL,24.5786394,73.6994851,'Shop No.1, Vasupujaya Complex, near Jain Mandir, Mewar Motor Link Road, Surajpole, Udaipur','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2016,11,5,'ChIJfZPkZXbvZzkRikipyefIxjY','N B TRADING COMPANY',4.3,9,'OPERATIONAL',1916,'1.9 km away',0,24.5589440,73.7023092,'61, Krishi Upaj Mandi, Udaipur','[\"supermarket\",\"grocery_or_supermarket\",\"shopping_mall\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2017,11,5,'ChIJ5UB_wJzvZzkRXiKlGhUqe-o','Sahkari Super Market',4.1,21,'OPERATIONAL',1886,'1.9 km away',0,24.5595582,73.6963753,'11-A/B, Main Road, Shopping Center, Sector No.11, Hiran Magri, Udaipur','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2018,11,5,'ChIJn8zAoH_lZzkR063LtOcn8kg','Bansal General Store',5.0,2,'CLOSED_TEMPORARILY',185,'185 m away',NULL,24.5751495,73.6989987,'15, Agrasen Nagar, Ganga Gali, Udaipur','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2019,11,5,'ChIJZS3ukkzlZzkRCcAzHKomjnY','WorldQart Fresh',5.0,1,'OPERATIONAL',561,'561 m away',NULL,24.5789334,73.6959147,'Surajpole Gate, Bapu Bazar Main Road, Udaipur','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2020,11,5,'ChIJh3TDSPDvZzkREKtQKwIE5Ts','Ramesh Suther',NULL,NULL,'CLOSED_TEMPORARILY',1016,'1.0 km away',NULL,24.5671541,73.6984479,'02 Dungarpur','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2021,11,5,'ChIJJ64jp3DlZzkRAAAAMDnsMnQ','Shwastik Grah Udyog',NULL,NULL,'OPERATIONAL',1069,'1.1 km away',0,24.5835281,73.6937953,'near Rishab Market, Dhan Mandi Udaipur 15 Tel Bazar, near Rishab Market, Udaipur','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2022,11,5,'ChIJ-VC_grzlZzkRagjOltP4i-s','RS KIRANA STORE',5.0,1,'OPERATIONAL',1181,'1.2 km away',NULL,24.5825438,73.7097800,'102, Kumharon Ka Bhatta, Udaipur','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2023,11,6,'ChIJ2Q1MN37lZzkR1NM8Fu6EtlQ','Sarv Ritu Vilas Park, Udaipur',4.1,179,'OPERATIONAL',464,'464 m away',1,24.5733060,73.6970970,'HMFW+8RH, Jawahar Nagar, Shivaji Nagar, Udaipur','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2024,11,6,'ChIJxV-UznnlZzkRqX00BzHuBRI','City Council Park',4.0,114,'OPERATIONAL',762,'762 m away',1,24.5822967,73.6972892,'National Highway 927A, Shakti Nagar, Udaipur','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2025,11,6,'ChIJfWA_TYjvZzkRYqY6NhGQtv4','Manik Lal Verma Park',4.2,1004,'OPERATIONAL',1684,'1.7 km away',1,24.5689743,73.6858111,'HM9P+H8M, Pichola, Udaipur','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2026,11,6,'ChIJoz1O15rlZzkRjxv_uTjRPFM','Shree Mohanlal Sukhadiya Memorial Foundation Park',4.3,1422,'OPERATIONAL',1438,'1.4 km away',0,24.5858295,73.7098752,'HPP5+8XJ, Durga Nursery Road, Ashok Nagar, Udaipur','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2027,11,6,'ChIJs3NDa4nvZzkRxHvbAeAIucE','Pandit Deendayal Upadhyay Park',4.3,733,'OPERATIONAL',1943,'1.9 km away',1,24.5666481,73.6843396,'HM8M+MP4, Pichola, Udaipur','[\"park\",\"tourist_attraction\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2028,11,6,'ChIJb0VKEC_lZzkRiyKUI7X_-uw','Udaipole Jawahar Nagar Circle',4.4,28,'OPERATIONAL',37,'<50 m away',NULL,24.5761378,73.7001384,'HPG2+C2V, Udaipole, Jawahar Nagar, Udaipur','[\"travel_agency\",\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2029,11,6,'ChIJwQCpznnlZzkRRPPmMulU-x4','Nehru Bal Udyan',4.1,34,'OPERATIONAL',801,'801 m away',1,24.5827269,73.6973863,'HMMW+3XR, Panchsheel Marg, Shakti Nagar, Udaipur','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2030,11,6,'ChIJh6SO1bflZzkRk7OHje3mXv4','शिवाजी पार्क',4.3,6,'OPERATIONAL',91,'91 m away',NULL,24.5761359,73.6996013,'HMGX+FR5, Udaipole, Jawahar Nagar, Ganga Gali, Udaipur','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2031,11,6,'ChIJA11Hgn7lZzkRO1u-MhXVyRQ','SAJJAN NIVAS',4.3,7,'OPERATIONAL',569,'569 m away',NULL,24.5753052,73.6949435,'India','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2032,11,6,'ChIJTTe3b6vlZzkRx1UAIGT-vV4','T.S.V. Community park',3.8,5,'OPERATIONAL',570,'570 m away',1,24.5788098,73.7052847,'HPH4+G4F, College Road, Ganesh Ghati, Udaipur','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2033,11,6,'ChIJTapbHbblZzkRZA2At7t-6Ho','Sishu Niketan Park',3.5,8,'OPERATIONAL',68,'68 m away',NULL,24.5761072,73.6998274,'HMGX+CWW, Udiyapole, Udaipur','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2034,11,6,'ChIJuWrkLNHlZzkR24OhIlwXVRw','Guru Nanak Park',3.7,3,'OPERATIONAL',843,'843 m away',NULL,24.5782632,73.7084884,'HPH5+895, sikh Colony, Kumharon Ka Bhatta, Central Area, Udaipur','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2035,11,6,'ChIJPeuTYwDlZzkRNW7anGwWVkU','Nehru park',4.5,2,'OPERATIONAL',654,'654 m away',1,24.5798382,73.6955060,'HMHW+W6J, Surajpole, Nada Khada, Udaipur','[\"park\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2036,11,6,'ChIJS9YE15PlZzkRCNMcfW6qKLI','Shahid Memorial',NULL,NULL,'OPERATIONAL',752,'752 m away',0,24.5820451,73.6969636,'Shahid Memorial, Ashoka Cinema Road, Nagar Nigam, Udaipur','[\"park\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2037,11,6,'ChIJHS823fnvZzkR5nT3ziMDPWo','Saifee Bagh Khanjipeer',5.0,1,'OPERATIONAL',768,'768 m away',NULL,24.5695383,73.6981274,'627, Jawahar Nagar, Khanjipeer, Udaipur','[\"park\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:23:30','2026-05-27 21:23:30','2026-05-20 21:23:30','2026-05-20 21:23:30'),
(2038,11,7,'ChIJJSpBjNTlZzkReFYJMBJfemM','Trishula\'s Diet Clinic (TDC Udaipur) Weight Management & Nutrition Expert, Diabetic Educator',4.9,126,'OPERATIONAL',340,'340 m away',0,24.5742157,73.6978466,'55, Ganga Gali, Udaipur','[\"gym\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:23:31','2026-05-27 21:23:31','2026-05-20 21:23:31','2026-05-20 21:23:31'),
(2039,11,7,'ChIJrW9my4flZzkRcFO075w3ESE','Dynamic Yoga Studio',5.0,382,'OPERATIONAL',1109,'1.1 km away',0,24.5764775,73.7114611,'near Choudhary Offset, 68, Guru Ramdas Colony, Central Area, Udaipur','[\"gym\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:23:31','2026-05-27 21:23:31','2026-05-20 21:23:31','2026-05-20 21:23:31'),
(2040,11,7,'ChIJW6DSBg7lZzkRHPzY6b0xVQw','The Workout Wala',4.8,409,'OPERATIONAL',875,'875 m away',0,24.5784302,73.6922378,'Woodland Square, near Police Thana, Amal Ka Kanta Road, Surajpole, Udaipur','[\"gym\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:23:31','2026-05-27 21:23:31','2026-05-20 21:23:31','2026-05-20 21:23:31'),
(2041,11,7,'ChIJweGDPZ3lZzkRvLBswA5s2ts','Shwetal\'s Nirog Dham',5.0,85,'OPERATIONAL',1074,'1.1 km away',0,24.5855697,73.7025764,'152/B, Shakti Nagar Road, Shakti Nagar, Udaipur','[\"gym\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:23:31','2026-05-27 21:23:31','2026-05-20 21:23:31','2026-05-20 21:23:31'),
(2042,11,7,'ChIJDYlOsXHlZzkRifzOJTElrOA','Shanti Arogyam Yoga & Wellness Centre - Yoga Center In Udaipur / Naturopathy In Udaipur',5.0,50,'OPERATIONAL',284,'284 m away',0,24.5737837,73.6993075,'near City connect, 19-B Shivaji nagar, near City connect, Hotel Street, Udaipole, Udaipur','[\"gym\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:23:31','2026-05-27 21:23:31','2026-05-20 21:23:31','2026-05-20 21:23:31'),
(2043,11,7,'ChIJL5RRnpPlZzkRUWoLKHnguIo','FRIENDS FITNESS ZONE',4.8,51,'OPERATIONAL',508,'508 m away',1,24.5737296,73.6962111,'SarwaRitu Vilas, Swastik printers, 26, Gulab Bagh Road, Near Ice Factory, Udaipur','[\"gym\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:23:31','2026-05-27 21:23:31','2026-05-20 21:23:31','2026-05-20 21:23:31'),
(2044,11,7,'ChIJaSQiuo7lZzkREaL58EnZVKw','FIVE TOWN CLUB',4.6,158,'OPERATIONAL',1826,'1.8 km away',1,24.5810253,73.7177251,'4th Floor, Amrit Plaza, opp. B.N Girls College Gate, Sardar Patel Marg, Subhash Nagar, Udaipur','[\"gym\",\"school\",\"food\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:23:31','2026-05-27 21:23:31','2026-05-20 21:23:31','2026-05-20 21:23:31'),
(2045,11,7,'ChIJt7XRRO3lZzkR8JWb_XmYS8g','Sattva Yoga & Fitness',4.8,23,'OPERATIONAL',482,'482 m away',0,24.5755017,73.6957826,'1st Floor, Gulab Bagh Road, Udaipur','[\"gym\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:23:31','2026-05-27 21:23:31','2026-05-20 21:23:31','2026-05-20 21:23:31'),
(2046,11,7,'ChIJc5SBjH7lZzkRKNgV-UiBIWc','BodyKraft Gym',4.4,34,'OPERATIONAL',413,'413 m away',0,24.5752744,73.6965152,'4-5 Sarva Ritu Villas Behind Ice Factory, near Sagas Ji Bavji Temple','[\"gym\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:23:31','2026-05-27 21:23:31','2026-05-20 21:23:31','2026-05-20 21:23:31'),
(2047,11,7,'ChIJMeBauw7lZzkRQs4lYa6hHPA','MY HEALTHY WEALTHY STATION',4.7,15,'OPERATIONAL',837,'837 m away',0,24.5791675,73.7080618,'2nd Floor, R Kay Mall, Panchwati, Udaipur','[\"gym\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:23:31','2026-05-27 21:23:31','2026-05-20 21:23:31','2026-05-20 21:23:31'),
(2048,11,7,'ChIJoZMouavlZzkRqauzuAAQLdY','Udaipur Yoga session (For Tourists)',4.9,11,'OPERATIONAL',1940,'1.9 km away',1,24.5808113,73.6820310,'near Bagore Ki Haveli Museum, Gangaur Ghat Marg, Udaipur','[\"physiotherapist\",\"gym\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:23:31','2026-05-27 21:23:31','2026-05-20 21:23:31','2026-05-20 21:23:31'),
(2049,11,7,'ChIJBRCvoGjlZzkRfEVX0ZoylAY','Ashtang Yoga Ashram',4.3,11,'OPERATIONAL',1995,'2.0 km away',1,24.5821610,73.6819270,'35, Raiba House Inside, Chand Pole, Udaipur','[\"gym\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:23:31','2026-05-27 21:23:31','2026-05-20 21:23:31','2026-05-20 21:23:31'),
(2050,11,7,'ChIJ53-_IgvlZzkReWQEeJhHX0s','Shree Siddh Yoga School',4.5,4,'OPERATIONAL',1979,'2.0 km away',NULL,24.5934429,73.6960935,'near GBH American Hospital, 10, Bhatt ji Badi, Udaipur','[\"gym\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:23:31','2026-05-27 21:23:31','2026-05-20 21:23:31','2026-05-20 21:23:31'),
(2051,11,7,'ChIJYQ2eKI7lZzkRQuIscVjKfcc','Bym Family Spa',5.0,1,'OPERATIONAL',713,'713 m away',NULL,24.5794770,73.7064996,'54 1st Floor Khumharo Ka Batta, sikh Colony, Udaipur','[\"gym\",\"point_of_interest\",\"health\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:23:31','2026-05-27 21:23:31','2026-05-20 21:23:31','2026-05-20 21:23:31'),
(2052,11,7,'ChIJ5doOKwDvZzkRQEmITW9iDlM','Samarwal’s',NULL,NULL,'OPERATIONAL',971,'971 m away',NULL,24.5709203,73.7082354,'near rada ji temple, 04, Sharveshwar Colony Road, Tekri, Gayariawas, Central Area, Udaipur','[\"gym\",\"point_of_interest\",\"health\",\"establishment\"]',0,'unrated','2026-05-20 21:23:31','2026-05-27 21:23:31','2026-05-20 21:23:31','2026-05-20 21:23:31'),
(2053,11,8,'ChIJ1ZS7PYDvZzkRKJuoeIgSlYo','Udaipur Railway Station',4.1,154,'OPERATIONAL',579,'579 m away',NULL,24.5709370,73.6997260,'India','[\"bus_station\",\"transit_station\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:31','2026-05-27 21:23:31','2026-05-20 21:23:31','2026-05-20 21:23:31'),
(2054,11,8,'ChIJE4iCcH_lZzkRibXdNOqWS5Y','Udiapole',4.4,36,'OPERATIONAL',116,'116 m away',NULL,24.5759028,73.6993747,'India','[\"bus_station\",\"transit_station\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:31','2026-05-27 21:23:31','2026-05-20 21:23:31','2026-05-20 21:23:31'),
(2055,11,8,'ChIJG8jqwX7vZzkRPZ1yfOE-3lk','Reti Stand',4.6,7,'OPERATIONAL',931,'931 m away',NULL,24.5687070,73.7048310,'India','[\"bus_station\",\"transit_station\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:31','2026-05-27 21:23:31','2026-05-20 21:23:31','2026-05-20 21:23:31'),
(2056,11,8,'ChIJjfAZb3_lZzkRC4M48n9tpZY','Udaipur',4.0,5,'OPERATIONAL',74,'74 m away',NULL,24.5763640,73.6998320,'India','[\"bus_station\",\"transit_station\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:31','2026-05-27 21:23:31','2026-05-20 21:23:31','2026-05-20 21:23:31'),
(2057,11,8,'ChIJGyLjsZvvZzkRZ0e5Ct4eR0A','Paras Choraya',4.6,9,'OPERATIONAL',2330,'2.3 km away',NULL,24.5565190,73.6923000,'India','[\"bus_station\",\"transit_station\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:31','2026-05-27 21:23:31','2026-05-20 21:23:31','2026-05-20 21:23:31'),
(2058,11,8,'ChIJZ6Ss2WXlZzkRW_wsOqdozhc','Fatehpurachoraya',4.3,9,'OPERATIONAL',1803,'1.8 km away',NULL,24.5801600,73.6832400,'India','[\"bus_station\",\"transit_station\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:31','2026-05-27 21:23:31','2026-05-20 21:23:31','2026-05-20 21:23:31'),
(2059,11,8,'ChIJG6pEw3nlZzkRYCcHnfacmtY','Townhall, Udaipur',4.0,2,'OPERATIONAL',790,'790 m away',NULL,24.5822140,73.6965300,'India','[\"bus_station\",\"transit_station\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:23:31','2026-05-27 21:23:31','2026-05-20 21:23:31','2026-05-20 21:23:31'),
(2060,11,8,'ChIJQac0KoTlZzkRvFdtyr60cqI','Mbscience College',1.0,1,'OPERATIONAL',961,'961 m away',NULL,24.5794940,73.7092380,'India','[\"bus_station\",\"transit_station\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:23:31','2026-05-27 21:23:31','2026-05-20 21:23:31','2026-05-20 21:23:31'),
(2061,11,8,'ChIJS00eRnfvZzkReM3Pi9njWzU','Udaipole',5.0,2,'OPERATIONAL',1820,'1.8 km away',NULL,24.5604750,73.7058500,'India','[\"bus_station\",\"transit_station\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:23:31','2026-05-27 21:23:31','2026-05-20 21:23:31','2026-05-20 21:23:31'),
(2062,11,8,'ChIJCxfG92bvZzkR0dJ5vid-Iz4','Hiran Magri Sec. Petrolpump',3.0,1,'OPERATIONAL',2297,'2.3 km away',NULL,24.5662040,73.7204360,'India','[\"bus_station\",\"transit_station\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:23:31','2026-05-27 21:23:31','2026-05-20 21:23:31','2026-05-20 21:23:31'),
(2063,11,9,'ChIJTy76HYLvZzkRAw-YPnKcsP4','Udaipur City',4.4,1694,'OPERATIONAL',980,'980 m away',NULL,24.5673000,73.6998900,'8, Station Road','[\"train_station\",\"transit_station\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:32','2026-05-27 21:23:32','2026-05-20 21:23:32','2026-05-20 21:23:32'),
(2064,11,9,'ChIJo-kp6_PlZzkRV1J3BIvxpcU','Rana Pratap Nagar',4.2,414,'OPERATIONAL',2940,'2.9 km away',NULL,24.5827681,73.7286393,'Khempura, Udaipur','[\"train_station\",\"transit_station\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:23:32','2026-05-27 21:23:32','2026-05-20 21:23:32','2026-05-20 21:23:32'),
(2065,8,1,'ChIJa-CroiU7RDkRxy6IWszNFn4','Amar Hospital',4.9,44,'OPERATIONAL',37,'<50 m away',0,25.7463637,71.3974724,'opp. Railway station, 2nd floor Arihant Tower, opp. Railway station, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:47','2027-05-20 21:38:47','2026-05-20 21:38:47','2026-05-20 21:38:47'),
(2066,8,1,'ChIJbX-3KgA7RDkRJk-cVYhkOLM','Himalaya diagnostic centre',5.0,12,'OPERATIONAL',386,'386 m away',1,25.7493327,71.3987703,'P9XX+QFF, Nehru Nagar, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:47','2027-05-20 21:38:47','2026-05-20 21:38:47','2026-05-20 21:38:47'),
(2067,8,1,'ChIJx32Bm7o6RDkR-Sa4_Gw0K1o','Dr sawai singh Rathore Orthopaedic surgeon',4.4,68,'OPERATIONAL',535,'535 m away',0,25.7503999,71.3946279,'Govt.hospital barmer, campus, Gandhi Nagar, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:47','2027-05-20 21:38:47','2026-05-20 21:38:47','2026-05-20 21:38:47'),
(2068,8,1,'ChIJ6f___886RDkRu5tHCQ1-dYI','Drishti Eye & Dental Hospital Barmer',4.3,106,'OPERATIONAL',1370,'1.4 km away',0,25.7342565,71.3937017,'opposite Burning Ghat, Near Ren Basera, opposite Burning Ghat, Chohtan Road, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:47','2027-05-20 21:38:47','2026-05-20 21:38:47','2026-05-20 21:38:47'),
(2069,8,1,'ChIJf7sKOrs6RDkRpoeMpnFOVtk','Sagar Hospital Brmer',4.5,23,'OPERATIONAL',214,'214 m away',1,25.7463184,71.3950453,'P9WW+G2F, Station Road, Kothwali, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:47','2027-05-20 21:38:47','2026-05-20 21:38:47','2026-05-20 21:38:47'),
(2070,8,1,'ChIJOSSmQwA7RDkRkG7gI_N2A64','MR HOSPITAL',4.8,20,'OPERATIONAL',386,'386 m away',0,25.7493327,71.3987703,'near Himalaya diagnostic centre, Nehru Nagar, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:47','2027-05-20 21:38:47','2026-05-20 21:38:47','2026-05-20 21:38:47'),
(2071,8,1,'ChIJu2HwX2c7RDkReq7x-LZJf2k','संस्कार पंचकर्मा हॉस्पिटल एण्ड लेबोरेट्री SANSKAR AAYURVED PANCHAKARM HOSPITAL',5.0,5,'OPERATIONAL',351,'351 m away',0,25.7490016,71.3987267,'Nehru Nagar, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:47','2027-05-20 21:38:47','2026-05-20 21:38:47','2026-05-20 21:38:47'),
(2072,8,1,'ChIJyzN395M6RDkRAoR5PG5XVNY','THAR HOSPITAL & MULTISPECIALITY CENTRE BARMER',3.8,189,'OPERATIONAL',1540,'1.5 km away',1,25.7327616,71.4010470,'near Hotel Kailash International, NH-15,, near Hotel Kailash International, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:47','2027-05-20 21:38:47','2026-05-20 21:38:47','2026-05-20 21:38:47'),
(2073,8,1,'ChIJtzEjLr06RDkRm4Fp3ZiXuAA','Matru Dental Clinic and Physiotherapy Center',4.1,13,'OPERATIONAL',637,'637 m away',NULL,25.7408430,71.3948417,'P9RV+8WP, Krishi Mandi Road, Kalyanpura, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:47','2027-05-20 21:38:47','2026-05-20 21:38:47','2026-05-20 21:38:47'),
(2074,8,1,'ChIJcWSSCQA7RDkRAl-Q-J6WBiw','Sagar Medicose',NULL,NULL,'OPERATIONAL',213,'213 m away',NULL,25.7463148,71.3950580,'P9WW+G2F, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:38:47','2027-05-20 21:38:47','2026-05-20 21:38:47','2026-05-20 21:38:47'),
(2075,8,1,'ChIJVSSvkro6RDkR_VvEkbMTOMg','Choudary Medicose',NULL,NULL,'OPERATIONAL',314,'314 m away',NULL,25.7489276,71.3965124,'P9XW+HJC, Railway Colony, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:38:47','2027-05-20 21:38:47','2026-05-20 21:38:47','2026-05-20 21:38:47'),
(2076,8,1,'ChIJ69mRMgA7RDkROEE_q6jtObY','Tarun medicals',NULL,NULL,'OPERATIONAL',316,'316 m away',NULL,25.7489521,71.3965141,'Shop Number-33, Bal Mandir school road, kishan Boarding, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:38:47','2027-05-20 21:38:47','2026-05-20 21:38:47','2026-05-20 21:38:47'),
(2077,8,1,'ChIJveNA4yI7RDkR4i88IbvwEdY','Dr Raj Kishor Mahesweri Child Doctor',3.4,5,'OPERATIONAL',326,'326 m away',NULL,25.7446562,71.3943870,'P9VV+VQ6, Mal Godawn Road, Kothwali, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:38:47','2027-05-20 21:38:47','2026-05-20 21:38:47','2026-05-20 21:38:47'),
(2078,8,1,'ChIJO4hk3GA7RDkR5OTIxDH9tH8','Hitkari madicos Barmar Govt.hospital',NULL,NULL,'OPERATIONAL',387,'387 m away',NULL,25.7496010,71.3978381,'P9XX+R4W, Nehru Nagar, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:38:47','2027-05-20 21:38:47','2026-05-20 21:38:47','2026-05-20 21:38:47'),
(2079,8,1,'ChIJ2awXNCo7RDkRGlrF4F2uUbY','Dhanwantari Homeopathy Clinic',5.0,2,'OPERATIONAL',390,'390 m away',NULL,25.7481386,71.3939526,'Dr Gopal Singh Jodha, MBC Girls College, School Rd, Laxmipura, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:38:47','2027-05-20 21:38:47','2026-05-20 21:38:47','2026-05-20 21:38:47'),
(2080,8,2,'ChIJm1_X11E7RDkR_izJddiniM4','तुलसाणीयों की ढाणी (उण्डखा)',NULL,NULL,'OPERATIONAL',37,'<50 m away',NULL,25.7463637,71.3974814,'तुलसाणीयों की ढाणी, उन्ड्खा','[\"primary_school\",\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2081,8,2,'ChIJQbMENAA7RDkRl4xa90b7c1I','Govt Railway Colony School Barmer',NULL,NULL,'OPERATIONAL',185,'185 m away',NULL,25.7451461,71.3986381,'P9WX+3F2, Railway Colony, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2082,8,2,'ChIJOUASqO47RDkRyqZafE0IFEM','Mahatma Gandhi Government English Medium School Station Road Barmer',NULL,NULL,'CLOSED_TEMPORARILY',241,'241 m away',NULL,25.7470797,71.3949973,'behind Palika Bazaar, High School Road, Kothwali, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2083,8,2,'ChIJR_Nv17o6RDkRgwCU1FgcY_M','हाई स्कूल बाड़मेर',NULL,NULL,'OPERATIONAL',266,'266 m away',NULL,25.7475368,71.3950019,'P9XW+226, Railway Colony, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2084,8,2,'ChIJZYNB17o6RDkRqhaH5LTsT-0','GOVERNMENT Senior Secondary SCHOOL',NULL,NULL,'OPERATIONAL',268,'268 m away',0,25.7475430,71.3949829,'P9XV+2X9, Station Road, Kothwali, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2085,8,2,'ChIJK5GeUFU7RDkRYSmXfNSbdIY','Govt senior secondary school Barmer near maalgodham road',NULL,NULL,'OPERATIONAL',330,'330 m away',0,25.7444859,71.3944635,'P9VV+QQW, Mal Godawn Road, Kothwali, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2086,8,2,'ChIJ4ZUblro6RDkRxnnkhZ59nio','Bal Mandir School, Barmer',NULL,NULL,'OPERATIONAL',348,'348 m away',0,25.7490696,71.3958621,'P9XW+J8H, High School Road, Railway Colony, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2087,8,2,'ChIJDZINLR47RDkR6Wkg-vAbnq4','Government School No.- 1 Barmer',NULL,NULL,'OPERATIONAL',383,'383 m away',NULL,25.7440481,71.3941658,'Kothwali, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2088,8,2,'ChIJge4r7go7RDkRmYNLIqDom6Y','Antari Devi Girl\'s Sen. Seconder School Barmer',NULL,NULL,'OPERATIONAL',471,'471 m away',0,25.7495565,71.3943559,'MBC Girls College, near, Laxmipura, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2089,8,2,'ChIJyeP1PXQ_RDkR0GkZ7pts6qE','GOVT. SENIOR SECONDARY SCHOOL SUTHARO KA TALA MITHADA,BARMER',NULL,NULL,'OPERATIONAL',479,'479 m away',0,25.7503070,71.3958309,'Q92W+48G, Unnamed Road, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2090,8,2,'ChIJ925GJr47RDkRbh7YHgSfMfg','पावड़ो की ढाणी',NULL,NULL,'OPERATIONAL',505,'505 m away',NULL,25.7506526,71.3963998,'Q92W+7H6, बामरला, बाड़मेर','[\"primary_school\",\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2091,8,2,'ChIJq0QB3aI6RDkR4SOQbn3w0CA','aasha children kingd',NULL,NULL,'CLOSED_TEMPORARILY',731,'731 m away',NULL,25.7407831,71.3929883,'P9RV+859, Kalyanpura, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2092,8,2,'ChIJidcJf7c6RDkRrHX-kXFynJ4','Ramubai Ganesh Mal Golechha, Govt. Secondary School',NULL,NULL,'OPERATIONAL',818,'818 m away',NULL,25.7512797,71.4030485,'QC23+G67, Adarsh Stadium Road, Nehru Nagar, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2093,8,2,'ChIJ23kPSus6RDkRPg1bPskwCXE','Shri kisan kesari Senior Secondary School',NULL,NULL,'OPERATIONAL',1450,'1.5 km away',0,25.7363627,71.4067257,'शास्त्री नगर NH-15, सदर थाने के पीछे, जाट कालोनी,बाड़मेर, 8, Dangriya, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2094,8,2,'ChIJpcx9xak6RDkRwPtlayf3DpY','Govt. Senior Secondary School Railway Kunwa No. 3',NULL,NULL,'CLOSED_TEMPORARILY',1535,'1.5 km away',NULL,25.7521364,71.3833556,'Railway kunwa, no 3, Gehoon Road, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2095,8,3,'ChIJ87dpM6I7RDkRlnIUtGexXXs','Thar books cafe',4.4,153,'OPERATIONAL',149,'149 m away',0,25.7463502,71.3957027,'3rd floor, Bhagwati complex, Station Road, Barmer','[\"cafe\",\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2096,8,3,'ChIJ0yacMLs6RDkRA4_2wsRlGpE','Hotel Kalinga Palace',4.0,1443,'OPERATIONAL',178,'178 m away',1,25.7462020,71.3954020,'Rly. Station, opposite Barmer, Station Road, Barmer','[\"bar\",\"lodging\",\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2097,8,3,'ChIJbzuolvw7RDkRPjeM6LoW6aM','श्री खेतेश्वर नास्ता हाउस',4.8,58,'OPERATIONAL',210,'210 m away',0,25.7443660,71.3965442,'P9VW+PJV, Unnamed Road, Kothwali, Barmer','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2098,8,3,'ChIJpbE7X6U6RDkREmi_3vFcKqM','Laziz Pizza',3.9,812,'OPERATIONAL',559,'559 m away',0,25.7497397,71.3932460,'Shop No. 1,2 and 3, girls college road Vishwakarma circle, Ray Colony, Barmer','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2099,8,3,'ChIJo4_rfLs6RDkRT5DtYWVeam8','AMBER HOTEL & RESTAURANTS',3.8,92,'OPERATIONAL',199,'199 m away',NULL,25.7445133,71.3964376,'P9VW+RH4, near LAXMI CINEMA, Station Road, Kothwali, Barmer','[\"lodging\",\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2100,8,3,'ChIJodUOq9o7RDkR_8_4oUyrQ4g','The Vip Express Restaurant || Best Restaurant, Cafe, Fast Food Restaurant',3.9,72,'OPERATIONAL',77,'77 m away',0,25.7454916,71.3970226,'North Western Railway Line, Barmer','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2101,8,3,'ChIJD3bE_tA7RDkRXKdRHEgwQzw','Raj Restaurant And Palace',3.7,66,'OPERATIONAL',122,'122 m away',0,25.7459265,71.3959888,'P9WW+99H, Kothwali, Barmer','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2102,8,3,'ChIJUS8-Ls87RDkRjFiiPHxynCs','Raj palace Hotel & Restaurant',4.5,13,'OPERATIONAL',155,'155 m away',NULL,25.7459237,71.3956548,'Station Road, Barmer','[\"lodging\",\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2103,8,3,'ChIJb0DCNuU7RDkR5A22yane_eE','Rail Restaurant',4.1,35,'OPERATIONAL',90,'90 m away',0,25.7453613,71.3971506,'P9WW+4PP, Kothwali, Barmer','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2104,8,3,'ChIJ7WJuFbs6RDkRQEguKcNDvuY','Kailash White International',4.4,15,'OPERATIONAL',117,'117 m away',0,25.7461001,71.3960068,'P9WW+CCR, Station Road, Kothwali, Barmer','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2105,8,3,'ChIJKcWRZFE7RDkRx0C8C675mXw','Vibes cafe',4.0,30,'OPERATIONAL',147,'147 m away',0,25.7469052,71.3959541,'P9WW+Q98, Barmer','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2106,8,3,'ChIJOblC-s46RDkR2j6i9vb7j74','K K Hotel',3.9,110,'OPERATIONAL',2165,'2.2 km away',NULL,25.7572657,71.4149466,'National Highway 68, Mahaveer Nagar, Barmer','[\"lodging\",\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2107,8,3,'ChIJWeq9MgA7RDkRjjeMSA0Qle4','Jay Bhavani Vadapav',4.2,5,'OPERATIONAL',96,'96 m away',NULL,25.7453192,71.3970085,'RAILWAY STATION, Barmer','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2108,8,3,'ChIJfS2zFAA7RDkR2zT6y11AcZw','Madam D\'Souza',3.5,6,'OPERATIONAL',83,'83 m away',NULL,25.7454334,71.3970360,'P9WW+5RF, North Western Railway Line, Nehru Nagar, Barmer','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2109,8,3,'ChIJvbu9VY47RDkR3AstQrMd4Lw','JANTA SHWET',3.3,3,'OPERATIONAL',63,'63 m away',NULL,25.7458923,71.3966237,'Ke Samne, Janta Shwet, Railway Station, Nehru Nagar, Barmer','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:38:48','2026-05-27 21:38:48','2026-05-20 21:38:48','2026-05-20 21:38:48'),
(2110,8,4,'ChIJVfEPba86RDkRTmzZct3vSIA','Axis Bank Branch',4.2,53,'OPERATIONAL',668,'668 m away',0,25.7516068,71.3943346,'Goswami Tower, Rai Colony Road, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:49','2026-05-27 21:38:49','2026-05-20 21:38:49','2026-05-20 21:38:49'),
(2111,8,4,'ChIJ7wKwU6I6RDkRHQN_Ofsw1t0','SBI Branch Barmer',3.9,69,'OPERATIONAL',1120,'1.1 km away',0,25.7376800,71.3911580,'Ci, Pratap Ji Ki Pole, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:49','2026-05-27 21:38:49','2026-05-20 21:38:49','2026-05-20 21:38:49'),
(2112,8,4,'ChIJ93o73q86RDkRmEBX_ZBAMIU','Union Bank of India',3.9,53,'OPERATIONAL',663,'663 m away',0,25.7514700,71.3941380,'Ward No-3, Barmer Main Laxmipura, Road, Ray Colony, Barmer','[\"bank\",\"atm\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:49','2026-05-27 21:38:49','2026-05-20 21:38:49','2026-05-20 21:38:49'),
(2113,8,4,'ChIJ0aDYF6g6RDkRaYmbReSwbyY','Kotak Mahindra Bank',3.7,49,'OPERATIONAL',654,'654 m away',0,25.7515208,71.3944753,'Dev Tower\",Laxmi Nagar, Road, Main, Ray Colony, Barmer','[\"bank\",\"insurance_agency\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:49','2026-05-27 21:38:49','2026-05-20 21:38:49','2026-05-20 21:38:49'),
(2114,8,4,'ChIJxQJeX6Q6RDkRNx-ELk166hE','SBI Bank',4.2,32,'OPERATIONAL',1173,'1.2 km away',0,25.7416164,71.4077451,'SH 40, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:49','2026-05-27 21:38:49','2026-05-20 21:38:49','2026-05-20 21:38:49'),
(2115,8,4,'ChIJO8ayiqQ6RDkRohxy3CfNtfw','Bank of Baroda',3.9,28,'OPERATIONAL',728,'728 m away',0,25.7449727,71.3900321,'Barmer, SH-112, Barmer Road, Barmer, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:49','2026-05-27 21:38:49','2026-05-20 21:38:49','2026-05-20 21:38:49'),
(2116,8,4,'ChIJgxIwbKQ6RDkRamWVTb2GLWw','ICICI Bank Gandhi Chowk, Barmer-Branch & ATM',4.0,14,'OPERATIONAL',738,'738 m away',0,25.7451008,71.3899053,'Gandhi Chowk, 0, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:49','2026-05-27 21:38:49','2026-05-20 21:38:49','2026-05-20 21:38:49'),
(2117,8,4,'ChIJ4a14L8Q6RDkR0waChtxchbA','UCO Bank',3.8,36,'OPERATIONAL',1569,'1.6 km away',0,25.7487178,71.4125892,'Barmer, NH-15, Barmer Road, Barmer, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:49','2026-05-27 21:38:49','2026-05-20 21:38:49','2026-05-20 21:38:49'),
(2118,8,4,'ChIJ03xM5ZA6RDkR_GYC8RE6ov4','M B Finance',4.3,3,'OPERATIONAL',1637,'1.6 km away',0,25.7314490,71.3969520,'P9JW+HQG, Near truck Union, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:49','2026-05-27 21:38:49','2026-05-20 21:38:49','2026-05-20 21:38:49'),
(2119,8,4,'ChIJ29UtZM86RDkRkJlDbjItj9Y','Axis Bank ATM',3.8,5,'OPERATIONAL',1802,'1.8 km away',1,25.7519813,71.4139734,'Goswami Tower, Road, Ray Colony, Barmer','[\"atm\",\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:49','2026-05-27 21:38:49','2026-05-20 21:38:49','2026-05-20 21:38:49'),
(2120,8,4,'ChIJUbJaaKQ6RDkRdBrwu1erllg','IDBI Bank',3.9,27,'CLOSED_TEMPORARILY',721,'721 m away',NULL,25.7451469,71.3900667,'Arihant Tower Opp Customs Check Post, Station Road, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:49','2026-05-27 21:38:49','2026-05-20 21:38:49','2026-05-20 21:38:49'),
(2121,8,4,'ChIJD8ed4K86RDkRdleaErAwzBI','CENTRAL BANK OF INDIA - BARMER Branch',3.7,18,'OPERATIONAL',1563,'1.6 km away',0,25.7485863,71.4125490,'near ahaar bojanalay, Chindru churaiya, near ahaar bojanalay, Krishi Mandi Road, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:49','2026-05-27 21:38:49','2026-05-20 21:38:49','2026-05-20 21:38:49'),
(2122,8,4,'ChIJn6qqatZoaTkRRYykhkQfm-0','ICICI Bank Ltd.,Barmer-Gandhi chowk',2.2,6,'OPERATIONAL',798,'798 m away',0,25.7449403,71.3893260,'ICICI Bank Ltd., Gandhi Chowk,Barmer - 344001 #VALUE!, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:38:49','2026-05-27 21:38:49','2026-05-20 21:38:49','2026-05-20 21:38:49'),
(2123,8,4,'ChIJkS8pKZg6RDkRCCfLpltASsk','Dena Bank',2.2,19,'OPERATIONAL',1151,'1.2 km away',0,25.7362357,71.3939553,'P9PV+FHW, opp. INDIAN OIL PETROL PUMP, Chohtan Road, Barmer','[\"bank\",\"atm\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:38:49','2026-05-27 21:38:49','2026-05-20 21:38:49','2026-05-20 21:38:49'),
(2124,8,5,'ChIJXWMQY2M7RDkR1lFEBlbXWUI','Balaji handloom',4.6,24,'OPERATIONAL',359,'359 m away',0,25.7453488,71.3937109,'opposite kailash sarover hotel, Station Road, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:49','2026-05-27 21:38:49','2026-05-20 21:38:49','2026-05-20 21:38:49'),
(2125,8,5,'ChIJq6qq6qw6RDkRn-TBS9mpBck','Jasnath Provision & Kirana Store Barmer',4.1,84,'OPERATIONAL',1736,'1.7 km away',0,25.7601101,71.3893627,'Q96Q+2PW, Indra Nagar, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:49','2026-05-27 21:38:49','2026-05-20 21:38:49','2026-05-20 21:38:49'),
(2126,8,5,'ChIJnxoTe5Q6RDkRPt8rJa3lnTQ','Jansukh Cart',5.0,4,'OPERATIONAL',1336,'1.3 km away',0,25.7345456,71.4005388,'opp. Thar Hospital, H.NO. 48 NH 68, opp. Thar Hospital, Shastri Nagar, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:49','2026-05-27 21:38:49','2026-05-20 21:38:49','2026-05-20 21:38:49'),
(2127,8,5,'ChIJiSLr7FA7RDkRAL0Tgw_xA0A','Karni Kirana Store',4.8,6,'OPERATIONAL',1234,'1.2 km away',NULL,25.7572651,71.3969238,'34, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:49','2026-05-27 21:38:49','2026-05-20 21:38:49','2026-05-20 21:38:49'),
(2128,8,5,'ChIJAQcl9MY6RDkRHB12W5pwSpw','Ramesh Traders Barmer',4.5,15,'OPERATIONAL',1355,'1.4 km away',0,25.7490776,71.4103203,'PCX6+J4P, Nehru Nagar, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:49','2026-05-27 21:38:49','2026-05-20 21:38:49','2026-05-20 21:38:49'),
(2129,8,5,'ChIJe22JrMg7RDkRv_xJEjUEnXw','MAA KUBRAD EMITRA AND DJ SOUND BARMER PRO. KISHAN LAL MANSURIYA',4.2,9,'OPERATIONAL',1837,'1.8 km away',0,25.7426274,71.4150904,'Kudla Road, Baba Ramdev Nagar, RICCO Housing Colony, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:49','2026-05-27 21:38:49','2026-05-20 21:38:49','2026-05-20 21:38:49'),
(2130,8,5,'ChIJq6qq6qw6RDkRb1w7yE18Phg','Bhagwati Hinglaj Provision',3.7,3,'OPERATIONAL',1738,'1.7 km away',0,25.7602373,71.3896045,'Q96Q+3RX, Indra Nagar, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:49','2026-05-27 21:38:49','2026-05-20 21:38:49','2026-05-20 21:38:49'),
(2131,8,5,'ChIJAYMr86Q6RDkRFvFS_8uJ0Os','SHIV GENERAL STORE',5.0,1,'OPERATIONAL',537,'537 m away',0,25.7454512,71.3918801,'mukand ji mandir, Near, Station Road, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:38:49','2026-05-27 21:38:49','2026-05-20 21:38:49','2026-05-20 21:38:49'),
(2132,8,5,'ChIJHdX5dcw7RDkR2W6WxgXAlQ0','Vishal Mega Mart',3.1,33,'OPERATIONAL',1725,'1.7 km away',0,25.7307590,71.3951810,'near Chohtan Road, Barmer - Munabao Road, Choraha, Vishnu Colony, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:38:49','2026-05-27 21:38:49','2026-05-20 21:38:49','2026-05-20 21:38:49'),
(2133,8,5,'ChIJofjJlDE7RDkRoN_IZOh4kvo','Shyam Lal Sharma',NULL,NULL,'OPERATIONAL',1799,'1.8 km away',NULL,25.7522373,71.4138254,'Shyam Lal Sharma, Mahaveer Nagar, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:38:49','2026-05-27 21:38:49','2026-05-20 21:38:49','2026-05-20 21:38:49'),
(2134,8,5,'ChIJzaX-uWw7RDkRhVdIxEk0oNc','Maa Jagtdmba Fruit Bhndar',NULL,NULL,'OPERATIONAL',1815,'1.8 km away',NULL,25.7523913,71.4139340,'16, Sindhary Choraha','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:38:49','2026-05-27 21:38:49','2026-05-20 21:38:49','2026-05-20 21:38:49'),
(2135,8,6,'ChIJsa3eXwA7RDkRVlLxfZMQu_w','भामाशाह लीलाराम जांगिड़ स्मृति पार्क',4.5,112,'OPERATIONAL',713,'713 m away',0,25.7398429,71.3983323,'1424, Krishi Mandi Road, Shastri Nagar, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:50','2026-05-27 21:38:50','2026-05-20 21:38:50','2026-05-20 21:38:50'),
(2136,8,6,'ChIJ_eUR7a07RDkRy1kF_2i9RAU','Mahaveer Park',4.2,103,'OPERATIONAL',710,'710 m away',NULL,25.7525125,71.3979844,'Madhuban Colony, P S Parisar Colony, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:50','2026-05-27 21:38:50','2026-05-20 21:38:50','2026-05-20 21:38:50'),
(2137,8,6,'ChIJ8eEWsbc6RDkRlevOoZ_Z6Vk','Mahaveer Park',4.2,863,'OPERATIONAL',1152,'1.2 km away',0,25.7541835,71.4044612,'QC33+MQG, Nehru Nagar, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:50','2026-05-27 21:38:50','2026-05-20 21:38:50','2026-05-20 21:38:50'),
(2138,8,6,'ChIJ9c7FRzw7RDkRjWNdGjSen_M','Township Park',4.8,5,'OPERATIONAL',1907,'1.9 km away',1,25.7310925,71.4062549,'PCJ4+CGJ, Dangriya, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:50','2026-05-27 21:38:50','2026-05-20 21:38:50','2026-05-20 21:38:50'),
(2139,8,6,'ChIJGd9N35s7RDkRp-_jpfDrvvs','Lt General Hanut Singh PVSM Mahavir Chakra Park',4.4,21,'OPERATIONAL',1852,'1.9 km away',1,25.7561273,71.4120022,'900/6, Ambedkar Colony, Mahaveer Nagar, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:50','2026-05-27 21:38:50','2026-05-20 21:38:50','2026-05-20 21:38:50'),
(2140,8,6,'ChIJ6dYbGOk7RDkRcmz917gO-2o','ओपन एयर जिम (आदर्श स्टेडियम), बाड़मेर',4.4,11,'OPERATIONAL',1153,'1.2 km away',NULL,25.7545544,71.4039465,'QC33+XR3, Ambedkar Colony, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:50','2026-05-27 21:38:50','2026-05-20 21:38:50','2026-05-20 21:38:50'),
(2141,8,6,'ChIJOcXekaA6RDkRa7Ohy8sRpGc','Son Naadi Park',4.1,29,'OPERATIONAL',1501,'1.5 km away',NULL,25.7407728,71.3834380,'P9RM+894, Venasar Naadi, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:50','2026-05-27 21:38:50','2026-05-20 21:38:50','2026-05-20 21:38:50'),
(2142,8,6,'ChIJPayqnj07RDkRdSlE3J7aCSc','आयुष्मान भारत सूर्यनमस्कार प्रतीक',NULL,NULL,'OPERATIONAL',535,'535 m away',NULL,25.7509766,71.3969922,'new, hanuwant school road, Derasar','[\"park\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:38:50','2026-05-27 21:38:50','2026-05-20 21:38:50','2026-05-20 21:38:50'),
(2143,8,6,'ChIJN_1YDAA7RDkROhdU2EU7NHo','Ugararam Rathore Rana',NULL,NULL,'OPERATIONAL',666,'666 m away',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:38:50','2026-05-27 21:38:50','2026-05-20 21:38:50','2026-05-20 21:38:50'),
(2144,8,6,'ChIJ6dEwbQA7RDkRMSheyro4FmE','Magraj beniwal',NULL,NULL,'OPERATIONAL',666,'666 m away',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:38:50','2026-05-27 21:38:50','2026-05-20 21:38:50','2026-05-20 21:38:50'),
(2145,8,6,'ChIJx-4CLwA7RDkRhTTjF4jEZeE','I LOVE BARMER',5.0,2,'OPERATIONAL',742,'742 m away',NULL,25.7527676,71.3983082,'Q93X+483, P S Parisar Colony, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:38:50','2026-05-27 21:38:50','2026-05-20 21:38:50','2026-05-20 21:38:50'),
(2146,8,6,'ChIJ____5LA6RDkRoac5qE405Fs','Public Park',NULL,NULL,'OPERATIONAL',751,'751 m away',NULL,25.7528555,71.3982092,'Q93X+47W, Madhuban Colony, P S Parisar Colony, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:38:50','2026-05-27 21:38:50','2026-05-20 21:38:50','2026-05-20 21:38:50'),
(2147,8,6,'ChIJI11QRgA7RDkR4x8fEF0yheI','Vaga ram ji moodh',NULL,NULL,'OPERATIONAL',1628,'1.6 km away',NULL,25.7322031,71.4020560,'PCJ2+VRM, धनु','[\"park\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:38:50','2026-05-27 21:38:50','2026-05-20 21:38:50','2026-05-20 21:38:50'),
(2148,8,6,'ChIJ6SqFgyQ7RDkRWopdDBXTbFA','Choudhary park jatt collony',5.0,1,'OPERATIONAL',1632,'1.6 km away',1,25.7351767,71.4079683,'PCP5+35G, जाट कॉलोनी, बाड़मेर','[\"park\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:38:50','2026-05-27 21:38:50','2026-05-20 21:38:50','2026-05-20 21:38:50'),
(2149,8,6,'ChIJT6niBLo7RDkRFXPQp2caQPo','Barmer pradrsini park',3.0,5,'OPERATIONAL',1891,'1.9 km away',NULL,25.7522847,71.4147956,'QC27+WW7, Baldev Nagar, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:38:50','2026-05-27 21:38:50','2026-05-20 21:38:50','2026-05-20 21:38:50'),
(2150,8,7,'ChIJvSfDPwA7RDkRq6lhDq5GuH8','Revital Zone Gym',4.9,128,'OPERATIONAL',670,'670 m away',0,25.7470827,71.3905612,'258/6, Harijan Basti, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:50','2026-05-27 21:38:50','2026-05-20 21:38:50','2026-05-20 21:38:50'),
(2151,8,7,'ChIJx00eWLc7RDkROGcSFPmaZvc','M S SODHA GYM',4.5,159,'OPERATIONAL',142,'142 m away',0,25.7461203,71.3957650,'5th Floor, Bhagwati Complex, Station Road, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:50','2026-05-27 21:38:50','2026-05-20 21:38:50','2026-05-20 21:38:50'),
(2152,8,7,'ChIJKX1nBPs7RDkR3_dBhXBNAic','ShreeRam GYM - Gym & Fitness Centre',4.9,469,'OPERATIONAL',1780,'1.8 km away',0,25.7551479,71.4118882,'Second Floor, City Centre, Mahaveer Nagar, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:50','2026-05-27 21:38:50','2026-05-20 21:38:50','2026-05-20 21:38:50'),
(2153,8,7,'ChIJT91d5uo6RDkR6D3b5N24r0Y','KDM GYM',4.5,330,'OPERATIONAL',1433,'1.4 km away',0,25.7379877,71.4082267,'Sodha Form house, near St. Paul\'s School, Shivkar Road, Dangriya, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:50','2026-05-27 21:38:50','2026-05-20 21:38:50','2026-05-20 21:38:50'),
(2154,8,7,'ChIJ3f8AFSA7RDkREp-aCQEpFFU','Joggers Fitness Club And Gym Barmer',4.6,67,'OPERATIONAL',1653,'1.7 km away',0,25.7314928,71.3945461,'Joggers Fitness club, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:50','2026-05-27 21:38:50','2026-05-20 21:38:50','2026-05-20 21:38:50'),
(2155,8,7,'ChIJD-QuhgI7RDkRQSAv_kcxWNs','VIP Gym',4.0,52,'OPERATIONAL',687,'687 m away',0,25.7518161,71.3943939,'Q92V+PQC, Laxmi Nagar, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:50','2026-05-27 21:38:50','2026-05-20 21:38:50','2026-05-20 21:38:50'),
(2156,8,7,'ChIJv7C65ho7RDkR6chaDoKrl-s','Nehru Yuva Kendra Gym, Barmer',4.8,4,'OPERATIONAL',893,'893 m away',0,25.7539764,71.3992490,'Q93X+HMX, Madhuban Colony, P S Parisar Colony, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:50','2026-05-27 21:38:50','2026-05-20 21:38:50','2026-05-20 21:38:50'),
(2157,8,7,'ChIJXS5-seM7RDkRQM0VdPoRxik','The fitness zone',4.2,52,'OPERATIONAL',1320,'1.3 km away',0,25.7353759,71.3916828,'Partap Ji Ki Prol Road, Pratap Ji Ki Pole, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:50','2026-05-27 21:38:50','2026-05-20 21:38:50','2026-05-20 21:38:50'),
(2158,8,7,'ChIJnbeOBIo7RDkR7mPazcsEu14','Vicky health & nutrition centre',4.0,8,'OPERATIONAL',737,'737 m away',0,25.7396755,71.3956955,'NEAR THAR GAS AGENCY, CO-OPERATIVE MARKETING SOCIETY, SHOP NO 12, FIRST FLOOR, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:50','2026-05-27 21:38:50','2026-05-20 21:38:50','2026-05-20 21:38:50'),
(2159,8,7,'ChIJbclBMgA7RDkR6dFzaibUY5c','HEALTH AND FITNESS CENTER BARMER',5.0,1,'OPERATIONAL',151,'151 m away',0,25.7460474,71.3956744,'SHOP No.- 408, 4TH FLOOR, BHAGATI COMPLEX, Railway, स्टेशन मार्ग, बाड़मेर','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:38:50','2026-05-27 21:38:50','2026-05-20 21:38:50','2026-05-20 21:38:50'),
(2160,8,7,'ChIJB2-zVgA7RDkRMZc-BcRwHEU','खोडाल',NULL,NULL,'CLOSED_TEMPORARILY',666,'666 m away',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:38:50','2026-05-27 21:38:50','2026-05-20 21:38:50','2026-05-20 21:38:50'),
(2161,8,7,'ChIJz2bCWwA7RDkRjR49MLZTDrQ','EX.Hari Singh Bhati ka vaas',NULL,NULL,'CLOSED_TEMPORARILY',666,'666 m away',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:38:50','2026-05-27 21:38:50','2026-05-20 21:38:50','2026-05-20 21:38:50'),
(2162,8,7,'ChIJd3WiFuI7RDkRPtLnZElocBY','Revital Store : Buy Branded Supplements & Nutrition Products At Best Price & 100% Genuine In Barmer',5.0,2,'OPERATIONAL',766,'766 m away',0,25.7491806,71.3902956,'in front of Rai Colony School, Panch Batti Cricle, Barmer','[\"gym\",\"food\",\"store\",\"health\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:38:50','2026-05-27 21:38:50','2026-05-20 21:38:50','2026-05-20 21:38:50'),
(2163,8,9,'ChIJ12Xvn7s6RDkRjUud9Q7F_HM','Barmer',4.4,1882,'OPERATIONAL',41,'<50 m away',NULL,25.7463500,71.3975400,'Station Road, Nehru Nagar, Barmer','[\"train_station\",\"transit_station\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:38:51','2026-05-27 21:38:51','2026-05-20 21:38:51','2026-05-20 21:38:51'),
(2164,12,1,'ChIJTxcrQiY7RDkRi4D_5EOaZxA','Dr. Rakesh Pannu',5.0,20,'OPERATIONAL',157,'157 m away',1,25.7516518,71.3952229,'Quarter no. 22, near govt hospital, road, Ray Colony, Barmer','[\"hospital\",\"doctor\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:45:27','2027-05-20 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2165,12,1,'ChIJx32Bm7o6RDkR-Sa4_Gw0K1o','Dr sawai singh Rathore Orthopaedic surgeon',4.4,68,'OPERATIONAL',283,'283 m away',0,25.7503999,71.3946279,'Govt.hospital barmer, campus, Gandhi Nagar, Barmer','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:45:27','2027-05-20 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2166,12,1,'ChIJ5ZHDJrA6RDkRI3Lc4EShIq8','SAPP Medilab',4.9,13,'OPERATIONAL',203,'203 m away',0,25.7518702,71.3946800,'Hotel Desert Inn, opp. CMHO office, near Bank of Maharashtra, road, Ray Colony, Barmer','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:45:27','2027-05-20 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2167,12,1,'ChIJjf_eis46RDkRf3vcBzIcKMQ','Balaji Hospital',4.4,38,'OPERATIONAL',1907,'1.9 km away',0,25.7571743,71.4148873,'15, National Highway, Ambedkar Colony, Mahaveer Nagar, Barmer','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:45:27','2027-05-20 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2168,12,1,'ChIJtzEjLr06RDkRm4Fp3ZiXuAA','Matru Dental Clinic and Physiotherapy Center',4.1,13,'OPERATIONAL',1270,'1.3 km away',NULL,25.7408430,71.3948417,'P9RV+8WP, Krishi Mandi Road, Kalyanpura, Barmer','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:45:27','2027-05-20 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2169,12,1,'ChIJRbJPfrA6RDkRR2HilYKYEs0','Lucky Lab',3.7,3,'OPERATIONAL',179,'179 m away',0,25.7506014,71.3971713,'Jodhpur - Barmer Road, Vivekanand Nagar, Nehru Nagar, Barmer','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:45:27','2027-05-20 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2170,12,1,'ChIJ3fN8Bco5RDkRZvbJuxihaAE','Martala Gala Barmer',3.8,11,'OPERATIONAL',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:45:27','2027-05-20 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2171,12,1,'ChIJfWY8BiE7RDkR1IUtO2Okadk','National medical store',NULL,NULL,'OPERATIONAL',0,'Distance unavailable',0,25.7521467,71.3966865,'National medical store, Agasdi, Barmer','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:45:27','2027-05-20 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2172,12,1,'ChIJn15vrRs7RDkR3jbokMDwSPQ','Dr aaysha Choudhary',5.0,1,'OPERATIONAL',0,'Distance unavailable',0,25.7521467,71.3966865,'जनना विंग के पीछे क्वार्टर में, राजकिय अस्पताल कैम्पस क्वार्टर बाड़मेर BB 76, III 49 C राजकीय अस्पताल, Barmer','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:45:27','2027-05-20 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2173,12,1,'ChIJeXo0ZwA7RDkRTfuno-EAZWY','सडैचा',NULL,NULL,'OPERATIONAL',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:45:27','2027-05-20 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2174,12,1,'ChIJfbwreAA7RDkRroCLD8whaFY','Gefra राम devasi',NULL,NULL,'OPERATIONAL',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:45:27','2027-05-20 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2175,12,1,'ChIJP6d7eQA7RDkROh-4stnY3ro','Raju bhandari (majisha medical Store)',NULL,NULL,'OPERATIONAL',2,'<50 m away',NULL,25.7521328,71.3966858,'Q92W+VM3, Barmer','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:45:27','2027-05-20 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2176,12,1,'ChIJUd1GdAA7RDkRIX4wwqCH9Nw','Aainath Hospital',NULL,NULL,'OPERATIONAL',186,'186 m away',1,25.7506175,71.3974287,'Q92W+6XV, Nehru Nagar, Barmer','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',0,'unrated','2026-05-20 21:45:27','2027-05-20 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2177,12,1,'ChIJS5LOTwA7RDkRA9YNWHVKveo','Ambulance stand',NULL,NULL,'OPERATIONAL',187,'187 m away',NULL,25.7504687,71.3967028,'Q92W+5MP, Railway Colony, Barmer','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',0,'unrated','2026-05-20 21:45:27','2027-05-20 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2178,12,1,'ChIJTQgeojs7RDkRwvFliqFYdyw','(आपातकालीन सेवा ) मातृ एव्म शिशु स्वास्थ्य केंद्र जिला अस्पताल , बाड़मेर (Emergency Service) Mother and Infant Health Center, District Hospital, Barmer',3.4,8,'OPERATIONAL',195,'195 m away',1,25.7508519,71.3953692,'Q92W+84X, Unnamed Road, रेलवे कॉलोनी, बाड़मेर','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:45:27','2027-05-20 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2179,12,2,'ChIJj_UIkJw7RDkRLWn9EoCq7SI','RR DEFENCE ACADEMY BARMER',5.0,168,'OPERATIONAL',443,'443 m away',1,25.7510197,71.4009323,'Nehru Nagar, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2180,12,2,'ChIJfdkacrA6RDkR-Xrvt5YuXB0','The SmarT KiDzEe Play School',4.9,15,'OPERATIONAL',412,'412 m away',0,25.7502882,71.3931326,'Vishwakarma circle Government Girls college, road, Laxmipura, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2181,12,2,'ChIJhcm3Hls7RDkR9ChtLLeVXYQ','Electric',NULL,NULL,'OPERATIONAL',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Barmer','[\"primary_school\",\"school\",\"point_of_interest\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2182,12,2,'ChIJH6udwb47RDkR2ljbkT2DAeA','भीममलाई 5 किलोमीटर दूर',NULL,NULL,'OPERATIONAL',5,'<50 m away',1,25.7521875,71.3966875,'Q92W+VMF','[\"school\",\"point_of_interest\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2183,12,2,'ChIJ0UQMLgA7RDkR9i-qIfL5Aus','टाक बस्ती स्कूल(vakaram)',NULL,NULL,'OPERATIONAL',27,'<50 m away',NULL,25.7519229,71.3965816,'Q92W+QJ8, Gouda, बाड़मेर','[\"primary_school\",\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2184,12,2,'ChIJdz6AWQA7RDkRTEKrsZY9vQQ','gouda kumhar tak basti',NULL,NULL,'OPERATIONAL',27,'<50 m away',NULL,25.7519229,71.3965816,'कुम्हार टाक बस्ती गोड़ा सेड़वा, बाड़मेर','[\"primary_school\",\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2185,12,2,'ChIJ925GJr47RDkRbh7YHgSfMfg','पावड़ो की ढाणी',NULL,NULL,'OPERATIONAL',169,'169 m away',NULL,25.7506526,71.3963998,'Q92W+7H6, बामरला, बाड़मेर','[\"primary_school\",\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2186,12,2,'ChIJyeP1PXQ_RDkR0GkZ7pts6qE','GOVT. SENIOR SECONDARY SCHOOL SUTHARO KA TALA MITHADA,BARMER',NULL,NULL,'OPERATIONAL',222,'222 m away',0,25.7503070,71.3958309,'Q92W+48G, Unnamed Road, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2187,12,2,'ChIJjRj-5UI7RDkRhgnAEhgJz8o','Aainath elominiyam wark /bas stop',NULL,NULL,'OPERATIONAL',255,'255 m away',NULL,25.7535475,71.3987015,'ke pas, Kalwani kumawat bas stop, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2188,12,2,'ChIJ4ZUblro6RDkRxnnkhZ59nio','Bal Mandir School, Barmer',NULL,NULL,'OPERATIONAL',352,'352 m away',0,25.7490696,71.3958621,'P9XW+J8H, High School Road, Railway Colony, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2189,12,2,'ChIJge4r7go7RDkRmYNLIqDom6Y','Antari Devi Girl\'s Sen. Seconder School Barmer',NULL,NULL,'OPERATIONAL',371,'371 m away',0,25.7495565,71.3943559,'MBC Girls College, near, Laxmipura, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2190,12,2,'ChIJjUQd4D07RDkRkRSGuiWPcRM','VIRAJ',NULL,NULL,'OPERATIONAL',476,'476 m away',NULL,25.7494940,71.3929594,'P9XV+Q5W','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2191,12,2,'ChIJidcJf7c6RDkRrHX-kXFynJ4','Ramubai Ganesh Mal Golechha, Govt. Secondary School',NULL,NULL,'OPERATIONAL',644,'644 m away',NULL,25.7512797,71.4030485,'QC23+G67, Adarsh Stadium Road, Nehru Nagar, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2192,12,2,'ChIJq0QB3aI6RDkR4SOQbn3w0CA','aasha children kingd',NULL,NULL,'CLOSED_TEMPORARILY',1317,'1.3 km away',NULL,25.7407831,71.3929883,'P9RV+859, Kalyanpura, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2193,12,2,'ChIJpcx9xak6RDkRwPtlayf3DpY','Govt. Senior Secondary School Railway Kunwa No. 3',NULL,NULL,'CLOSED_TEMPORARILY',1335,'1.3 km away',NULL,25.7521364,71.3833556,'Railway kunwa, no 3, Gehoon Road, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2194,12,3,'ChIJ0yacMLs6RDkRA4_2wsRlGpE','Hotel Kalinga Palace',4.0,1443,'OPERATIONAL',673,'673 m away',1,25.7462020,71.3954020,'Rly. Station, opposite Barmer, Station Road, Barmer','[\"bar\",\"lodging\",\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2195,12,3,'ChIJpbE7X6U6RDkREmi_3vFcKqM','Laziz Pizza',3.9,812,'OPERATIONAL',436,'436 m away',0,25.7497397,71.3932460,'Shop No. 1,2 and 3, girls college road Vishwakarma circle, Ray Colony, Barmer','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2196,12,3,'ChIJOblC-s46RDkR2j6i9vb7j74','K K Hotel',3.9,110,'OPERATIONAL',1915,'1.9 km away',NULL,25.7572657,71.4149466,'National Highway 68, Mahaveer Nagar, Barmer','[\"lodging\",\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2197,12,3,'ChIJtZHLZwA7RDkRm_b9GejsSsk','माचरा भोजनालय',NULL,NULL,'OPERATIONAL',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2198,12,3,'ChIJx_qDcgA7RDkRn5eFaYO3pWA','प्रकाश चन्द्र मीणा टुकड़ी वाला बाड़मेर सामुडा सोराया है',NULL,NULL,'OPERATIONAL',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"meal_takeaway\",\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2199,12,3,'ChIJWXMzSwA7RDkRli3rDMSG4Zc','𝓗𝓪𝓻𝓲𝓼𝓱 𝓳𝓪𝓴𝓱𝓪𝓻',NULL,NULL,'CLOSED_TEMPORARILY',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2200,12,3,'ChIJia9Vd3k7RDkRBMZ_IONgGjs','करणी रेस्टोरेंट पूरोहित रेस्टोरेंट',NULL,NULL,'CLOSED_TEMPORARILY',0,'Distance unavailable',NULL,25.7521467,71.3966865,'आईसर कपनी, बाड़मेर','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2201,12,3,'ChIJ-ehbZAA7RDkRcPD9lMUiJVs','ढाबा देसी तड़का',NULL,NULL,'CLOSED_TEMPORARILY',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Khema-Ka-Kuwa, Jodhpur - Barmer Road, Pal, Jodhpur','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2202,12,3,'ChIJmYpaMAA7RDkR4uJ8m1BZwY0','Balaji sikim road new baypas Barmer',NULL,NULL,'CLOSED_TEMPORARILY',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Q92W+VM3, Balaji sikim road, new baypas, बाड़मेर','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2203,12,3,'ChIJyTk-6lQ7RDkRV64oHCzZnRU','Taste Buds',NULL,NULL,'CLOSED_TEMPORARILY',0,'Distance unavailable',NULL,25.7521467,71.3966865,'M.S, Ramaiah Enclave, 44/2, Hesarghatta Road, Barmer','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2204,12,3,'ChIJuVQ8NUE7RDkREQNKoomfy7I','Thar Restaurant Barmer',NULL,NULL,'OPERATIONAL',0,'Distance unavailable',NULL,25.7521467,71.3966865,'near Maple Marriage Garden, Gehu Road, Barmer','[\"bakery\",\"restaurant\",\"food\",\"point_of_interest\",\"store\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2205,12,3,'ChIJHyxeawA7RDkRTZxqxceFpeg','साईं राम महाराज माजीसा मंदिर',NULL,NULL,'OPERATIONAL',0,'Distance unavailable',NULL,25.7521467,71.3966865,'में गांव क','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2206,12,3,'ChIJt91QMQA7RDkR5dgSHauqqow','Pappu',NULL,NULL,'CLOSED_TEMPORARILY',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2207,12,3,'ChIJQ2fiVAA7RDkRICygSZNmFYM','गोस्वामी होटल सोनड़ी',NULL,NULL,'CLOSED_TEMPORARILY',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2208,12,3,'ChIJW4g8rgQ7RDkR2dulruboqCo','Aasin khan',NULL,NULL,'CLOSED_TEMPORARILY',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:45:27','2026-05-27 21:45:27','2026-05-20 21:45:27','2026-05-20 21:45:27'),
(2209,12,4,'ChIJVfEPba86RDkRTmzZct3vSIA','Axis Bank Branch',4.2,53,'OPERATIONAL',243,'243 m away',0,25.7516068,71.3943346,'Goswami Tower, Rai Colony Road, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:45:28','2026-05-27 21:45:28','2026-05-20 21:45:28','2026-05-20 21:45:28'),
(2210,12,4,'ChIJ93o73q86RDkRmEBX_ZBAMIU','Union Bank of India',3.9,53,'OPERATIONAL',266,'266 m away',0,25.7514700,71.3941380,'Ward No-3, Barmer Main Laxmipura, Road, Ray Colony, Barmer','[\"bank\",\"atm\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:45:28','2026-05-27 21:45:28','2026-05-20 21:45:28','2026-05-20 21:45:28'),
(2211,12,4,'ChIJ0aDYF6g6RDkRaYmbReSwbyY','Kotak Mahindra Bank',3.7,49,'OPERATIONAL',232,'232 m away',0,25.7515208,71.3944753,'Dev Tower\",Laxmi Nagar, Road, Main, Ray Colony, Barmer','[\"bank\",\"insurance_agency\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:45:28','2026-05-27 21:45:28','2026-05-20 21:45:28','2026-05-20 21:45:28'),
(2212,12,4,'ChIJkTS-BrE6RDkRqBkPGqChY-4','SBI Branch Barmer Collectorate',4.4,30,'OPERATIONAL',1442,'1.4 km away',0,25.7600376,71.4081090,'Sbi, Circuit House Road, Collectrate Campus, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:45:28','2026-05-27 21:45:28','2026-05-20 21:45:28','2026-05-20 21:45:28'),
(2213,12,4,'ChIJ7wKwU6I6RDkRHQN_Ofsw1t0','SBI Branch Barmer',3.9,69,'OPERATIONAL',1701,'1.7 km away',0,25.7376800,71.3911580,'Ci, Pratap Ji Ki Pole, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:45:28','2026-05-27 21:45:28','2026-05-20 21:45:28','2026-05-20 21:45:28'),
(2214,12,4,'ChIJxQJeX6Q6RDkRNx-ELk166hE','SBI Bank',4.2,32,'OPERATIONAL',1612,'1.6 km away',0,25.7416164,71.4077451,'SH 40, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:45:28','2026-05-27 21:45:28','2026-05-20 21:45:28','2026-05-20 21:45:28'),
(2215,12,4,'ChIJO8ayiqQ6RDkRohxy3CfNtfw','Bank of Baroda',3.9,28,'OPERATIONAL',1039,'1.0 km away',0,25.7449727,71.3900321,'Barmer, SH-112, Barmer Road, Barmer, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:45:28','2026-05-27 21:45:28','2026-05-20 21:45:28','2026-05-20 21:45:28'),
(2216,12,4,'ChIJgxIwbKQ6RDkRamWVTb2GLWw','ICICI Bank Gandhi Chowk, Barmer-Branch & ATM',4.0,14,'OPERATIONAL',1037,'1.0 km away',0,25.7451008,71.3899053,'Gandhi Chowk, 0, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:45:28','2026-05-27 21:45:28','2026-05-20 21:45:28','2026-05-20 21:45:28'),
(2217,12,4,'ChIJceMyEM86RDkR4pcwcclFl2s','Andhra Bank',4.4,12,'OPERATIONAL',1785,'1.8 km away',0,25.7546248,71.4142947,'GROUND FLOOR, BB-3 Mahaveer Nagar, NH-15, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:45:28','2026-05-27 21:45:28','2026-05-20 21:45:28','2026-05-20 21:45:28'),
(2218,12,4,'ChIJ4a14L8Q6RDkR0waChtxchbA','UCO Bank',3.8,36,'OPERATIONAL',1638,'1.6 km away',0,25.7487178,71.4125892,'Barmer, NH-15, Barmer Road, Barmer, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:45:28','2026-05-27 21:45:28','2026-05-20 21:45:28','2026-05-20 21:45:28'),
(2219,12,4,'ChIJ29UtZM86RDkRkJlDbjItj9Y','Axis Bank ATM',3.8,5,'OPERATIONAL',1731,'1.7 km away',1,25.7519813,71.4139734,'Goswami Tower, Road, Ray Colony, Barmer','[\"atm\",\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:45:28','2026-05-27 21:45:28','2026-05-20 21:45:28','2026-05-20 21:45:28'),
(2220,12,4,'ChIJD8ed4K86RDkRdleaErAwzBI','CENTRAL BANK OF INDIA - BARMER Branch',3.7,18,'OPERATIONAL',1637,'1.6 km away',0,25.7485863,71.4125490,'near ahaar bojanalay, Chindru churaiya, near ahaar bojanalay, Krishi Mandi Road, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:45:28','2026-05-27 21:45:28','2026-05-20 21:45:28','2026-05-20 21:45:28'),
(2221,12,4,'ChIJUbJaaKQ6RDkRdBrwu1erllg','IDBI Bank',3.9,27,'CLOSED_TEMPORARILY',1022,'1.0 km away',NULL,25.7451469,71.3900667,'Arihant Tower Opp Customs Check Post, Station Road, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:45:28','2026-05-27 21:45:28','2026-05-20 21:45:28','2026-05-20 21:45:28'),
(2222,12,4,'ChIJn6qqatZoaTkRRYykhkQfm-0','ICICI Bank Ltd.,Barmer-Gandhi chowk',2.2,6,'OPERATIONAL',1089,'1.1 km away',0,25.7449403,71.3893260,'ICICI Bank Ltd., Gandhi Chowk,Barmer - 344001 #VALUE!, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:45:28','2026-05-27 21:45:28','2026-05-20 21:45:28','2026-05-20 21:45:28'),
(2223,12,5,'ChIJq6qq6qw6RDkRn-TBS9mpBck','Jasnath Provision & Kirana Store Barmer',4.1,84,'OPERATIONAL',1150,'1.2 km away',0,25.7601101,71.3893627,'Q96Q+2PW, Indra Nagar, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"point_of_interest\",\"store\",\"establishment\"]',1,NULL,'2026-05-20 21:45:28','2026-05-27 21:45:28','2026-05-20 21:45:28','2026-05-20 21:45:28'),
(2224,12,5,'ChIJiSLr7FA7RDkRAL0Tgw_xA0A','Karni Kirana Store',4.8,6,'OPERATIONAL',570,'570 m away',NULL,25.7572651,71.3969238,'34, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"point_of_interest\",\"store\",\"establishment\"]',1,NULL,'2026-05-20 21:45:28','2026-05-27 21:45:28','2026-05-20 21:45:28','2026-05-20 21:45:28'),
(2225,12,5,'ChIJXWMQY2M7RDkR1lFEBlbXWUI','Balaji handloom',4.6,24,'OPERATIONAL',813,'813 m away',0,25.7453488,71.3937109,'opposite kailash sarover hotel, Station Road, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"point_of_interest\",\"store\",\"establishment\"]',1,NULL,'2026-05-20 21:45:28','2026-05-27 21:45:28','2026-05-20 21:45:28','2026-05-20 21:45:28'),
(2226,12,5,'ChIJnxoTe5Q6RDkRPt8rJa3lnTQ','Jansukh Cart',5.0,4,'OPERATIONAL',1995,'2.0 km away',0,25.7345456,71.4005388,'opp. Thar Hospital, H.NO. 48 NH 68, opp. Thar Hospital, Shastri Nagar, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"point_of_interest\",\"store\",\"establishment\"]',1,NULL,'2026-05-20 21:45:28','2026-05-27 21:45:28','2026-05-20 21:45:28','2026-05-20 21:45:28'),
(2227,12,5,'ChIJAQcl9MY6RDkRHB12W5pwSpw','Ramesh Traders Barmer',4.5,15,'OPERATIONAL',1407,'1.4 km away',0,25.7490776,71.4103203,'PCX6+J4P, Nehru Nagar, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"point_of_interest\",\"store\",\"establishment\"]',1,NULL,'2026-05-20 21:45:28','2026-05-27 21:45:28','2026-05-20 21:45:28','2026-05-20 21:45:28'),
(2228,12,5,'ChIJq6qq6qw6RDkRb1w7yE18Phg','Bhagwati Hinglaj Provision',3.7,3,'OPERATIONAL',1146,'1.1 km away',0,25.7602373,71.3896045,'Q96Q+3RX, Indra Nagar, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"point_of_interest\",\"store\",\"establishment\"]',1,NULL,'2026-05-20 21:45:28','2026-05-27 21:45:28','2026-05-20 21:45:28','2026-05-20 21:45:28'),
(2229,12,5,'ChIJAYMr86Q6RDkRFvFS_8uJ0Os','SHIV GENERAL STORE',5.0,1,'OPERATIONAL',887,'887 m away',0,25.7454512,71.3918801,'mukand ji mandir, Near, Station Road, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"point_of_interest\",\"store\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:45:28','2026-05-27 21:45:28','2026-05-20 21:45:28','2026-05-20 21:45:28'),
(2230,12,5,'ChIJofjJlDE7RDkRoN_IZOh4kvo','Shyam Lal Sharma',NULL,NULL,'OPERATIONAL',1717,'1.7 km away',NULL,25.7522373,71.4138254,'Shyam Lal Sharma, Mahaveer Nagar, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"point_of_interest\",\"store\",\"establishment\"]',0,'unrated','2026-05-20 21:45:28','2026-05-27 21:45:28','2026-05-20 21:45:28','2026-05-20 21:45:28'),
(2231,12,5,'ChIJzaX-uWw7RDkRhVdIxEk0oNc','Maa Jagtdmba Fruit Bhndar',NULL,NULL,'OPERATIONAL',1728,'1.7 km away',NULL,25.7523913,71.4139340,'16, Sindhary Choraha','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"point_of_interest\",\"store\",\"establishment\"]',0,'unrated','2026-05-20 21:45:28','2026-05-27 21:45:28','2026-05-20 21:45:28','2026-05-20 21:45:28'),
(2232,12,5,'ChIJMRGzv5M7RDkR73gq1J3d9-g','माँ अम्बे सैनेट्री वेयर बलदेव नगर बाड़मेर',5.0,2,'OPERATIONAL',1897,'1.9 km away',1,25.7559878,71.4151427,'QC48+93R, Baldev Nagar, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"point_of_interest\",\"store\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:45:28','2026-05-27 21:45:28','2026-05-20 21:45:28','2026-05-20 21:45:28'),
(2233,12,5,'ChIJTZO2h2s7RDkRKmOmhxot_7A','Hanuman Ram',NULL,NULL,'OPERATIONAL',1994,'2.0 km away',NULL,25.7517424,71.4165943,'Hanuman Ram, Sindhari Road, Baldev Nagar, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"point_of_interest\",\"store\",\"establishment\"]',0,'unrated','2026-05-20 21:45:28','2026-05-27 21:45:28','2026-05-20 21:45:28','2026-05-20 21:45:28'),
(2234,12,6,'ChIJ_eUR7a07RDkRy1kF_2i9RAU','Mahaveer Park',4.2,103,'OPERATIONAL',136,'136 m away',NULL,25.7525125,71.3979844,'Madhuban Colony, P S Parisar Colony, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:45:29','2026-05-27 21:45:29','2026-05-20 21:45:29','2026-05-20 21:45:29'),
(2235,12,6,'ChIJsa3eXwA7RDkRVlLxfZMQu_w','भामाशाह लीलाराम जांगिड़ स्मृति पार्क',4.5,112,'OPERATIONAL',1378,'1.4 km away',0,25.7398429,71.3983323,'1424, Krishi Mandi Road, Shastri Nagar, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:45:29','2026-05-27 21:45:29','2026-05-20 21:45:29','2026-05-20 21:45:29'),
(2236,12,6,'ChIJ8eEWsbc6RDkRlevOoZ_Z6Vk','Mahaveer Park',4.2,863,'OPERATIONAL',811,'811 m away',0,25.7541835,71.4044612,'QC33+MQG, Nehru Nagar, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:45:29','2026-05-27 21:45:29','2026-05-20 21:45:29','2026-05-20 21:45:29'),
(2237,12,6,'ChIJ6dYbGOk7RDkRcmz917gO-2o','ओपन एयर जिम (आदर्श स्टेडियम), बाड़मेर',4.4,11,'OPERATIONAL',775,'775 m away',NULL,25.7545544,71.4039465,'QC33+XR3, Ambedkar Colony, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:45:29','2026-05-27 21:45:29','2026-05-20 21:45:29','2026-05-20 21:45:29'),
(2238,12,6,'ChIJGd9N35s7RDkRp-_jpfDrvvs','Lt General Hanut Singh PVSM Mahavir Chakra Park',4.4,21,'OPERATIONAL',1596,'1.6 km away',1,25.7561273,71.4120022,'900/6, Ambedkar Colony, Mahaveer Nagar, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:45:29','2026-05-27 21:45:29','2026-05-20 21:45:29','2026-05-20 21:45:29'),
(2239,12,6,'ChIJ5cP_WVE7RDkRFEPGjuOSDN8','Maa Shera Wali Garba Ground',4.8,12,'OPERATIONAL',1756,'1.8 km away',NULL,25.7567116,71.4134717,'1157, Ambedkar Colony, Mahaveer Nagar, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:45:29','2026-05-27 21:45:29','2026-05-20 21:45:29','2026-05-20 21:45:29'),
(2240,12,6,'ChIJOcXekaA6RDkRa7Ohy8sRpGc','Son Naadi Park',4.1,29,'OPERATIONAL',1833,'1.8 km away',NULL,25.7407728,71.3834380,'P9RM+894, Venasar Naadi, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:45:29','2026-05-27 21:45:29','2026-05-20 21:45:29','2026-05-20 21:45:29'),
(2241,12,6,'ChIJN_1YDAA7RDkROhdU2EU7NHo','Ugararam Rathore Rana',NULL,NULL,'OPERATIONAL',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:45:29','2026-05-27 21:45:29','2026-05-20 21:45:29','2026-05-20 21:45:29'),
(2242,12,6,'ChIJ6dEwbQA7RDkRMSheyro4FmE','Magraj beniwal',NULL,NULL,'OPERATIONAL',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:45:29','2026-05-27 21:45:29','2026-05-20 21:45:29','2026-05-20 21:45:29'),
(2243,12,6,'ChIJPayqnj07RDkRdSlE3J7aCSc','आयुष्मान भारत सूर्यनमस्कार प्रतीक',NULL,NULL,'OPERATIONAL',134,'134 m away',NULL,25.7509766,71.3969922,'new, hanuwant school road, Derasar','[\"park\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:45:29','2026-05-27 21:45:29','2026-05-20 21:45:29','2026-05-20 21:45:29'),
(2244,12,6,'ChIJ____5LA6RDkRoac5qE405Fs','Public Park',NULL,NULL,'OPERATIONAL',172,'172 m away',NULL,25.7528555,71.3982092,'Q93X+47W, Madhuban Colony, P S Parisar Colony, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:45:29','2026-05-27 21:45:29','2026-05-20 21:45:29','2026-05-20 21:45:29'),
(2245,12,6,'ChIJx-4CLwA7RDkRhTTjF4jEZeE','I LOVE BARMER',5.0,2,'OPERATIONAL',176,'176 m away',NULL,25.7527676,71.3983082,'Q93X+483, P S Parisar Colony, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:45:29','2026-05-27 21:45:29','2026-05-20 21:45:29','2026-05-20 21:45:29'),
(2246,12,6,'ChIJgWV3JQAlRDkRPuRQGB0EX6k','Park',3.0,2,'OPERATIONAL',1436,'1.4 km away',NULL,25.7649061,71.3944619,'Q97V+XQ8, Hinglaj Nagar, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:45:29','2026-05-27 21:45:29','2026-05-20 21:45:29','2026-05-20 21:45:29'),
(2247,12,6,'ChIJT6niBLo7RDkRFXPQp2caQPo','Barmer pradrsini park',3.0,5,'OPERATIONAL',1814,'1.8 km away',NULL,25.7522847,71.4147956,'QC27+WW7, Baldev Nagar, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:45:29','2026-05-27 21:45:29','2026-05-20 21:45:29','2026-05-20 21:45:29'),
(2248,12,6,'ChIJhWrJdt47RDkRo1odcGABylI','कबूतरों का चबूतरा',NULL,NULL,'OPERATIONAL',1924,'1.9 km away',NULL,25.7590617,71.4142967,'QC57+JPF, Ambedkar Colony, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:45:29','2026-05-27 21:45:29','2026-05-20 21:45:29','2026-05-20 21:45:29'),
(2249,12,7,'ChIJvSfDPwA7RDkRq6lhDq5GuH8','Revital Zone Gym',4.9,128,'OPERATIONAL',833,'833 m away',0,25.7470827,71.3905612,'258/6, Harijan Basti, Barmer','[\"gym\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:45:29','2026-05-27 21:45:29','2026-05-20 21:45:29','2026-05-20 21:45:29'),
(2250,12,7,'ChIJx00eWLc7RDkROGcSFPmaZvc','M S SODHA GYM',4.5,159,'OPERATIONAL',676,'676 m away',0,25.7461203,71.3957650,'5th Floor, Bhagwati Complex, Station Road, Barmer','[\"gym\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:45:29','2026-05-27 21:45:29','2026-05-20 21:45:29','2026-05-20 21:45:29'),
(2251,12,7,'ChIJKX1nBPs7RDkR3_dBhXBNAic','ShreeRam GYM - Gym & Fitness Centre',4.9,469,'OPERATIONAL',1559,'1.6 km away',0,25.7551479,71.4118882,'Second Floor, City Centre, Mahaveer Nagar, Barmer','[\"gym\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:45:29','2026-05-27 21:45:29','2026-05-20 21:45:29','2026-05-20 21:45:29'),
(2252,12,7,'ChIJuVCD6VA7RDkRy5EjtVKzQIw','The Dance Factory Barmer',5.0,64,'OPERATIONAL',1821,'1.8 km away',0,25.7583179,71.4135301,'behind costume quarters, Ambedkar Colony, Barmer','[\"gym\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:45:29','2026-05-27 21:45:29','2026-05-20 21:45:29','2026-05-20 21:45:29'),
(2253,12,7,'ChIJT91d5uo6RDkR6D3b5N24r0Y','KDM GYM',4.5,330,'OPERATIONAL',1953,'2.0 km away',0,25.7379877,71.4082267,'Sodha Form house, near St. Paul\'s School, Shivkar Road, Dangriya, Barmer','[\"gym\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:45:29','2026-05-27 21:45:29','2026-05-20 21:45:29','2026-05-20 21:45:29'),
(2254,12,7,'ChIJv7C65ho7RDkR6chaDoKrl-s','Nehru Yuva Kendra Gym, Barmer',4.8,4,'OPERATIONAL',327,'327 m away',0,25.7539764,71.3992490,'Q93X+HMX, Madhuban Colony, P S Parisar Colony, Barmer','[\"gym\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:45:29','2026-05-27 21:45:29','2026-05-20 21:45:29','2026-05-20 21:45:29'),
(2255,12,7,'ChIJD-QuhgI7RDkRQSAv_kcxWNs','VIP Gym',4.0,52,'OPERATIONAL',233,'233 m away',0,25.7518161,71.3943939,'Q92V+PQC, Laxmi Nagar, Barmer','[\"gym\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:45:29','2026-05-27 21:45:29','2026-05-20 21:45:29','2026-05-20 21:45:29'),
(2256,12,7,'ChIJXS5-seM7RDkRQM0VdPoRxik','The fitness zone',4.2,52,'OPERATIONAL',1931,'1.9 km away',0,25.7353759,71.3916828,'Partap Ji Ki Prol Road, Pratap Ji Ki Pole, Barmer','[\"gym\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:45:29','2026-05-27 21:45:29','2026-05-20 21:45:29','2026-05-20 21:45:29'),
(2257,12,7,'ChIJnbeOBIo7RDkR7mPazcsEu14','Vicky health & nutrition centre',4.0,8,'OPERATIONAL',1390,'1.4 km away',0,25.7396755,71.3956955,'NEAR THAR GAS AGENCY, CO-OPERATIVE MARKETING SOCIETY, SHOP NO 12, FIRST FLOOR, Barmer','[\"gym\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-20 21:45:29','2026-05-27 21:45:29','2026-05-20 21:45:29','2026-05-20 21:45:29'),
(2258,12,7,'ChIJB2-zVgA7RDkRMZc-BcRwHEU','खोडाल',NULL,NULL,'CLOSED_TEMPORARILY',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"gym\",\"point_of_interest\",\"health\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:45:29','2026-05-27 21:45:29','2026-05-20 21:45:29','2026-05-20 21:45:29'),
(2259,12,7,'ChIJz2bCWwA7RDkRjR49MLZTDrQ','EX.Hari Singh Bhati ka vaas',NULL,NULL,'CLOSED_TEMPORARILY',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"gym\",\"point_of_interest\",\"health\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:45:29','2026-05-27 21:45:29','2026-05-20 21:45:29','2026-05-20 21:45:29'),
(2260,12,7,'ChIJbclBMgA7RDkR6dFzaibUY5c','HEALTH AND FITNESS CENTER BARMER',5.0,1,'OPERATIONAL',686,'686 m away',0,25.7460474,71.3956744,'SHOP No.- 408, 4TH FLOOR, BHAGATI COMPLEX, Railway, स्टेशन मार्ग, बाड़मेर','[\"gym\",\"point_of_interest\",\"health\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:45:29','2026-05-27 21:45:29','2026-05-20 21:45:29','2026-05-20 21:45:29'),
(2261,12,7,'ChIJd3WiFuI7RDkRPtLnZElocBY','Revital Store : Buy Branded Supplements & Nutrition Products At Best Price & 100% Genuine In Barmer',5.0,2,'OPERATIONAL',720,'720 m away',0,25.7491806,71.3902956,'in front of Rai Colony School, Panch Batti Cricle, Barmer','[\"gym\",\"food\",\"point_of_interest\",\"store\",\"health\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:45:29','2026-05-27 21:45:29','2026-05-20 21:45:29','2026-05-20 21:45:29'),
(2262,12,9,'ChIJ12Xvn7s6RDkRjUud9Q7F_HM','Barmer',4.4,1882,'OPERATIONAL',650,'650 m away',NULL,25.7463500,71.3975400,'Station Road, Nehru Nagar, Barmer','[\"train_station\",\"transit_station\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:45:30','2026-05-27 21:45:30','2026-05-20 21:45:30','2026-05-20 21:45:30'),
(2263,13,1,'ChIJTxcrQiY7RDkRi4D_5EOaZxA','Dr. Rakesh Pannu',5.0,20,'OPERATIONAL',157,'157 m away',1,25.7516518,71.3952229,'Quarter no. 22, near govt hospital, road, Ray Colony, Barmer','[\"hospital\",\"doctor\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:33','2027-05-20 21:57:33','2026-05-20 21:57:33','2026-05-20 21:57:33'),
(2264,13,1,'ChIJx32Bm7o6RDkR-Sa4_Gw0K1o','Dr sawai singh Rathore Orthopaedic surgeon',4.4,68,'OPERATIONAL',283,'283 m away',0,25.7503999,71.3946279,'Govt.hospital barmer, campus, Gandhi Nagar, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:33','2027-05-20 21:57:33','2026-05-20 21:57:33','2026-05-20 21:57:33'),
(2265,13,1,'ChIJ5ZHDJrA6RDkRI3Lc4EShIq8','SAPP Medilab',4.9,13,'OPERATIONAL',203,'203 m away',0,25.7518702,71.3946800,'Hotel Desert Inn, opp. CMHO office, near Bank of Maharashtra, road, Ray Colony, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:33','2027-05-20 21:57:33','2026-05-20 21:57:33','2026-05-20 21:57:33'),
(2266,13,1,'ChIJjf_eis46RDkRf3vcBzIcKMQ','Balaji Hospital',4.4,38,'OPERATIONAL',1907,'1.9 km away',0,25.7571743,71.4148873,'15, National Highway, Ambedkar Colony, Mahaveer Nagar, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:33','2027-05-20 21:57:33','2026-05-20 21:57:33','2026-05-20 21:57:33'),
(2267,13,1,'ChIJtzEjLr06RDkRm4Fp3ZiXuAA','Matru Dental Clinic and Physiotherapy Center',4.1,13,'OPERATIONAL',1270,'1.3 km away',NULL,25.7408430,71.3948417,'P9RV+8WP, Krishi Mandi Road, Kalyanpura, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:33','2027-05-20 21:57:33','2026-05-20 21:57:33','2026-05-20 21:57:33'),
(2268,13,1,'ChIJRbJPfrA6RDkRR2HilYKYEs0','Lucky Lab',3.7,3,'OPERATIONAL',179,'179 m away',0,25.7506014,71.3971713,'Jodhpur - Barmer Road, Vivekanand Nagar, Nehru Nagar, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:33','2027-05-20 21:57:33','2026-05-20 21:57:33','2026-05-20 21:57:33'),
(2269,13,1,'ChIJ3fN8Bco5RDkRZvbJuxihaAE','Martala Gala Barmer',3.8,11,'OPERATIONAL',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:33','2027-05-20 21:57:33','2026-05-20 21:57:33','2026-05-20 21:57:33'),
(2270,13,1,'ChIJfWY8BiE7RDkR1IUtO2Okadk','National medical store',NULL,NULL,'OPERATIONAL',0,'Distance unavailable',0,25.7521467,71.3966865,'National medical store, Agasdi, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:57:33','2027-05-20 21:57:33','2026-05-20 21:57:33','2026-05-20 21:57:33'),
(2271,13,1,'ChIJn15vrRs7RDkR3jbokMDwSPQ','Dr aaysha Choudhary',5.0,1,'OPERATIONAL',0,'Distance unavailable',0,25.7521467,71.3966865,'जनना विंग के पीछे क्वार्टर में, राजकिय अस्पताल कैम्पस क्वार्टर बाड़मेर BB 76, III 49 C राजकीय अस्पताल, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:57:33','2027-05-20 21:57:33','2026-05-20 21:57:33','2026-05-20 21:57:33'),
(2272,13,1,'ChIJeXo0ZwA7RDkRTfuno-EAZWY','सडैचा',NULL,NULL,'OPERATIONAL',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:57:33','2027-05-20 21:57:33','2026-05-20 21:57:33','2026-05-20 21:57:33'),
(2273,13,1,'ChIJfbwreAA7RDkRroCLD8whaFY','Gefra राम devasi',NULL,NULL,'OPERATIONAL',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:57:33','2027-05-20 21:57:33','2026-05-20 21:57:33','2026-05-20 21:57:33'),
(2274,13,1,'ChIJP6d7eQA7RDkROh-4stnY3ro','Raju bhandari (majisha medical Store)',NULL,NULL,'OPERATIONAL',2,'<50 m away',NULL,25.7521328,71.3966858,'Q92W+VM3, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:57:33','2027-05-20 21:57:33','2026-05-20 21:57:33','2026-05-20 21:57:33'),
(2275,13,1,'ChIJUd1GdAA7RDkRIX4wwqCH9Nw','Aainath Hospital',NULL,NULL,'OPERATIONAL',186,'186 m away',1,25.7506175,71.3974287,'Q92W+6XV, Nehru Nagar, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:57:33','2027-05-20 21:57:33','2026-05-20 21:57:33','2026-05-20 21:57:33'),
(2276,13,1,'ChIJS5LOTwA7RDkRA9YNWHVKveo','Ambulance stand',NULL,NULL,'OPERATIONAL',187,'187 m away',NULL,25.7504687,71.3967028,'Q92W+5MP, Railway Colony, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:57:33','2027-05-20 21:57:33','2026-05-20 21:57:33','2026-05-20 21:57:33'),
(2277,13,1,'ChIJTQgeojs7RDkRwvFliqFYdyw','(आपातकालीन सेवा ) मातृ एव्म शिशु स्वास्थ्य केंद्र जिला अस्पताल , बाड़मेर (Emergency Service) Mother and Infant Health Center, District Hospital, Barmer',3.4,8,'OPERATIONAL',195,'195 m away',1,25.7508519,71.3953692,'Q92W+84X, Unnamed Road, रेलवे कॉलोनी, बाड़मेर','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:57:33','2027-05-20 21:57:33','2026-05-20 21:57:33','2026-05-20 21:57:33'),
(2278,13,2,'ChIJj_UIkJw7RDkRLWn9EoCq7SI','RR DEFENCE ACADEMY BARMER',5.0,168,'OPERATIONAL',443,'443 m away',1,25.7510197,71.4009323,'Nehru Nagar, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2279,13,2,'ChIJfdkacrA6RDkR-Xrvt5YuXB0','The SmarT KiDzEe Play School',4.9,15,'OPERATIONAL',412,'412 m away',0,25.7502882,71.3931326,'Vishwakarma circle Government Girls college, road, Laxmipura, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2280,13,2,'ChIJhcm3Hls7RDkR9ChtLLeVXYQ','Electric',NULL,NULL,'OPERATIONAL',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Barmer','[\"primary_school\",\"school\",\"point_of_interest\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2281,13,2,'ChIJH6udwb47RDkR2ljbkT2DAeA','भीममलाई 5 किलोमीटर दूर',NULL,NULL,'OPERATIONAL',5,'<50 m away',1,25.7521875,71.3966875,'Q92W+VMF','[\"school\",\"point_of_interest\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2282,13,2,'ChIJ0UQMLgA7RDkR9i-qIfL5Aus','टाक बस्ती स्कूल(vakaram)',NULL,NULL,'OPERATIONAL',27,'<50 m away',NULL,25.7519229,71.3965816,'Q92W+QJ8, Gouda, बाड़मेर','[\"primary_school\",\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2283,13,2,'ChIJdz6AWQA7RDkRTEKrsZY9vQQ','gouda kumhar tak basti',NULL,NULL,'OPERATIONAL',27,'<50 m away',NULL,25.7519229,71.3965816,'कुम्हार टाक बस्ती गोड़ा सेड़वा, बाड़मेर','[\"primary_school\",\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2284,13,2,'ChIJ925GJr47RDkRbh7YHgSfMfg','पावड़ो की ढाणी',NULL,NULL,'OPERATIONAL',169,'169 m away',NULL,25.7506526,71.3963998,'Q92W+7H6, बामरला, बाड़मेर','[\"primary_school\",\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2285,13,2,'ChIJyeP1PXQ_RDkR0GkZ7pts6qE','GOVT. SENIOR SECONDARY SCHOOL SUTHARO KA TALA MITHADA,BARMER',NULL,NULL,'OPERATIONAL',222,'222 m away',0,25.7503070,71.3958309,'Q92W+48G, Unnamed Road, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2286,13,2,'ChIJjRj-5UI7RDkRhgnAEhgJz8o','Aainath elominiyam wark /bas stop',NULL,NULL,'OPERATIONAL',255,'255 m away',NULL,25.7535475,71.3987015,'ke pas, Kalwani kumawat bas stop, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2287,13,2,'ChIJ4ZUblro6RDkRxnnkhZ59nio','Bal Mandir School, Barmer',NULL,NULL,'OPERATIONAL',352,'352 m away',0,25.7490696,71.3958621,'P9XW+J8H, High School Road, Railway Colony, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2288,13,2,'ChIJge4r7go7RDkRmYNLIqDom6Y','Antari Devi Girl\'s Sen. Seconder School Barmer',NULL,NULL,'OPERATIONAL',371,'371 m away',0,25.7495565,71.3943559,'MBC Girls College, near, Laxmipura, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2289,13,2,'ChIJjUQd4D07RDkRkRSGuiWPcRM','VIRAJ',NULL,NULL,'OPERATIONAL',476,'476 m away',NULL,25.7494940,71.3929594,'P9XV+Q5W','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2290,13,2,'ChIJidcJf7c6RDkRrHX-kXFynJ4','Ramubai Ganesh Mal Golechha, Govt. Secondary School',NULL,NULL,'OPERATIONAL',644,'644 m away',NULL,25.7512797,71.4030485,'QC23+G67, Adarsh Stadium Road, Nehru Nagar, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2291,13,2,'ChIJq0QB3aI6RDkR4SOQbn3w0CA','aasha children kingd',NULL,NULL,'CLOSED_TEMPORARILY',1317,'1.3 km away',NULL,25.7407831,71.3929883,'P9RV+859, Kalyanpura, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2292,13,2,'ChIJpcx9xak6RDkRwPtlayf3DpY','Govt. Senior Secondary School Railway Kunwa No. 3',NULL,NULL,'CLOSED_TEMPORARILY',1335,'1.3 km away',NULL,25.7521364,71.3833556,'Railway kunwa, no 3, Gehoon Road, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2293,13,3,'ChIJ0yacMLs6RDkRA4_2wsRlGpE','Hotel Kalinga Palace',4.0,1443,'OPERATIONAL',673,'673 m away',1,25.7462020,71.3954020,'Rly. Station, opposite Barmer, Station Road, Barmer','[\"lodging\",\"bar\",\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',1,NULL,'2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2294,13,3,'ChIJpbE7X6U6RDkREmi_3vFcKqM','Laziz Pizza',3.9,812,'OPERATIONAL',436,'436 m away',0,25.7497397,71.3932460,'Shop No. 1,2 and 3, girls college road Vishwakarma circle, Ray Colony, Barmer','[\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',1,NULL,'2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2295,13,3,'ChIJOblC-s46RDkR2j6i9vb7j74','K K Hotel',3.9,110,'OPERATIONAL',1915,'1.9 km away',NULL,25.7572657,71.4149466,'National Highway 68, Mahaveer Nagar, Barmer','[\"lodging\",\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',1,NULL,'2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2296,13,3,'ChIJtZHLZwA7RDkRm_b9GejsSsk','माचरा भोजनालय',NULL,NULL,'OPERATIONAL',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2297,13,3,'ChIJx_qDcgA7RDkRn5eFaYO3pWA','प्रकाश चन्द्र मीणा टुकड़ी वाला बाड़मेर सामुडा सोराया है',NULL,NULL,'OPERATIONAL',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"meal_takeaway\",\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2298,13,3,'ChIJWXMzSwA7RDkRli3rDMSG4Zc','𝓗𝓪𝓻𝓲𝓼𝓱 𝓳𝓪𝓴𝓱𝓪𝓻',NULL,NULL,'CLOSED_TEMPORARILY',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2299,13,3,'ChIJia9Vd3k7RDkRBMZ_IONgGjs','करणी रेस्टोरेंट पूरोहित रेस्टोरेंट',NULL,NULL,'CLOSED_TEMPORARILY',0,'Distance unavailable',NULL,25.7521467,71.3966865,'आईसर कपनी, बाड़मेर','[\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2300,13,3,'ChIJ-ehbZAA7RDkRcPD9lMUiJVs','ढाबा देसी तड़का',NULL,NULL,'CLOSED_TEMPORARILY',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Khema-Ka-Kuwa, Jodhpur - Barmer Road, Pal, Jodhpur','[\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2301,13,3,'ChIJmYpaMAA7RDkR4uJ8m1BZwY0','Balaji sikim road new baypas Barmer',NULL,NULL,'CLOSED_TEMPORARILY',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Q92W+VM3, Balaji sikim road, new baypas, बाड़मेर','[\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2302,13,3,'ChIJyTk-6lQ7RDkRV64oHCzZnRU','Taste Buds',NULL,NULL,'CLOSED_TEMPORARILY',0,'Distance unavailable',NULL,25.7521467,71.3966865,'M.S, Ramaiah Enclave, 44/2, Hesarghatta Road, Barmer','[\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2303,13,3,'ChIJuVQ8NUE7RDkREQNKoomfy7I','Thar Restaurant Barmer',NULL,NULL,'OPERATIONAL',0,'Distance unavailable',NULL,25.7521467,71.3966865,'near Maple Marriage Garden, Gehu Road, Barmer','[\"bakery\",\"restaurant\",\"point_of_interest\",\"food\",\"store\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2304,13,3,'ChIJHyxeawA7RDkRTZxqxceFpeg','साईं राम महाराज माजीसा मंदिर',NULL,NULL,'OPERATIONAL',0,'Distance unavailable',NULL,25.7521467,71.3966865,'में गांव क','[\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2305,13,3,'ChIJt91QMQA7RDkR5dgSHauqqow','Pappu',NULL,NULL,'CLOSED_TEMPORARILY',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2306,13,3,'ChIJQ2fiVAA7RDkRICygSZNmFYM','गोस्वामी होटल सोनड़ी',NULL,NULL,'CLOSED_TEMPORARILY',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2307,13,3,'ChIJW4g8rgQ7RDkR2dulruboqCo','Aasin khan',NULL,NULL,'CLOSED_TEMPORARILY',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:57:34','2026-05-27 21:57:34','2026-05-20 21:57:34','2026-05-20 21:57:34'),
(2308,13,4,'ChIJVfEPba86RDkRTmzZct3vSIA','Axis Bank Branch',4.2,53,'OPERATIONAL',243,'243 m away',0,25.7516068,71.3943346,'Goswami Tower, Rai Colony Road, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2309,13,4,'ChIJ93o73q86RDkRmEBX_ZBAMIU','Union Bank of India',3.9,53,'OPERATIONAL',266,'266 m away',0,25.7514700,71.3941380,'Ward No-3, Barmer Main Laxmipura, Road, Ray Colony, Barmer','[\"bank\",\"atm\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2310,13,4,'ChIJ0aDYF6g6RDkRaYmbReSwbyY','Kotak Mahindra Bank',3.7,49,'OPERATIONAL',232,'232 m away',0,25.7515208,71.3944753,'Dev Tower\",Laxmi Nagar, Road, Main, Ray Colony, Barmer','[\"bank\",\"insurance_agency\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2311,13,4,'ChIJkTS-BrE6RDkRqBkPGqChY-4','SBI Branch Barmer Collectorate',4.4,30,'OPERATIONAL',1442,'1.4 km away',0,25.7600376,71.4081090,'Sbi, Circuit House Road, Collectrate Campus, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2312,13,4,'ChIJ7wKwU6I6RDkRHQN_Ofsw1t0','SBI Branch Barmer',3.9,69,'OPERATIONAL',1701,'1.7 km away',0,25.7376800,71.3911580,'Ci, Pratap Ji Ki Pole, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2313,13,4,'ChIJxQJeX6Q6RDkRNx-ELk166hE','SBI Bank',4.2,32,'OPERATIONAL',1612,'1.6 km away',0,25.7416164,71.4077451,'SH 40, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2314,13,4,'ChIJO8ayiqQ6RDkRohxy3CfNtfw','Bank of Baroda',3.9,28,'OPERATIONAL',1039,'1.0 km away',0,25.7449727,71.3900321,'Barmer, SH-112, Barmer Road, Barmer, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2315,13,4,'ChIJgxIwbKQ6RDkRamWVTb2GLWw','ICICI Bank Gandhi Chowk, Barmer-Branch & ATM',4.0,14,'OPERATIONAL',1037,'1.0 km away',0,25.7451008,71.3899053,'Gandhi Chowk, 0, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2316,13,4,'ChIJceMyEM86RDkR4pcwcclFl2s','Andhra Bank',4.4,12,'OPERATIONAL',1785,'1.8 km away',0,25.7546248,71.4142947,'GROUND FLOOR, BB-3 Mahaveer Nagar, NH-15, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2317,13,4,'ChIJ4a14L8Q6RDkR0waChtxchbA','UCO Bank',3.8,36,'OPERATIONAL',1638,'1.6 km away',0,25.7487178,71.4125892,'Barmer, NH-15, Barmer Road, Barmer, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2318,13,4,'ChIJ29UtZM86RDkRkJlDbjItj9Y','Axis Bank ATM',3.8,5,'OPERATIONAL',1731,'1.7 km away',1,25.7519813,71.4139734,'Goswami Tower, Road, Ray Colony, Barmer','[\"atm\",\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2319,13,4,'ChIJD8ed4K86RDkRdleaErAwzBI','CENTRAL BANK OF INDIA - BARMER Branch',3.7,18,'OPERATIONAL',1637,'1.6 km away',0,25.7485863,71.4125490,'near ahaar bojanalay, Chindru churaiya, near ahaar bojanalay, Krishi Mandi Road, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2320,13,4,'ChIJUbJaaKQ6RDkRdBrwu1erllg','IDBI Bank',3.9,27,'CLOSED_TEMPORARILY',1022,'1.0 km away',NULL,25.7451469,71.3900667,'Arihant Tower Opp Customs Check Post, Station Road, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2321,13,4,'ChIJn6qqatZoaTkRRYykhkQfm-0','ICICI Bank Ltd.,Barmer-Gandhi chowk',2.2,6,'OPERATIONAL',1089,'1.1 km away',0,25.7449403,71.3893260,'ICICI Bank Ltd., Gandhi Chowk,Barmer - 344001 #VALUE!, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2322,13,5,'ChIJq6qq6qw6RDkRn-TBS9mpBck','Jasnath Provision & Kirana Store Barmer',4.1,84,'OPERATIONAL',1150,'1.2 km away',0,25.7601101,71.3893627,'Q96Q+2PW, Indra Nagar, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"store\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2323,13,5,'ChIJiSLr7FA7RDkRAL0Tgw_xA0A','Karni Kirana Store',4.8,6,'OPERATIONAL',570,'570 m away',NULL,25.7572651,71.3969238,'34, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"store\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2324,13,5,'ChIJXWMQY2M7RDkR1lFEBlbXWUI','Balaji handloom',4.6,24,'OPERATIONAL',813,'813 m away',0,25.7453488,71.3937109,'opposite kailash sarover hotel, Station Road, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"store\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2325,13,5,'ChIJnxoTe5Q6RDkRPt8rJa3lnTQ','Jansukh Cart',5.0,4,'OPERATIONAL',1995,'2.0 km away',0,25.7345456,71.4005388,'opp. Thar Hospital, H.NO. 48 NH 68, opp. Thar Hospital, Shastri Nagar, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"store\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2326,13,5,'ChIJAQcl9MY6RDkRHB12W5pwSpw','Ramesh Traders Barmer',4.5,15,'OPERATIONAL',1407,'1.4 km away',0,25.7490776,71.4103203,'PCX6+J4P, Nehru Nagar, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"store\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2327,13,5,'ChIJq6qq6qw6RDkRb1w7yE18Phg','Bhagwati Hinglaj Provision',3.7,3,'OPERATIONAL',1146,'1.1 km away',0,25.7602373,71.3896045,'Q96Q+3RX, Indra Nagar, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"store\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2328,13,5,'ChIJAYMr86Q6RDkRFvFS_8uJ0Os','SHIV GENERAL STORE',5.0,1,'OPERATIONAL',887,'887 m away',0,25.7454512,71.3918801,'mukand ji mandir, Near, Station Road, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"store\",\"food\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2329,13,5,'ChIJofjJlDE7RDkRoN_IZOh4kvo','Shyam Lal Sharma',NULL,NULL,'OPERATIONAL',1717,'1.7 km away',NULL,25.7522373,71.4138254,'Shyam Lal Sharma, Mahaveer Nagar, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"store\",\"food\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2330,13,5,'ChIJzaX-uWw7RDkRhVdIxEk0oNc','Maa Jagtdmba Fruit Bhndar',NULL,NULL,'OPERATIONAL',1728,'1.7 km away',NULL,25.7523913,71.4139340,'16, Sindhary Choraha','[\"supermarket\",\"grocery_or_supermarket\",\"store\",\"food\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2331,13,5,'ChIJMRGzv5M7RDkR73gq1J3d9-g','माँ अम्बे सैनेट्री वेयर बलदेव नगर बाड़मेर',5.0,2,'OPERATIONAL',1897,'1.9 km away',1,25.7559878,71.4151427,'QC48+93R, Baldev Nagar, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"store\",\"food\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2332,13,5,'ChIJTZO2h2s7RDkRKmOmhxot_7A','Hanuman Ram',NULL,NULL,'OPERATIONAL',1994,'2.0 km away',NULL,25.7517424,71.4165943,'Hanuman Ram, Sindhari Road, Baldev Nagar, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"store\",\"food\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2333,13,6,'ChIJ_eUR7a07RDkRy1kF_2i9RAU','Mahaveer Park',4.2,103,'OPERATIONAL',136,'136 m away',NULL,25.7525125,71.3979844,'Madhuban Colony, P S Parisar Colony, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2334,13,6,'ChIJsa3eXwA7RDkRVlLxfZMQu_w','भामाशाह लीलाराम जांगिड़ स्मृति पार्क',4.5,112,'OPERATIONAL',1378,'1.4 km away',0,25.7398429,71.3983323,'1424, Krishi Mandi Road, Shastri Nagar, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2335,13,6,'ChIJ8eEWsbc6RDkRlevOoZ_Z6Vk','Mahaveer Park',4.2,863,'OPERATIONAL',811,'811 m away',0,25.7541835,71.4044612,'QC33+MQG, Nehru Nagar, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2336,13,6,'ChIJ6dYbGOk7RDkRcmz917gO-2o','ओपन एयर जिम (आदर्श स्टेडियम), बाड़मेर',4.4,11,'OPERATIONAL',775,'775 m away',NULL,25.7545544,71.4039465,'QC33+XR3, Ambedkar Colony, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2337,13,6,'ChIJGd9N35s7RDkRp-_jpfDrvvs','Lt General Hanut Singh PVSM Mahavir Chakra Park',4.4,21,'OPERATIONAL',1596,'1.6 km away',1,25.7561273,71.4120022,'900/6, Ambedkar Colony, Mahaveer Nagar, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2338,13,6,'ChIJ5cP_WVE7RDkRFEPGjuOSDN8','Maa Shera Wali Garba Ground',4.8,12,'OPERATIONAL',1756,'1.8 km away',NULL,25.7567116,71.4134717,'1157, Ambedkar Colony, Mahaveer Nagar, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2339,13,6,'ChIJOcXekaA6RDkRa7Ohy8sRpGc','Son Naadi Park',4.1,29,'OPERATIONAL',1833,'1.8 km away',NULL,25.7407728,71.3834380,'P9RM+894, Venasar Naadi, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2340,13,6,'ChIJN_1YDAA7RDkROhdU2EU7NHo','Ugararam Rathore Rana',NULL,NULL,'OPERATIONAL',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2341,13,6,'ChIJ6dEwbQA7RDkRMSheyro4FmE','Magraj beniwal',NULL,NULL,'OPERATIONAL',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2342,13,6,'ChIJPayqnj07RDkRdSlE3J7aCSc','आयुष्मान भारत सूर्यनमस्कार प्रतीक',NULL,NULL,'OPERATIONAL',134,'134 m away',NULL,25.7509766,71.3969922,'new, hanuwant school road, Derasar','[\"park\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2343,13,6,'ChIJ____5LA6RDkRoac5qE405Fs','Public Park',NULL,NULL,'OPERATIONAL',172,'172 m away',NULL,25.7528555,71.3982092,'Q93X+47W, Madhuban Colony, P S Parisar Colony, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2344,13,6,'ChIJx-4CLwA7RDkRhTTjF4jEZeE','I LOVE BARMER',5.0,2,'OPERATIONAL',176,'176 m away',NULL,25.7527676,71.3983082,'Q93X+483, P S Parisar Colony, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2345,13,6,'ChIJgWV3JQAlRDkRPuRQGB0EX6k','Park',3.0,2,'OPERATIONAL',1436,'1.4 km away',NULL,25.7649061,71.3944619,'Q97V+XQ8, Hinglaj Nagar, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2346,13,6,'ChIJT6niBLo7RDkRFXPQp2caQPo','Barmer pradrsini park',3.0,5,'OPERATIONAL',1814,'1.8 km away',NULL,25.7522847,71.4147956,'QC27+WW7, Baldev Nagar, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2347,13,6,'ChIJhWrJdt47RDkRo1odcGABylI','कबूतरों का चबूतरा',NULL,NULL,'OPERATIONAL',1924,'1.9 km away',NULL,25.7590617,71.4142967,'QC57+JPF, Ambedkar Colony, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:57:35','2026-05-27 21:57:35','2026-05-20 21:57:35','2026-05-20 21:57:35'),
(2348,13,7,'ChIJvSfDPwA7RDkRq6lhDq5GuH8','Revital Zone Gym',4.9,128,'OPERATIONAL',833,'833 m away',0,25.7470827,71.3905612,'258/6, Harijan Basti, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:36','2026-05-27 21:57:36','2026-05-20 21:57:36','2026-05-20 21:57:36'),
(2349,13,7,'ChIJx00eWLc7RDkROGcSFPmaZvc','M S SODHA GYM',4.5,159,'OPERATIONAL',676,'676 m away',0,25.7461203,71.3957650,'5th Floor, Bhagwati Complex, Station Road, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:36','2026-05-27 21:57:36','2026-05-20 21:57:36','2026-05-20 21:57:36'),
(2350,13,7,'ChIJKX1nBPs7RDkR3_dBhXBNAic','ShreeRam GYM - Gym & Fitness Centre',4.9,469,'OPERATIONAL',1559,'1.6 km away',0,25.7551479,71.4118882,'Second Floor, City Centre, Mahaveer Nagar, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:36','2026-05-27 21:57:36','2026-05-20 21:57:36','2026-05-20 21:57:36'),
(2351,13,7,'ChIJuVCD6VA7RDkRy5EjtVKzQIw','The Dance Factory Barmer',5.0,64,'OPERATIONAL',1821,'1.8 km away',0,25.7583179,71.4135301,'behind costume quarters, Ambedkar Colony, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:36','2026-05-27 21:57:36','2026-05-20 21:57:36','2026-05-20 21:57:36'),
(2352,13,7,'ChIJT91d5uo6RDkR6D3b5N24r0Y','KDM GYM',4.5,330,'OPERATIONAL',1953,'2.0 km away',0,25.7379877,71.4082267,'Sodha Form house, near St. Paul\'s School, Shivkar Road, Dangriya, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:36','2026-05-27 21:57:36','2026-05-20 21:57:36','2026-05-20 21:57:36'),
(2353,13,7,'ChIJv7C65ho7RDkR6chaDoKrl-s','Nehru Yuva Kendra Gym, Barmer',4.8,4,'OPERATIONAL',327,'327 m away',0,25.7539764,71.3992490,'Q93X+HMX, Madhuban Colony, P S Parisar Colony, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:36','2026-05-27 21:57:36','2026-05-20 21:57:36','2026-05-20 21:57:36'),
(2354,13,7,'ChIJD-QuhgI7RDkRQSAv_kcxWNs','VIP Gym',4.0,52,'OPERATIONAL',233,'233 m away',0,25.7518161,71.3943939,'Q92V+PQC, Laxmi Nagar, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:36','2026-05-27 21:57:36','2026-05-20 21:57:36','2026-05-20 21:57:36'),
(2355,13,7,'ChIJXS5-seM7RDkRQM0VdPoRxik','The fitness zone',4.2,52,'OPERATIONAL',1931,'1.9 km away',0,25.7353759,71.3916828,'Partap Ji Ki Prol Road, Pratap Ji Ki Pole, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:36','2026-05-27 21:57:36','2026-05-20 21:57:36','2026-05-20 21:57:36'),
(2356,13,7,'ChIJnbeOBIo7RDkR7mPazcsEu14','Vicky health & nutrition centre',4.0,8,'OPERATIONAL',1390,'1.4 km away',0,25.7396755,71.3956955,'NEAR THAR GAS AGENCY, CO-OPERATIVE MARKETING SOCIETY, SHOP NO 12, FIRST FLOOR, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:36','2026-05-27 21:57:36','2026-05-20 21:57:36','2026-05-20 21:57:36'),
(2357,13,7,'ChIJB2-zVgA7RDkRMZc-BcRwHEU','खोडाल',NULL,NULL,'CLOSED_TEMPORARILY',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:57:36','2026-05-27 21:57:36','2026-05-20 21:57:36','2026-05-20 21:57:36'),
(2358,13,7,'ChIJz2bCWwA7RDkRjR49MLZTDrQ','EX.Hari Singh Bhati ka vaas',NULL,NULL,'CLOSED_TEMPORARILY',0,'Distance unavailable',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:57:36','2026-05-27 21:57:36','2026-05-20 21:57:36','2026-05-20 21:57:36'),
(2359,13,7,'ChIJbclBMgA7RDkR6dFzaibUY5c','HEALTH AND FITNESS CENTER BARMER',5.0,1,'OPERATIONAL',686,'686 m away',0,25.7460474,71.3956744,'SHOP No.- 408, 4TH FLOOR, BHAGATI COMPLEX, Railway, स्टेशन मार्ग, बाड़मेर','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:57:36','2026-05-27 21:57:36','2026-05-20 21:57:36','2026-05-20 21:57:36'),
(2360,13,7,'ChIJd3WiFuI7RDkRPtLnZElocBY','Revital Store : Buy Branded Supplements & Nutrition Products At Best Price & 100% Genuine In Barmer',5.0,2,'OPERATIONAL',720,'720 m away',0,25.7491806,71.3902956,'in front of Rai Colony School, Panch Batti Cricle, Barmer','[\"gym\",\"health\",\"store\",\"point_of_interest\",\"food\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:57:36','2026-05-27 21:57:36','2026-05-20 21:57:36','2026-05-20 21:57:36'),
(2361,13,9,'ChIJ12Xvn7s6RDkRjUud9Q7F_HM','Barmer',4.4,1882,'OPERATIONAL',650,'650 m away',NULL,25.7463500,71.3975400,'Station Road, Nehru Nagar, Barmer','[\"train_station\",\"transit_station\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:57:37','2026-05-27 21:57:37','2026-05-20 21:57:37','2026-05-20 21:57:37'),
(2362,4,1,'ChIJdefsZ9U7RDkRlyv0QAguy7c','BARMER JOINTS TRAUMA AND DENTAL CARE HOSPITAL',4.9,428,'OPERATIONAL',610,'610 m away',1,25.7503293,71.3922418,'Vishvkarma Circle, Ray Colony, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:02','2027-05-20 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2363,4,1,'ChIJf4wn7fo7RDkRb-LOXn3t6VI','Massa-bawasir rog nivaran kendra',5.0,34,'OPERATIONAL',514,'514 m away',0,25.7486029,71.3897425,'Near, Panch batti circle, Ray Colony, Barmer','[\"hospital\",\"doctor\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:02','2027-05-20 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2364,4,1,'ChIJ45xn7JU7RDkRW9ELgUZKxxk','Sex specialist hospital',4.9,35,'OPERATIONAL',515,'515 m away',0,25.7486055,71.3897466,'MEDICOSE, KHATRI, NEAR, PANCH BATTI CIRCLE, Barmer','[\"hospital\",\"doctor\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:02','2027-05-20 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2365,4,1,'ChIJx32Bm7o6RDkR-Sa4_Gw0K1o','Dr sawai singh Rathore Orthopaedic surgeon',4.4,68,'OPERATIONAL',837,'837 m away',0,25.7503999,71.3946279,'Govt.hospital barmer, campus, Gandhi Nagar, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:02','2027-05-20 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2366,4,1,'ChIJT5GJxuM7RDkR5mEtzLvHM5k','DR.GAJENDRA SONI HOSPITAL',5.0,12,'OPERATIONAL',516,'516 m away',0,25.7485777,71.3897281,'Near, panch batti circle, Ray Colony, Barmer','[\"hospital\",\"doctor\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:02','2027-05-20 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2367,4,1,'ChIJ8YBE7686RDkRE7h4FPF_pL4','Khatri Dental Clinic',4.8,25,'OPERATIONAL',725,'725 m away',0,25.7509016,71.3936117,'Roy Colony Road, Railway Colony, Barmer','[\"hospital\",\"dentist\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:02','2027-05-20 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2368,4,1,'ChIJayDveVg7RDkRFjsfQyBfQa8','Navjeevan Multi Speciality & Maternity Hospital',3.7,3,'OPERATIONAL',762,'762 m away',1,25.7514438,71.3940802,'Q92V+HJG, above Union Bank, Ray Colony, Barmer','[\"hospital\",\"doctor\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:02','2027-05-20 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2369,4,1,'ChIJtzEjLr06RDkRm4Fp3ZiXuAA','Matru Dental Clinic and Physiotherapy Center',4.1,13,'OPERATIONAL',1514,'1.5 km away',NULL,25.7408430,71.3948417,'P9RV+8WP, Krishi Mandi Road, Kalyanpura, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:02','2027-05-20 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2370,4,1,'ChIJ2SLlUQA7RDkRRJUQ-dA6dLc','Mehmud K Nurani',NULL,NULL,'OPERATIONAL',363,'363 m away',1,25.7489757,71.3860240,'P9XP+HCR, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:59:02','2027-05-20 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2371,4,1,'ChIJofIDnB87RDkROaubzmK4yzM','KHATRI MEDICALS',5.0,1,'OPERATIONAL',515,'515 m away',0,25.7485765,71.3897170,'Near, panch batti circle, Ray Colony, Barmer','[\"drugstore\",\"pharmacy\",\"hospital\",\"veterinary_care\",\"doctor\",\"health\",\"store\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:59:02','2027-05-20 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2372,4,1,'ChIJoxheZgY7RDkRiJB7XkJD-zs','Meghani Enterprises',NULL,NULL,'OPERATIONAL',585,'585 m away',NULL,25.7517972,71.3923428,'Q92R+PW8, Unnamed Road, krishna Nagar, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:59:02','2027-05-20 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2373,4,1,'ChIJGUrZ86o6RDkRlTDjHjYfqlQ','Satyam Health Care',NULL,NULL,'OPERATIONAL',653,'653 m away',NULL,25.7577125,71.3842656,'Q95M+3PJ, Tejaji Nagar, Indra Nagar, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:59:02','2027-05-20 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2374,4,1,'ChIJM5U3NwA7RDkROoR-clM6BWE','Shree Chandra medicose',NULL,NULL,'OPERATIONAL',687,'687 m away',NULL,25.7504243,71.3930839,'11/6, 11/6, Roy Colony Road, Railway Colony, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:59:02','2027-05-20 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2375,4,1,'ChIJb_puQ_g7RDkRdKmVLauHeRk','नाभी रेकी सेंटर',5.0,1,'OPERATIONAL',696,'696 m away',1,25.7473588,71.3909136,'Madhukar bhavan, Ramdev welding ke pass, ke puchhe, Barmer','[\"hospital\",\"health\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:59:02','2027-05-20 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2376,4,1,'ChIJK4BfDRYxRDkRLUn_FjWfpgc','GOYAL MEDICAL STORE',5.0,1,'OPERATIONAL',701,'701 m away',0,25.7546826,71.3800837,'Genhu Road, Daroora, Barmer','[\"hospital\",\"doctor\",\"health\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:59:02','2027-05-20 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2377,4,2,'ChIJKX0mWa86RDkRfKCC1U6EkXk','Siddharth Gurukul Sr. Sec. Barmer, Rajasthan',4.4,39,'OPERATIONAL',413,'413 m away',0,25.7495817,71.3894311,'Ward No, 51, Roy Colony Road, Ray Colony, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:02','2026-05-27 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2378,4,2,'ChIJo3bMIKU7RDkR76KjXKix9N8','Nirjara music classes',4.7,3,'OPERATIONAL',445,'445 m away',0,25.7497732,71.3900451,'652, 7, krishna Nagar, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:02','2026-05-27 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2379,4,2,'ChIJMT02HAA7RDkRkFd6p1biqwk','B R BIRLA PUBLIC SCHOOL',NULL,NULL,'OPERATIONAL',0,'Distance unavailable',NULL,25.7522057,71.3865196,'Q92P+VJJ, Ray Colony, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:59:02','2026-05-27 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2380,4,2,'ChIJbR6fUAA7RDkRx35rkqb_rDw','THE KNOWLEDGE INTERNATIONAL SCHOOL',NULL,NULL,'OPERATIONAL',0,'Distance unavailable',NULL,25.7522057,71.3865196,'83, Lala lajpat rai colony, 5th road, eidgah, Jodhpur','[\"school\",\"point_of_interest\",\"establishment\"]',0,'suspicious_same_location','2026-05-20 21:59:02','2026-05-27 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2381,4,2,'ChIJ7VyJmDc7RDkRq6M6QmoTD8o','Government upper primary school, Rai colony',NULL,NULL,'OPERATIONAL',15,'<50 m away',NULL,25.7522867,71.3866411,'Q92P+WM6, Ray Colony, Barmer','[\"primary_school\",\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:59:02','2026-05-27 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2382,4,2,'ChIJw752_BI7RDkR3ZmfFbmcZW4','e-ZONE PLAY & PUBLIC SCHOOL',NULL,NULL,'OPERATIONAL',103,'103 m away',NULL,25.7514020,71.3860067,'Gulab ji ki hotel, Sardarpura, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:59:02','2026-05-27 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2383,4,2,'ChIJpcx9xak6RDkRwPtlayf3DpY','Govt. Senior Secondary School Railway Kunwa No. 3',NULL,NULL,'CLOSED_TEMPORARILY',317,'317 m away',NULL,25.7521364,71.3833556,'Railway kunwa, no 3, Gehoon Road, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:59:02','2026-05-27 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2384,4,2,'ChIJ--X1e887RDkRwKicFy9nINI','Aditya Nobles Academy Upper Primary School',NULL,NULL,'OPERATIONAL',375,'375 m away',NULL,25.7533552,71.3829967,'Ward No.39, Barmer','[\"primary_school\",\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:59:02','2026-05-27 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2385,4,2,'ChIJuW0gvSk7RDkRYatR_cR0j0k','Alok bal sadan secondry school barmer',NULL,NULL,'OPERATIONAL',412,'412 m away',NULL,25.7487234,71.3879294,'P9XQ+F5M, Sardarpura, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:59:02','2026-05-27 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2386,4,2,'ChIJG786eZQ7RDkRs6jYSWnwfOY','Government Primary School Pipaji Ka Mandir',NULL,NULL,'OPERATIONAL',422,'422 m away',NULL,25.7495467,71.3895280,'Ward No, 51, Roy Colony Road, Ray Colony, Barmer','[\"primary_school\",\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:59:02','2026-05-27 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2387,4,2,'ChIJqRcNdqg6RDkRNer-fkUElJg','Mother Vageesha School',NULL,NULL,'OPERATIONAL',432,'432 m away',NULL,25.7488199,71.3843967,'P9XM+GQC, Daroora, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:59:02','2026-05-27 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2388,4,2,'ChIJMf-eB5k7RDkRC0ETcrjYks8','Madarsa Darul Uloom Ziyaul Mustafa',NULL,NULL,'OPERATIONAL',474,'474 m away',1,25.7546395,71.3826283,'Q94M+62Q, masjid e abbas railwaiy kuaa no 3, Daroora, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:59:02','2026-05-27 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2389,4,2,'ChIJfzEm16U6RDkRRPJo03-VF6I','Nootan Vidhya Mandir',NULL,NULL,'OPERATIONAL',502,'502 m away',0,25.7480685,71.3885293,'Roy Colony Street, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:59:02','2026-05-27 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2390,4,2,'ChIJq0QB3aI6RDkR4SOQbn3w0CA','aasha children kingd',NULL,NULL,'CLOSED_TEMPORARILY',1426,'1.4 km away',NULL,25.7407831,71.3929883,'P9RV+859, Kalyanpura, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:59:02','2026-05-27 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2391,4,2,'ChIJidcJf7c6RDkRrHX-kXFynJ4','Ramubai Ganesh Mal Golechha, Govt. Secondary School',NULL,NULL,'OPERATIONAL',1659,'1.7 km away',NULL,25.7512797,71.4030485,'QC23+G67, Adarsh Stadium Road, Nehru Nagar, Barmer','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:59:02','2026-05-27 21:59:02','2026-05-20 21:59:02','2026-05-20 21:59:02'),
(2392,4,3,'ChIJ0yacMLs6RDkRA4_2wsRlGpE','Hotel Kalinga Palace',4.0,1443,'OPERATIONAL',1112,'1.1 km away',1,25.7462020,71.3954020,'Rly. Station, opposite Barmer, Station Road, Barmer','[\"lodging\",\"bar\",\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',1,NULL,'2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2393,4,3,'ChIJpbE7X6U6RDkREmi_3vFcKqM','Laziz Pizza',3.9,812,'OPERATIONAL',727,'727 m away',0,25.7497397,71.3932460,'Shop No. 1,2 and 3, girls college road Vishwakarma circle, Ray Colony, Barmer','[\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',1,NULL,'2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2394,4,3,'ChIJ89ifk887RDkRBA01fNhMjpM','shiv sanker fast food juice and shake',5.0,5,'OPERATIONAL',787,'787 m away',0,25.7513402,71.3943150,'Q92V+GPP, Roy Colony Road, Roy Colony Street, Barmer','[\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',1,NULL,'2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2395,4,3,'ChIJgXHfH7A6RDkR9EoyadV42nU','Maharaja Restaurant',3.9,67,'OPERATIONAL',777,'777 m away',0,25.7513021,71.3942111,'Q92V+GMG, Roy Colony Road, Roy Colony Street, Barmer','[\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',1,NULL,'2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2396,4,3,'ChIJtU0eO7A6RDkRq2wYUDZg-B8','Laxmi Chinese Food',4.8,8,'OPERATIONAL',869,'869 m away',0,25.7523514,71.3951905,'Parsuram marg, Ray Colony, Barmer','[\"meal_takeaway\",\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',1,NULL,'2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2397,4,3,'ChIJnyq-IQA7RDkR4rvCOoNxro0','99 variety doss',4.8,8,'OPERATIONAL',875,'875 m away',NULL,25.7528820,71.3952227,'472/2, 472/2, Shiv Temple Road, Madhuban Colony, P S Parisar Colony, Barmer','[\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',1,NULL,'2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2398,4,3,'ChIJVZ2YXaQ6RDkRRL4jQI33ohA','Kheteshwar mirchiwada',4.2,22,'OPERATIONAL',864,'864 m away',0,25.7454413,71.3907558,'P9WR+58C, Station Road, Harijan Basti, Barmer','[\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',1,NULL,'2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2399,4,3,'ChIJOblC-s46RDkR2j6i9vb7j74','K K Hotel',3.9,110,'OPERATIONAL',2902,'2.9 km away',NULL,25.7572657,71.4149466,'National Highway 68, Mahaveer Nagar, Barmer','[\"lodging\",\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',1,NULL,'2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2400,4,3,'ChIJpSRKGIs7RDkRKGJG63NCB9s','JAI MAA AMBE TIFFIN CENTRE',4.1,8,'OPERATIONAL',593,'593 m away',NULL,25.7510662,71.3923081,'Q92R+CWF, Ray Colony, Barmer','[\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',1,NULL,'2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2401,4,3,'ChIJGaWHewA7RDkRn5rJu_aaPkg','Della restaurant',3.6,24,'OPERATIONAL',763,'763 m away',0,25.7517705,71.3941223,'5th floor, omega Tower, Ray Colony, Barmer','[\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',1,NULL,'2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2402,4,3,'ChIJx9eDAjo7RDkREgTN2qmsG8s','Maa Oshiya Tiffin Service',3.5,8,'CLOSED_TEMPORARILY',433,'433 m away',NULL,25.7500147,71.3900928,'Ward No, 51, Roy Colony Road, Ray Colony, Barmer','[\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',1,NULL,'2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2403,4,3,'ChIJi0wiXYk7RDkR-BlRs-mGga4','SAWAI',NULL,NULL,'OPERATIONAL',140,'140 m away',NULL,25.7512059,71.3856665,'Sawai Gheoun Road 340001, Barmer','[\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',0,'unrated','2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2404,4,3,'ChIJk-Nk5Eo7RDkRK2jmpFqSMxQ','THE LAZONA RESTRO CAFE',2.9,43,'OPERATIONAL',577,'577 m away',0,25.7499544,71.3917065,'3rd Floor, Hitkari Heights, near Bhawani Giri Math, Road, Ray Colony, Barmer','[\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2405,4,3,'ChIJSaGWIIM7RDkRng_lWGtumUY','HINGLAJ NASTA CORNOR',5.0,1,'OPERATIONAL',867,'867 m away',0,25.7452436,71.3904141,'HINGLAJ NASTA CORNER, Station Road, Harijan Basti, Barmer','[\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2406,4,3,'ChIJCRiKaAg7RDkR4-1_h0W5sCk','Maraj nasta house',NULL,NULL,'OPERATIONAL',867,'867 m away',NULL,25.7451267,71.3901495,'Gandhi Chowk, Barmer','[\"restaurant\",\"point_of_interest\",\"food\",\"establishment\"]',0,'unrated','2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2407,4,4,'ChIJVfEPba86RDkRTmzZct3vSIA','Axis Bank Branch',4.2,53,'OPERATIONAL',786,'786 m away',0,25.7516068,71.3943346,'Goswami Tower, Rai Colony Road, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2408,4,4,'ChIJ93o73q86RDkRmEBX_ZBAMIU','Union Bank of India',3.9,53,'OPERATIONAL',767,'767 m away',0,25.7514700,71.3941380,'Ward No-3, Barmer Main Laxmipura, Road, Ray Colony, Barmer','[\"bank\",\"atm\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2409,4,4,'ChIJ7wKwU6I6RDkRHQN_Ofsw1t0','SBI Branch Barmer',3.9,69,'OPERATIONAL',1681,'1.7 km away',0,25.7376800,71.3911580,'Ci, Pratap Ji Ki Pole, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2410,4,4,'ChIJzZqhAqk6RDkR4iaK7GqDQb8','AU Small Finance Bank',4.1,25,'OPERATIONAL',767,'767 m away',0,25.7516389,71.3941553,'Ground Floor, Goswami Tower, beside Airtel Office, Roy Colony Road, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2411,4,4,'ChIJ0aDYF6g6RDkRaYmbReSwbyY','Kotak Mahindra Bank',3.7,49,'OPERATIONAL',800,'800 m away',0,25.7515208,71.3944753,'Dev Tower\",Laxmi Nagar, Road, Main, Ray Colony, Barmer','[\"bank\",\"insurance_agency\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2412,4,4,'ChIJC3yEU2eabzkRaH8QKDj9s1Q','ICICI Bank Gandhi Chowk, Barmer-Branch & ATM',4.1,23,'OPERATIONAL',855,'855 m away',0,25.7449403,71.3893260,'Gandhi Chowk, Barmer 0, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2413,4,4,'ChIJO8ayiqQ6RDkRohxy3CfNtfw','Bank of Baroda',3.9,28,'OPERATIONAL',878,'878 m away',0,25.7449727,71.3900321,'Barmer, SH-112, Barmer Road, Barmer, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2414,4,4,'ChIJ6zBuqVE7RDkRiVOeJ3-lB6k','Indian Overseas Bank - ATM',3.7,3,'OPERATIONAL',732,'732 m away',1,25.7514262,71.3937808,'Goswami Tower, opposite Civil Hospital Building, Roy Colony Road, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2415,4,4,'ChIJUbJaaKQ6RDkRdBrwu1erllg','IDBI Bank',3.9,27,'CLOSED_TEMPORARILY',862,'862 m away',NULL,25.7451469,71.3900667,'Arihant Tower Opp Customs Check Post, Station Road, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2416,4,4,'ChIJq6qqHqk6RDkRNwP0WgBZ4hg','Vakrangee Kendra',1.5,2,'OPERATIONAL',15,'<50 m away',0,25.7522867,71.3866411,'Ward No 31, Barmer (M)','[\"bank\",\"atm\",\"insurance_agency\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2417,4,4,'ChIJJxNyIKc7RDkRRVej04TzFf0','Indian Overseas Bank',NULL,NULL,'OPERATIONAL',731,'731 m away',0,25.7514405,71.3937717,'Goswami Tower, opposite Civil Hospital Building, Road, Ray Colony, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2418,4,4,'ChIJazLj3a86RDkRkdZO92cGUjc','VANKAL TOWER',4.0,2,'CLOSED_TEMPORARILY',747,'747 m away',NULL,25.7514464,71.3939268,'Q92V+HHF, Roy Colony Street, Madhuban Colony, Ray Colony, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2419,4,4,'ChIJn6qqatZoaTkRRYykhkQfm-0','ICICI Bank Ltd.,Barmer-Gandhi chowk',2.2,6,'OPERATIONAL',855,'855 m away',0,25.7449403,71.3893260,'ICICI Bank Ltd., Gandhi Chowk,Barmer - 344001 #VALUE!, Barmer','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2420,4,4,'ChIJkS8pKZg6RDkRCCfLpltASsk','Dena Bank',2.2,19,'OPERATIONAL',1926,'1.9 km away',0,25.7362357,71.3939553,'P9PV+FHW, opp. INDIAN OIL PETROL PUMP, Chohtan Road, Barmer','[\"bank\",\"atm\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2421,4,5,'ChIJq6qq6qw6RDkRn-TBS9mpBck','Jasnath Provision & Kirana Store Barmer',4.1,84,'OPERATIONAL',924,'924 m away',0,25.7601101,71.3893627,'Q96Q+2PW, Indra Nagar, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"point_of_interest\",\"store\",\"establishment\"]',1,NULL,'2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2422,4,5,'ChIJXWMQY2M7RDkR1lFEBlbXWUI','Balaji handloom',4.6,24,'OPERATIONAL',1049,'1.0 km away',0,25.7453488,71.3937109,'opposite kailash sarover hotel, Station Road, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"point_of_interest\",\"store\",\"establishment\"]',1,NULL,'2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2423,4,5,'ChIJiSLr7FA7RDkRAL0Tgw_xA0A','Karni Kirana Store',4.8,6,'OPERATIONAL',1184,'1.2 km away',NULL,25.7572651,71.3969238,'34, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"point_of_interest\",\"store\",\"establishment\"]',1,NULL,'2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2424,4,5,'ChIJq6qq6qw6RDkRb1w7yE18Phg','Bhagwati Hinglaj Provision',3.7,3,'OPERATIONAL',945,'945 m away',0,25.7602373,71.3896045,'Q96Q+3RX, Indra Nagar, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"point_of_interest\",\"store\",\"establishment\"]',1,NULL,'2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2425,4,5,'ChIJAYMr86Q6RDkRFvFS_8uJ0Os','SHIV GENERAL STORE',5.0,1,'OPERATIONAL',923,'923 m away',0,25.7454512,71.3918801,'mukand ji mandir, Near, Station Road, Barmer','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"point_of_interest\",\"store\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:59:03','2026-05-27 21:59:03','2026-05-20 21:59:03','2026-05-20 21:59:03'),
(2426,4,6,'ChIJ_eUR7a07RDkRy1kF_2i9RAU','Mahaveer Park',4.2,103,'OPERATIONAL',1149,'1.1 km away',NULL,25.7525125,71.3979844,'Madhuban Colony, P S Parisar Colony, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:04','2026-05-27 21:59:04','2026-05-20 21:59:04','2026-05-20 21:59:04'),
(2427,4,6,'ChIJsa3eXwA7RDkRVlLxfZMQu_w','भामाशाह लीलाराम जांगिड़ स्मृति पार्क',4.5,112,'OPERATIONAL',1814,'1.8 km away',0,25.7398429,71.3983323,'1424, Krishi Mandi Road, Shastri Nagar, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:04','2026-05-27 21:59:04','2026-05-20 21:59:04','2026-05-20 21:59:04'),
(2428,4,6,'ChIJyQwq7r4xRDkRoDd623ruiGU','Barmer Hilly Memorial Park',4.3,146,'OPERATIONAL',1427,'1.4 km away',0,25.7468895,71.3735460,'P9WF+QC3, Barmer rural','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:04','2026-05-27 21:59:04','2026-05-20 21:59:04','2026-05-20 21:59:04'),
(2429,4,6,'ChIJ8eEWsbc6RDkRlevOoZ_Z6Vk','Mahaveer Park',4.2,863,'OPERATIONAL',1810,'1.8 km away',0,25.7541835,71.4044612,'QC33+MQG, Nehru Nagar, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:04','2026-05-27 21:59:04','2026-05-20 21:59:04','2026-05-20 21:59:04'),
(2430,4,6,'ChIJkaSG3PQxRDkRKFz4Bo94lUQ','Hanuman Selfie Point',4.5,4,'OPERATIONAL',1076,'1.1 km away',NULL,25.7464842,71.3778513,'P9WH+H4X, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:04','2026-05-27 21:59:04','2026-05-20 21:59:04','2026-05-20 21:59:04'),
(2431,4,6,'ChIJOcXekaA6RDkRa7Ohy8sRpGc','Son Naadi Park',4.1,29,'OPERATIONAL',1308,'1.3 km away',NULL,25.7407728,71.3834380,'P9RM+894, Venasar Naadi, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:04','2026-05-27 21:59:04','2026-05-20 21:59:04','2026-05-20 21:59:04'),
(2432,4,6,'ChIJ6dYbGOk7RDkRcmz917gO-2o','ओपन एयर जिम (आदर्श स्टेडियम), बाड़मेर',4.4,11,'OPERATIONAL',1765,'1.8 km away',NULL,25.7545544,71.4039465,'QC33+XR3, Ambedkar Colony, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:04','2026-05-27 21:59:04','2026-05-20 21:59:04','2026-05-20 21:59:04'),
(2433,4,6,'ChIJN_1YDAA7RDkROhdU2EU7NHo','Ugararam Rathore Rana',NULL,NULL,'OPERATIONAL',1018,'1.0 km away',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:59:04','2026-05-27 21:59:04','2026-05-20 21:59:04','2026-05-20 21:59:04'),
(2434,4,6,'ChIJ6dEwbQA7RDkRMSheyro4FmE','Magraj beniwal',NULL,NULL,'OPERATIONAL',1018,'1.0 km away',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:59:04','2026-05-27 21:59:04','2026-05-20 21:59:04','2026-05-20 21:59:04'),
(2435,4,6,'ChIJPayqnj07RDkRdSlE3J7aCSc','आयुष्मान भारत सूर्यनमस्कार प्रतीक',NULL,NULL,'OPERATIONAL',1058,'1.1 km away',NULL,25.7509766,71.3969922,'new, hanuwant school road, Derasar','[\"park\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:59:04','2026-05-27 21:59:04','2026-05-20 21:59:04','2026-05-20 21:59:04'),
(2436,4,6,'ChIJ____5LA6RDkRoac5qE405Fs','Public Park',NULL,NULL,'OPERATIONAL',1173,'1.2 km away',NULL,25.7528555,71.3982092,'Q93X+47W, Madhuban Colony, P S Parisar Colony, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:59:04','2026-05-27 21:59:04','2026-05-20 21:59:04','2026-05-20 21:59:04'),
(2437,4,6,'ChIJx-4CLwA7RDkRhTTjF4jEZeE','I LOVE BARMER',5.0,2,'OPERATIONAL',1182,'1.2 km away',NULL,25.7527676,71.3983082,'Q93X+483, P S Parisar Colony, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:59:04','2026-05-27 21:59:04','2026-05-20 21:59:04','2026-05-20 21:59:04'),
(2438,4,6,'ChIJ5dVyVgAxRDkREN1OitRABUA','वन विभाग स्मृति हिल्ली उद्यान बाड़मेर',NULL,NULL,'OPERATIONAL',1262,'1.3 km away',NULL,25.7566105,71.3749075,'Q94F+GXR, Genhu Road, Daroora, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:59:04','2026-05-27 21:59:04','2026-05-20 21:59:04','2026-05-20 21:59:04'),
(2439,4,6,'ChIJgWV3JQAlRDkRPuRQGB0EX6k','Park',3.0,2,'OPERATIONAL',1621,'1.6 km away',NULL,25.7649061,71.3944619,'Q97V+XQ8, Hinglaj Nagar, Barmer','[\"park\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-20 21:59:04','2026-05-27 21:59:04','2026-05-20 21:59:04','2026-05-20 21:59:04'),
(2440,4,6,'ChIJO2FUXQAvRDkRr9n9a4v9yFw','Maheshwari place',NULL,NULL,'OPERATIONAL',1868,'1.9 km away',NULL,25.7608930,71.3705550,'Q95C+F64, Gehoon','[\"park\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:59:04','2026-05-27 21:59:04','2026-05-20 21:59:04','2026-05-20 21:59:04'),
(2441,4,7,'ChIJvSfDPwA7RDkRq6lhDq5GuH8','Revital Zone Gym',4.9,128,'OPERATIONAL',699,'699 m away',0,25.7470827,71.3905612,'258/6, Harijan Basti, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:04','2026-05-27 21:59:04','2026-05-20 21:59:04','2026-05-20 21:59:04'),
(2442,4,7,'ChIJx00eWLc7RDkROGcSFPmaZvc','M S SODHA GYM',4.5,159,'OPERATIONAL',1147,'1.1 km away',0,25.7461203,71.3957650,'5th Floor, Bhagwati Complex, Station Road, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:04','2026-05-27 21:59:04','2026-05-20 21:59:04','2026-05-20 21:59:04'),
(2443,4,7,'ChIJD-QuhgI7RDkRQSAv_kcxWNs','VIP Gym',4.0,52,'OPERATIONAL',790,'790 m away',0,25.7518161,71.3943939,'Q92V+PQC, Laxmi Nagar, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:04','2026-05-27 21:59:04','2026-05-20 21:59:04','2026-05-20 21:59:04'),
(2444,4,7,'ChIJv7C65ho7RDkR6chaDoKrl-s','Nehru Yuva Kendra Gym, Barmer',4.8,4,'OPERATIONAL',1290,'1.3 km away',0,25.7539764,71.3992490,'Q93X+HMX, Madhuban Colony, P S Parisar Colony, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:04','2026-05-27 21:59:04','2026-05-20 21:59:04','2026-05-20 21:59:04'),
(2445,4,7,'ChIJXS5-seM7RDkRQM0VdPoRxik','The fitness zone',4.2,52,'OPERATIONAL',1942,'1.9 km away',0,25.7353759,71.3916828,'Partap Ji Ki Prol Road, Pratap Ji Ki Pole, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:04','2026-05-27 21:59:04','2026-05-20 21:59:04','2026-05-20 21:59:04'),
(2446,4,7,'ChIJnbeOBIo7RDkR7mPazcsEu14','Vicky health & nutrition centre',4.0,8,'OPERATIONAL',1669,'1.7 km away',0,25.7396755,71.3956955,'NEAR THAR GAS AGENCY, CO-OPERATIVE MARKETING SOCIETY, SHOP NO 12, FIRST FLOOR, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:04','2026-05-27 21:59:04','2026-05-20 21:59:04','2026-05-20 21:59:04'),
(2447,4,7,'ChIJd3WiFuI7RDkRPtLnZElocBY','Revital Store : Buy Branded Supplements & Nutrition Products At Best Price & 100% Genuine In Barmer',5.0,2,'OPERATIONAL',506,'506 m away',0,25.7491806,71.3902956,'in front of Rai Colony School, Panch Batti Cricle, Barmer','[\"gym\",\"health\",\"store\",\"point_of_interest\",\"food\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:59:04','2026-05-27 21:59:04','2026-05-20 21:59:04','2026-05-20 21:59:04'),
(2448,4,7,'ChIJB2-zVgA7RDkRMZc-BcRwHEU','खोडाल',NULL,NULL,'CLOSED_TEMPORARILY',1018,'1.0 km away',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:59:04','2026-05-27 21:59:04','2026-05-20 21:59:04','2026-05-20 21:59:04'),
(2449,4,7,'ChIJz2bCWwA7RDkRjR49MLZTDrQ','EX.Hari Singh Bhati ka vaas',NULL,NULL,'CLOSED_TEMPORARILY',1018,'1.0 km away',NULL,25.7521467,71.3966865,'Q92W+VM3, Barmer','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-20 21:59:04','2026-05-27 21:59:04','2026-05-20 21:59:04','2026-05-20 21:59:04'),
(2450,4,7,'ChIJbclBMgA7RDkR6dFzaibUY5c','HEALTH AND FITNESS CENTER BARMER',5.0,1,'OPERATIONAL',1144,'1.1 km away',0,25.7460474,71.3956744,'SHOP No.- 408, 4TH FLOOR, BHAGATI COMPLEX, Railway, स्टेशन मार्ग, बाड़मेर','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-20 21:59:04','2026-05-27 21:59:04','2026-05-20 21:59:04','2026-05-20 21:59:04'),
(2451,4,9,'ChIJ12Xvn7s6RDkRjUud9Q7F_HM','Barmer',4.4,1882,'OPERATIONAL',1281,'1.3 km away',NULL,25.7463500,71.3975400,'Station Road, Nehru Nagar, Barmer','[\"train_station\",\"transit_station\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-20 21:59:05','2026-05-27 21:59:05','2026-05-20 21:59:05','2026-05-20 21:59:05'),
(2452,1,6,'ChIJ533DTd7hUDkR9cvAp2plQj0','Sunset point',4.4,10,'OPERATIONAL',1698,'1.7 km away',NULL,23.1694266,69.6912816,'5M9R+QGF, Jadura','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:05:50','2026-05-28 01:05:50','2026-05-21 01:05:50','2026-05-21 01:05:50'),
(2453,9,1,'ChIJy_ZtFTAADTkRIbB-LL9jIBU','Kapil Multispeciality Hospital',4.5,1507,'OPERATIONAL',1715,'1.7 km away',1,28.7677065,77.1818522,'A-1 shastri park mor, Nathupura, Burari, New Delhi','[\"hospital\",\"doctor\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-21 01:20:49','2027-05-21 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2454,9,1,'ChIJ1yvHKCH-DDkR8ueG4GGUP-g','Guru Gobind Singh Hospital (GGSH)',4.4,847,'OPERATIONAL',1815,'1.8 km away',1,28.7415310,77.1976912,'Sant Nagar Marg, A-2 Block, Virendar Nagar, Block B, West Sant Nagar, Burari, Delhi','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-21 01:20:49','2027-05-21 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2455,9,1,'ChIJ7f5QHisADTkRBsnKy8uA2-E','City Child & Family Care Hospital',3.9,107,'OPERATIONAL',452,'452 m away',0,28.7600733,77.1914807,'Sant Nagar Marg, Laxmi Vihar, Extension Colony, Burari, Delhi','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-21 01:20:49','2027-05-21 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2456,9,1,'ChIJCTkJnisADTkRNb-acEseynE','Burari Hospital',3.7,620,'OPERATIONAL',670,'670 m away',0,28.7616210,77.1900260,'Burari Road, Kaushik Enclave, Shankarpura, Burari, Delhi','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-21 01:20:49','2027-05-21 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2457,9,1,'ChIJiTEpsPUBDTkRaYvSnDNWw4U','Samrijo hospital',4.1,15,'OPERATIONAL',310,'310 m away',1,28.7557950,77.1975690,'opposite Janta medical, Main, Burari Road, Delhi','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-21 01:20:49','2027-05-21 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2458,9,1,'ChIJO-ExzSb-DDkRorTt5zS_RW8','North City Hospital',3.9,67,'OPERATIONAL',1777,'1.8 km away',1,28.7419546,77.1982522,'Main Market, Sant Nagar, Burari, Delhi','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-21 01:20:49','2027-05-21 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2459,9,1,'ChIJK0hKjyb-DDkROVMK82w8QiI','Dr. Nitin Gupta MD Homeopathy Doctor in Sant Nagar Burari Delhi',4.3,45,'OPERATIONAL',1547,'1.5 km away',0,28.7444089,77.1998832,'123/2, B-1 Block, Brahmakumari Marg, Labour Chowk, Sant Nagar, Burari, New Delhi','[\"hospital\",\"doctor\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-21 01:20:49','2027-05-21 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2460,9,1,'ChIJD74trdL_DDkRAv4-l1HMvz4','PATEL HOSPITAL',4.0,21,'OPERATIONAL',978,'978 m away',1,28.7606843,77.2046990,'Pradhan Enclave, 51/4, A Block, Burari, Delhi','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-21 01:20:49','2027-05-21 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2461,9,1,'ChIJm-JJkiv-DDkRtV3dcvGz8dM','Government Dispensary',3.7,7,'OPERATIONAL',492,'492 m away',0,28.7551857,77.1994019,'641, Sant Nagar Marg, Baba Colony, Burari, Delhi','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-21 01:20:49','2027-05-21 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2462,9,1,'ChIJE8EbMyb-DDkRfGDafIqOMVM','The Sant Parmanand School of Nursing',4.5,13,'CLOSED_TEMPORARILY',1249,'1.2 km away',NULL,28.7466037,77.1971124,'opposite Canara Bank, Khasra 783, Mandir Wali Gali, Sant Nagar, Burari, Delhi','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-21 01:20:49','2027-05-21 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2463,9,1,'ChIJdadPuyr-DDkRDlcgTFvJ8yU','Budhiraja Nursing Home',3.2,12,'OPERATIONAL',11,'<50 m away',0,28.7576449,77.1951851,'Q55W+333, Burari Garhi, Burari, New Delhi','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',0,'below_min_rating','2026-05-21 01:20:49','2027-05-21 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2464,9,1,'ChIJzRDkQiwADTkRDnDE3735O00','Nature Care Health Care Centre',2.0,1,'CLOSED_TEMPORARILY',86,'86 m away',NULL,28.7573267,77.1960240,'Burari, 2, Main Road, Burari, New Delhi','[\"doctor\",\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',0,'below_min_rating','2026-05-21 01:20:49','2027-05-21 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2465,9,1,'ChIJaagnkTL_DDkRSwnF76tPcqw','NB Artifiical Limbs Centre',NULL,NULL,'OPERATIONAL',87,'87 m away',NULL,28.7582155,77.1945761,'Nirmal Niwas, near Uma Garden, C-173, Parasram Enclave, Burari, Delhi','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',0,'unrated','2026-05-21 01:20:49','2027-05-21 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2466,9,1,'ChIJ50wdHysADTkRTUNXZdT7t7M','City Pharmacy',4.0,2,'OPERATIONAL',451,'451 m away',1,28.7600463,77.1914736,'Q56R+2H9, Sant Nagar Marg, Laxmi Vihar, Extension Colony, Burari, Delhi','[\"pharmacy\",\"hospital\",\"point_of_interest\",\"health\",\"store\",\"establishment\"]',0,'below_min_reviews','2026-05-21 01:20:49','2027-05-21 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2467,9,1,'ChIJV-QIhCb-DDkRjN5BsR-Q_nM','Medicos',2.0,2,'OPERATIONAL',1463,'1.5 km away',NULL,28.7453193,77.2002841,'P6W2+44F, Parvatiya Anchal, Block B, Sant Nagar, Burari, Delhi','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',0,'below_min_rating','2026-05-21 01:20:49','2027-05-21 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2468,9,2,'ChIJAwAA7B0CDTkRb8azok4O3tY','Shyam Sharma\'s Classes',4.4,35,'OPERATIONAL',1213,'1.2 km away',0,28.7477397,77.2002899,'khasra no 861, havells society tower, opposite Gali Number 3, 5, Parvatiya Anchal, Sant Nagar, Burari, Delhi','[\"school\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2469,9,2,'ChIJSycA09cBDTkRAXzhYXRMuV0','LEARNERS CASTLE PLAYSCHOOL, BURARI, NEW DELHI',4.6,5,'CLOSED_TEMPORARILY',695,'695 m away',NULL,28.7514839,77.1958086,'behind Govt School, A- 29, Tomar Colony, Burari, Delhi','[\"school\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2470,9,2,'ChIJzUT3Ui_-DDkRXkEf6K8ni-U','The Country\'s Pride Play School',4.3,8,'CLOSED_TEMPORARILY',1139,'1.1 km away',NULL,28.7485298,77.2004357,'B- 5868, Ground Floor, Maurya Enclave, Sweety Properties, Near Shagun Banquet Hall, 25 Feet Road, Burari, New Delhi','[\"school\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2471,9,2,'ChIJSQfiRCr-DDkRF4sevHks1NA','Rajdhan Public School',NULL,NULL,'OPERATIONAL',208,'208 m away',0,28.7563746,77.1967405,'Ekta Enclave, Harizon Basti, Burari Garhi, Burari, Delhi','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2472,9,2,'ChIJ957dDiv-DDkRpi90KdEFUPQ','Indian Public School',NULL,NULL,'OPERATIONAL',302,'302 m away',0,28.7571354,77.1982883,'near Janta Medical Store, Mangal Bazar Wali Gali, Extension Colony, Burari, Delhi','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2473,9,2,'ChIJBaSXaisADTkReekErc1G5BA','City Convent School',NULL,NULL,'OPERATIONAL',555,'555 m away',NULL,28.7598089,77.1900952,'221-A-2, Gali Number 1, A Block, West Sant Nagar, Burari, New Delhi','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2474,9,2,'ChIJyedsrin-DDkR2c5SEnHObF8','Baankura Public School',NULL,NULL,'OPERATIONAL',557,'557 m away',0,28.7531061,77.1974908,'Main, 41 Feet Road, Ganesh Nagar, Burari, Delhi','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2475,9,2,'ChIJw5aYsCkADTkRNRWaOZxF6jE','Great Mission Convent Secondary School',NULL,NULL,'OPERATIONAL',1005,'1.0 km away',0,28.7664560,77.1926278,'Gali Number 37/F, Kaushik Enclave, Shankarpura, Burari, Delhi','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2476,9,2,'ChIJpcqxaCwADTkRKoNTNLbBxqU','Nai Kiran',NULL,NULL,'OPERATIONAL',1027,'1.0 km away',NULL,28.7641060,77.1876529,'Gali No. 16, T- Point Near Gurudwara, Kaushik Enclave, Burari, Delhi','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2477,9,2,'ChIJj2pM79cBDTkRY96NqaXlGYE','Galaxy Public School',NULL,NULL,'OPERATIONAL',1056,'1.1 km away',0,28.7483938,77.1931709,'25 Feet Road, Block D, Kamal Vihar, Burari, New Delhi','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2478,9,2,'ChIJS7jGNx_-DDkRfpFOauoUbeQ','Nalanda Modern Public School',NULL,NULL,'OPERATIONAL',1182,'1.2 km away',0,28.7474747,77.1985315,'857/1, Sant Nagar Marg, Burari, New Delhi','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2479,9,2,'ChIJTQ8ZvCf-DDkRbxXvYJQefCQ','Anubhav Public School',NULL,NULL,'OPERATIONAL',1200,'1.2 km away',0,28.7469252,77.1951853,'57, G, No.2, Uttaranchal Enclave, Kamal Pur, Burari, New Delhi','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2480,9,2,'ChIJTQ8ZvCf-DDkRekluBPcu4bI','Divya Coaching Center',NULL,NULL,'OPERATIONAL',1355,'1.4 km away',NULL,28.7455583,77.1962447,'25 Feet Road, Kamal Vihar, Burari, Delhi','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2481,9,2,'ChIJ5-SD-Sb-DDkRukXUMdxLrSw','M. D. Public School',NULL,NULL,'OPERATIONAL',1482,'1.5 km away',1,28.7443883,77.1948504,'S.No:121, West, Sant Nagar Marg, A-2 Block, Sant Nagar, Burari, New Delhi','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2482,9,2,'ChIJT6bZ_Sb-DDkRWrPS-CicPO0','The Redwoods School',NULL,NULL,'OPERATIONAL',1515,'1.5 km away',0,28.7441872,77.1971357,'P5VW+MVC, Main Road, Sant Nagar Extension, Sant Nagar, Burari, Delhi','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2483,9,3,'ChIJgaJwT7H_DDkR-iiw7-AT-Jo','Royal Regal Cafe, Lounge & Restra',4.7,1052,'OPERATIONAL',33,'<50 m away',0,28.7579763,77.1954252,'First Floor, opposite Shalimar Palace, near Aapka Budget Bazaar, kh. No. 540, Main Road, Burari, Delhi','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2484,9,3,'ChIJ51tR77MBDTkRGcf4lJH24Ck','FOOD PITARRA',4.2,448,'OPERATIONAL',141,'141 m away',0,28.7584237,77.1940541,'Kh. No- 457/1, near Shalimar Palace, opposite Vindhya Shree Appartment, Burari, Delhi','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2485,9,3,'ChIJ1SQhHwD_DDkRpjD6CRVYaT4','DOMINOS | Uttarakhand Enclave',4.8,13,'OPERATIONAL',9,'<50 m away',NULL,28.7577888,77.1952149,'Q55W+438, Conductor Colony, Burari Garhi, Burari, Delhi','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2486,9,3,'ChIJvz3N1_r_DDkRLwY04_41BdI','The Delicious Cafe',4.4,39,'OPERATIONAL',85,'85 m away',0,28.7572268,77.1959340,'1st floor, CHARAN SINGH PLAZA, opposite kapil Public school, near Shalimar Palace, Main 100, Futa Road, Burari, Delhi','[\"restaurant\",\"cafe\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2487,9,3,'ChIJWeR7Ut0BDTkR0D8XLjtATb8','Da Pizza Palace Sant nagar',3.9,1967,'OPERATIONAL',1699,'1.7 km away',0,28.7426486,77.1981890,'Kh no.122, near vishal mega mart, 16/2, 100 Feet Road, Block B, Sant Nagar, Burari, New Delhi','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2488,9,3,'ChIJxZn0DK7_DDkRT_ok3sFd9so','WINNKEY\'S',5.0,5,'CLOSED_TEMPORARILY',10,'<50 m away',NULL,28.7576684,77.1951655,'near Yashu Vidya public school, 17/21, New Delhi','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2489,9,3,'ChIJB7w2vir-DDkRQBAIRJASMGc','Nainital Dhaba',3.7,40,'OPERATIONAL',56,'56 m away',0,28.7575430,77.1957938,'Main Nathupura Road Opp.Shalimar Palace 317 Sant Nagar Marg Data Ram Tyagi Enclave Block A Extension Colony, Ram Garhi, Burari, Delhi','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2490,9,3,'ChIJhaqF-jkADTkRXFX0vauoQy8','Aggarwal Sweets Corner',3.7,522,'OPERATIONAL',2104,'2.1 km away',0,28.7693621,77.1782507,'Nathu Pura Main Road, Prem Nagar, Nathupura, Burari, New Delhi','[\"restaurant\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2491,9,3,'ChIJN9gXCNsBDTkRr0_WticLn8U','Bikaner Sweets',3.7,63,'OPERATIONAL',1898,'1.9 km away',0,28.7427646,77.1858533,'P5VP+485, Mangal Bazar Road, Samta Vihar, Mukandpur Part 2, Jahangirpuri, Delhi','[\"restaurant\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2492,9,3,'ChIJaef0OzgADTkR_iWmcOF7hXY','Raju Chowmein Corner',3.6,54,'CLOSED_TEMPORARILY',890,'890 m away',NULL,28.7646023,77.1905999,'Q57R+R6X, Nathu Colony, Burari New Delhi, Delhi','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2493,9,3,'ChIJb2qiaLj_DDkRBt0Go0n_0UY','Domino\'s Pizza | Burari, New Delhi',3.1,8,'OPERATIONAL',28,'<50 m away',0,28.7578736,77.1950426,'Khata No. 1062/850, Lal Dora, Ground Floor, At Khasra No. 535, Burari, Delhi','[\"meal_delivery\",\"meal_takeaway\",\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2494,9,3,'ChIJpactGgD_DDkRWSyXHidiKJo','Domino’s Pizza | BURARI',3.3,101,'OPERATIONAL',34,'<50 m away',NULL,28.7575909,77.1949450,'284, Sant Nagar Marg, Conductor Colony, Burari Garhi, Burari, New Delhi','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2495,9,3,'ChIJ54yjawD_DDkRYvaXlipTM54','Sarvesh kumar dwivedi',NULL,NULL,'OPERATIONAL',87,'87 m away',NULL,28.7582155,77.1945761,'Q55V+7RP, Burari, Delhi','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2496,9,3,'ChIJHcLzIEz_DDkRfzpTVlwFU1o','BH X BB',NULL,NULL,'CLOSED_TEMPORARILY',87,'87 m away',NULL,28.7582155,77.1945761,'Q55V+7RP, Keshav nagar, Burari, Delhi','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2497,9,3,'ChIJd6CWBYsBDTkRpi-ut7BpKWU','JAGDAMBA JHARKHAND DHABA',2.0,4,'OPERATIONAL',136,'136 m away',0,28.7584627,77.1941515,'Q55V+FQ6, Laxmi Vihar, Burari, Delhi','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-21 01:20:49','2026-05-28 01:20:49','2026-05-21 01:20:49','2026-05-21 01:20:49'),
(2498,9,4,'ChIJW_UJnb3_DDkRMJMHgDrQ1SE','Fedbank Financial Services Ltd',5.0,9,'OPERATIONAL',511,'511 m away',0,28.7546806,77.1991957,'First Floor, near Jindal Hardware, No. 665, Sant Nagar Marg, Burari, New Delhi','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2499,9,4,'ChIJxz4-TmgaDTkR-A2-k-yq8ko','HDFC Bank',3.8,33,'OPERATIONAL',1077,'1.1 km away',0,28.7484642,77.1985469,'No 548/2, Bamnoli, Sector 28, New Delhi','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2500,9,4,'ChIJ5YmzWy_-DDkRX7Qxg1uT1DM','Kangra Cooperative Bank, Burari',3.9,19,'OPERATIONAL',1188,'1.2 km away',0,28.7483963,77.2012206,'P6X2+9F5, Satya Vihar, Baba Colony, Burari, Delhi','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2501,9,4,'ChIJ4Uiwl4j_DDkRJ3LiN5semv4','ICICI BANK ATM',1.0,1,'OPERATIONAL',78,'78 m away',1,28.7572002,77.1958084,'Shop No. 449, Khasra No. 303/2, Main Chowk Burari, Burari, New Delhi','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2502,9,4,'ChIJuVcgliv-DDkRI-9drTGQXYM','Punjab National Bank',3.2,124,'OPERATIONAL',430,'430 m away',0,28.7555519,77.1989196,'No 303/1, Burari, New Delhi','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2503,9,4,'ChIJucH7vSv-DDkRHPgr1xCm9hY','Axis Bank ATM',3.3,3,'OPERATIONAL',432,'432 m away',1,28.7553971,77.1988219,'Shop No.1, Ground Floor, Main Burari Chowk, North, Delhi','[\"atm\",\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2504,9,4,'ChIJyT2RBir-DDkRYEeRdVwz-HM','union bank',2.5,11,'OPERATIONAL',468,'468 m away',0,28.7535207,77.1948237,'Q53V+CW4, Tomar Colony, Burari, Kamal Pur, Burari, Delhi','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2505,9,4,'ChIJ63_R7iv-DDkR6GMtOYopMfE','THE DELHI STATE COOPERATIVE BANK LTD.',3.4,5,'OPERATIONAL',534,'534 m away',NULL,28.7543959,77.1992192,'Q53X+QM5, Sant Nagar Marg, Conductor Colony, Burari, New Delhi','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2506,9,4,'ChIJ5S28JyL-DDkR1y0qJTm8rDg','Union Bank',3.1,22,'OPERATIONAL',583,'583 m away',0,28.7540429,77.1995213,'A-1, Gali Number 16, A-1 Block Extension, Kamal Vihar, Sant Nagar, Burari, नई दिल्ली, Gali Number 16, A-1 Block Extension, Kamal Vihar, Sant Nagar, Burari, नई दिल्ली','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2507,9,4,'ChIJS0VbTeH_DDkR8aWO-Gc7PgM','CANARA BANK - DELHI SANT NAGAR BURARI-II',1.7,42,'OPERATIONAL',739,'739 m away',0,28.7519189,77.1989743,'KHASRA NO. 353 & 816 MAIN, 100, Foota Road, Sant Nagar, Burari, Delhi','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2508,9,4,'ChIJcShkFyn-DDkRJ-0jyCxBl1I','Indian Bank',2.3,3,'OPERATIONAL',785,'785 m away',NULL,28.7512894,77.1985905,'India','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2509,9,4,'ChIJhQg9APMBDTkRQ6vC973rR50','Axis Bank ATM',3.0,1,'OPERATIONAL',1020,'1.0 km away',1,28.7519059,77.2033627,'Khasra No 9/3, 2/1, Plot No 397, Burari, New Delhi','[\"atm\",\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2510,9,4,'ChIJV0t-lEcBDTkR0llHFTZVuhE','SBI Branch Nathupura',5.0,1,'OPERATIONAL',1093,'1.1 km away',0,28.7625706,77.1855064,'Ground Floor, Street, B19/26, Nathupura Road, Burari, Delhi','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2511,9,4,'ChIJzUTodSj-DDkR1BoLLrE_Qco','यूनियन बैंक ऑफ इंडिया ग्राहक सेवा केन्द्र',NULL,NULL,'OPERATIONAL',1136,'1.1 km away',NULL,28.7475361,77.1962692,'India','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2512,9,4,'ChIJRcgUQiv-DDkRY4ISGHKrOps','Axis Bank Branch',1.9,30,'OPERATIONAL',1451,'1.5 km away',0,28.7448890,77.1979829,'Ground Floor Khasra No 804, Main 100, Foota Road, Burari, New Delhi','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2513,9,5,'ChIJ9Z6Z6y7-DDkRo76yEuRW9bU','Uday Traders',4.3,84,'OPERATIONAL',847,'847 m away',0,28.7523600,77.2014324,'Prem Nagar, Baba Colony, Burari, Delhi','[\"supermarket\",\"grocery_or_supermarket\",\"store\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2514,9,5,'ChIJY5tt4BT_DDkRSgqPvck9g8s','Lucky General Store',5.0,4,'OPERATIONAL',516,'516 m away',1,28.7544856,77.1914602,'near trigudeshwari, D Block Road, Ajit Vihar, Burari, Delhi','[\"supermarket\",\"grocery_or_supermarket\",\"store\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2515,9,5,'ChIJh2VWCRIBDTkRDnra7EQLkVQ','The Custom Shop',4.7,26,'OPERATIONAL',682,'682 m away',0,28.7525232,77.1989845,'Khasra no.806 and 807, extended lal dora, Burari Road, Burari, Delhi','[\"supermarket\",\"grocery_or_supermarket\",\"shoe_store\",\"home_goods_store\",\"clothing_store\",\"store\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2516,9,5,'ChIJT8-MiNf_DDkRrpU4mSC33bQ','Baniya Ki Dukan , Burari Sant Nagar',3.8,371,'OPERATIONAL',1208,'1.2 km away',0,28.7471681,77.1982179,'KH NO.777, Landmark Vashistha Dharam Kanta, Burari, Delhi','[\"supermarket\",\"grocery_or_supermarket\",\"store\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2517,9,5,'ChIJ6xXcdDz_DDkRghm2ofU7Xwo','The Prayaas',5.0,5,'OPERATIONAL',784,'784 m away',0,28.7549636,77.2026652,'Gali No 18, House No 428, Maurya Enclave, Burari, New Delhi','[\"supermarket\",\"grocery_or_supermarket\",\"store\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2518,9,5,'ChIJ3bnv29IBDTkR5fj4lBxCm_o','Panmei\'s Mart',4.6,30,'OPERATIONAL',944,'944 m away',0,28.7568490,77.1856227,'near Oscar Public School, Gali Number 20, Kaushik Enclave, Block A, Burari, Delhi','[\"supermarket\",\"grocery_or_supermarket\",\"store\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2519,9,5,'ChIJ3xZmU0D_DDkRp_HuUgfni8Q','AAPKA BUDGET BAZAAR (SHALIMAR PALACE BURARI)',3.8,52,'OPERATIONAL',37,'<50 m away',0,28.7577563,77.1956385,'KH NO 540, opp. SHALIMAR PALACE, 100, Foota Road, Burari, Delhi','[\"department_store\",\"supermarket\",\"grocery_or_supermarket\",\"store\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2520,9,5,'ChIJsWNCKy7-DDkRDH8ose-gDis','JAi_e Hypermarket',5.0,24,'CLOSED_TEMPORARILY',148,'148 m away',NULL,28.7584973,77.1940266,'G No, 1 Block, KH. No. 139, 19, A, Sant Nagar Marg, Burari, New Delhi','[\"supermarket\",\"grocery_or_supermarket\",\"store\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2521,9,5,'ChIJx0Nj6Cb-DDkRVyZAtoy26_E','Vishal Mega Mart',3.8,7572,'OPERATIONAL',1619,'1.6 km away',0,28.7433861,77.1982006,'opp. BHAGAT COLONY GATE, MAIN, 100 Feet Road, Sant Nagar, Burari, New Delhi','[\"supermarket\",\"grocery_or_supermarket\",\"clothing_store\",\"store\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2522,9,5,'ChIJ5VdyZZ3_DDkRra7RHXNqUEA','Kia Bazaar',4.8,5,'OPERATIONAL',848,'848 m away',0,28.7507090,77.1987067,'lal dora, 830/2/2 kh no no 830/1/2/2, 100 foota road, Burari, New Delhi','[\"supermarket\",\"grocery_or_supermarket\",\"store\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2523,9,5,'ChIJ3VO0DP4BDTkRfK-yOFLFGs0','ROSHAN mega Mart',5.0,2,'CLOSED_TEMPORARILY',805,'805 m away',NULL,28.7614424,77.1881815,'b block, 37/17, Gali Number 13, Kaushik Enclave, Burari, Delhi','[\"supermarket\",\"grocery_or_supermarket\",\"store\",\"food\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2524,9,5,'ChIJebblcVUBDTkRF4AbQIOeE5Q','NG Supplements House',5.0,1,'OPERATIONAL',890,'890 m away',0,28.7645764,77.1905674,'Shop No-725/5, Main, 25 Feet Road, Tomar Colony, Burari, Burari, New Delhi','[\"supermarket\",\"grocery_or_supermarket\",\"store\",\"food\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2525,9,5,'ChIJA-E-3kcBDTkRiqY0_4kpj60','Rajmandir Hypermarket Burari 2',3.4,5,'OPERATIONAL',973,'973 m away',0,28.7495098,77.1987238,'Ground Floor, Kh No 104/26, Main Road, Burari, New Delhi','[\"supermarket\",\"grocery_or_supermarket\",\"store\",\"food\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2526,9,5,'ChIJtaj-nwj_DDkR84e6qUiNNp4','HK MART',NULL,NULL,'OPERATIONAL',1115,'1.1 km away',0,28.7514762,77.2042134,'near Swaraj Mandir, Main 60, Foota Road, Baba Colony, New Delhi','[\"supermarket\",\"grocery_or_supermarket\",\"store\",\"food\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2527,9,5,'ChIJrd8jiZMBDTkR9jvq_DABEB4','Pinky Bartan Store',5.0,1,'CLOSED_TEMPORARILY',1176,'1.2 km away',NULL,28.7527338,77.1846112,'Khasra no 99/7, Gali Number 17, West Kamal Vihar Marg, Block D, Swami Dayanand Enclave, Burari, New Delhi','[\"supermarket\",\"grocery_or_supermarket\",\"store\",\"food\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-21 01:20:50','2026-05-28 01:20:50','2026-05-21 01:20:50','2026-05-21 01:20:50'),
(2528,9,6,'ChIJN5t29qv_DDkRx4w5pL2nYzw','Abode Green Infra Projects (Green Natural Grass: Selection No.1, Bermuda, Mexcian, Nilgiri, Korean)',5.0,94,'OPERATIONAL',1431,'1.4 km away',0,28.7448438,77.1954915,'near chetan bihari mandir, North, Kamal Vihar, Burari, Delhi','[\"park\",\"general_contractor\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:51','2026-05-28 01:20:51','2026-05-21 01:20:51','2026-05-21 01:20:51'),
(2529,9,6,'ChIJpYm1Obj_DDkRsgW1ym5toXA','Khandeshwar Park',4.4,39,'OPERATIONAL',418,'418 m away',1,28.7606298,77.1979719,'Q56X+755, Village, Burari, Delhi','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:51','2026-05-28 01:20:51','2026-05-21 01:20:51','2026-05-21 01:20:51'),
(2530,9,6,'ChIJ9ag5FgABDTkRLbx-0av5opE','उत्तरैणी कौतिक (बुराड़ी, दिल्ली)',5.0,5,'OPERATIONAL',935,'935 m away',NULL,28.7621569,77.1871200,'Q56P+VR9, A Block, Indraprasth Colony, Burari, Delhi','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:51','2026-05-28 01:20:51','2026-05-21 01:20:51','2026-05-21 01:20:51'),
(2531,9,6,'ChIJ2bnOBKj_DDkRdbsVsqdLiEk','Shree Ram Garden',4.5,30,'CLOSED_TEMPORARILY',1028,'1.0 km away',NULL,28.7668227,77.1970617,'Hanuman Road, Sunil Colony, Burari, New Delhi','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:51','2026-05-28 01:20:51','2026-05-21 01:20:51','2026-05-21 01:20:51'),
(2532,9,6,'ChIJkbUi72__DDkRwNBGqmdKfVY','Yamuna Water Lake',4.1,13,'OPERATIONAL',1901,'1.9 km away',1,28.7473013,77.2107211,'P6W6+W7H, Unnamed Road, Delhi','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:51','2026-05-28 01:20:51','2026-05-21 01:20:51','2026-05-21 01:20:51'),
(2533,9,6,'ChIJS4lr8b4BDTkRsVeuhDCzqRI','Rama garden',4.2,6,'OPERATIONAL',1816,'1.8 km away',0,28.7435959,77.1858995,'P5VP+C9J, Mangal Bazar Road, Samta Vihar, Mukandpur Part 2, Mukundpur, Delhi','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:51','2026-05-28 01:20:51','2026-05-21 01:20:51','2026-05-21 01:20:51'),
(2534,9,6,'ChIJa_ZjW2P_DDkRY4d2J_KKhdU','Yamuna Bio Diversity Park Phase 2 Jagatpur',3.8,20,'OPERATIONAL',1823,'1.8 km away',NULL,28.7460785,77.2084309,'P6W5+C9M, Delhi','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:51','2026-05-28 01:20:51','2026-05-21 01:20:51','2026-05-21 01:20:51'),
(2535,9,6,'ChIJpX8TbgD_DDkRtTPNoPF6DcU','Neem ka tree plot',5.0,1,'OPERATIONAL',185,'185 m away',NULL,28.7587537,77.1967438,'near ndpl, plot 1,Khasra 202, Data Ram Tyagi Enclave, Block A, Extension Colony, Burari, Delhi','[\"park\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-21 01:20:51','2026-05-28 01:20:51','2026-05-21 01:20:51','2026-05-21 01:20:51'),
(2536,9,6,'ChIJ9T9FEEj_DDkRq6D6y2W3xPo','Burari Village Park',1.0,1,'OPERATIONAL',419,'419 m away',NULL,28.7568664,77.1994498,'Q54X+PQW, Burari Village Marg, Block B, Baba Colony, Burari, Delhi','[\"park\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-21 01:20:51','2026-05-28 01:20:51','2026-05-21 01:20:51','2026-05-21 01:20:51'),
(2537,9,6,'ChIJ4UarOwABDTkR8HftHIPFnkY','Shakti Sarovar park',4.5,2,'OPERATIONAL',463,'463 m away',NULL,28.7569208,77.1905959,'Q54R+Q69, Ajit Vihar, Burari Garhi, Burari, Delhi','[\"park\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-21 01:20:51','2026-05-28 01:20:51','2026-05-21 01:20:51','2026-05-21 01:20:51'),
(2538,9,6,'ChIJ68gsAwD_DDkRqberge3xfOs','Jhod',NULL,NULL,'OPERATIONAL',901,'901 m away',NULL,28.7515606,77.2012680,'Q622+GFX, Prem Nagar, Baba Colony, Burari, Delhi','[\"park\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 01:20:51','2026-05-28 01:20:51','2026-05-21 01:20:51','2026-05-21 01:20:51'),
(2539,9,6,'ChIJpX_9ewD_DDkR7yfhxrsXYNA','Sukhdev Tyagi Estate',5.0,1,'OPERATIONAL',1774,'1.8 km away',NULL,28.7417650,77.1954820,'653, Nehru Gali, Chandan Vihar, Burari, New Delhi','[\"park\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-21 01:20:51','2026-05-28 01:20:51','2026-05-21 01:20:51','2026-05-21 01:20:51'),
(2540,9,6,'ChIJr6ausoH_DDkRMvqZRsEqWtE','shanti bhawan',1.0,1,'OPERATIONAL',1779,'1.8 km away',1,28.7440432,77.2047380,'3, Gali Number 98, Sant Nagar, Burari, Delhi','[\"park\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-21 01:20:51','2026-05-28 01:20:51','2026-05-21 01:20:51','2026-05-21 01:20:51'),
(2541,9,6,'ChIJ_RARKAD_DDkR6KHG6ct-O-4','Prakash house F2',4.0,1,'OPERATIONAL',1804,'1.8 km away',NULL,28.7716942,77.2046520,'ASHOK/RANI HOME, Suleman Majra Burari, Burari, Delhi','[\"park\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-21 01:20:51','2026-05-28 01:20:51','2026-05-21 01:20:51','2026-05-21 01:20:51'),
(2542,9,6,'ChIJeykOA-gBDTkRvPISUNId3tU','Incredible Paper Works',NULL,NULL,'OPERATIONAL',1923,'1.9 km away',NULL,28.7472451,77.1795562,'Gali no-09 C-Block Near By Govt.School Mukund Pur Delhi, Unnamed Road, New Delhi','[\"park\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 01:20:51','2026-05-28 01:20:51','2026-05-21 01:20:51','2026-05-21 01:20:51'),
(2543,9,7,'ChIJ9V6nZUL_DDkRzKZM4xoIC-k','Delhi Gymnastics ,Parkour & Calisthenics Academy',4.8,175,'OPERATIONAL',509,'509 m away',1,28.7543938,77.1988531,'near Patanjali store, Chowk, Burari, Delhi','[\"gym\",\"school\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:52','2026-05-28 01:20:52','2026-05-21 01:20:52','2026-05-21 01:20:52'),
(2544,9,7,'ChIJSWWX14oBDTkRnYaTZbZ4xTM','Aqua Fitness Studio',4.7,109,'OPERATIONAL',325,'325 m away',1,28.7570166,77.1920215,'Cluster_civil Lines 5 Shakti Enclave, Cluster_civil Lines 4, 149/2/3, Shanti Bhavan Road, Ajit Vihar, Burari Garhi, Burari, Delhi','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:52','2026-05-28 01:20:52','2026-05-21 01:20:52','2026-05-21 01:20:52'),
(2545,9,7,'ChIJTQLvUu3_DDkRxikqrshBdYw','Real Fitness Gym',5.0,44,'OPERATIONAL',42,'<50 m away',1,28.7578069,77.1956746,'Khasra no, opposite Shalimar Palace, 540, Burari, Delhi','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:52','2026-05-28 01:20:52','2026-05-21 01:20:52','2026-05-21 01:20:52'),
(2546,9,7,'ChIJO6KpSjIBDTkR8IiIpoWk14U','Fitness Law Gym',4.4,70,'OPERATIONAL',177,'177 m away',1,28.7586661,77.1937971,'Shree Rama Dharam Kanta, near shalimar palace, Burari, Delhi','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:52','2026-05-28 01:20:52','2026-05-21 01:20:52','2026-05-21 01:20:52'),
(2547,9,7,'ChIJmT2R-5__DDkRh_pXeC-cky0','Motivation Fitness Unisex Gym',4.6,66,'OPERATIONAL',531,'531 m away',1,28.7561363,77.1901141,'A, near Happy Child Convent school, 89, 25 Feet Road, Ajit Vihar, Burari, New Delhi','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:52','2026-05-28 01:20:52','2026-05-21 01:20:52','2026-05-21 01:20:52'),
(2548,9,7,'ChIJ0Zj37Cj-DDkRVC8npEylO8w','The Gym',4.3,255,'OPERATIONAL',1070,'1.1 km away',1,28.7484621,77.1982787,'Near Bank Of Baroda ,Main Road, Sant Nagar Marg, Sant Nagar, Burari, Delhi','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:52','2026-05-28 01:20:52','2026-05-21 01:20:52','2026-05-21 01:20:52'),
(2549,9,7,'ChIJJRbhR5f_DDkRKaLVQ2Yy4p8','Yoga for life',5.0,15,'OPERATIONAL',219,'219 m away',1,28.7558657,77.1960240,'Burari Garhi, Burari, Delhi','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:52','2026-05-28 01:20:52','2026-05-21 01:20:52','2026-05-21 01:20:52'),
(2550,9,7,'ChIJMyYQ-dMBDTkRPbAFf0H5gM8','Uk fitness gym',5.0,14,'OPERATIONAL',201,'201 m away',1,28.7575841,77.1973154,'near pump house & Choudhry builder, Gali Number 2, Tomar Colony, Burari, Burari, Delhi','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:52','2026-05-28 01:20:52','2026-05-21 01:20:52','2026-05-21 01:20:52'),
(2551,9,7,'ChIJd94bSCb-DDkRM7k7N3d9Yrw','Country Fitness Gym sant nagar burari',4.0,454,'OPERATIONAL',1237,'1.2 km away',1,28.7469571,77.1984729,'above ashokis garment, opposite vijay sales, 863/3 main, Burari Road, Sant Nagar, New Delhi','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 01:20:52','2026-05-28 01:20:52','2026-05-21 01:20:52','2026-05-21 01:20:52'),
(2552,9,7,'ChIJKXaNEwD_DDkRAg43_-sYsn0','DK FITNESS',NULL,NULL,'OPERATIONAL',86,'86 m away',1,28.7572231,77.1959335,'near shalimar banquet, opposite kapil school, Main 100 futa road, Burari Road, Burari, Delhi','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 01:20:52','2026-05-28 01:20:52','2026-05-21 01:20:52','2026-05-21 01:20:52'),
(2553,9,7,'ChIJ7ZzIqSr-DDkRk__MB4iX6dg','Fitness Mania Gym',NULL,NULL,'CLOSED_TEMPORARILY',87,'87 m away',NULL,28.7582156,77.1945758,'Q55V+7RP, Bengali Colony Road, Burari, Delhi','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 01:20:52','2026-05-28 01:20:52','2026-05-21 01:20:52','2026-05-21 01:20:52'),
(2554,9,7,'ChIJBRK26-T_DDkRflLbaN5zwlU','Bhardwaj yoga & wellness',NULL,NULL,'CLOSED_TEMPORARILY',203,'203 m away',NULL,28.7559747,77.1958903,'Park, EKTA ENCLAVE, Burari, Delhi','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 01:20:52','2026-05-28 01:20:52','2026-05-21 01:20:52','2026-05-21 01:20:52'),
(2555,9,7,'ChIJv0fteSr-DDkR-QhJNeSmNI8','Yoga With Shalu',NULL,NULL,'CLOSED_TEMPORARILY',274,'274 m away',NULL,28.7552820,77.1948340,'Arya Samaj Mandir, near Arya Samaj Mandir, 84, Harit Vihar, Burari, Delhi','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 01:20:52','2026-05-28 01:20:52','2026-05-21 01:20:52','2026-05-21 01:20:52'),
(2556,9,7,'ChIJ8fOB9-X_DDkR3j7pX-ua7lI','THE MUSCLE BEAST FITNESS UNISEX GYM',NULL,NULL,'CLOSED_TEMPORARILY',367,'367 m away',NULL,28.7580794,77.1915146,'Cluster_civil Lines 4 Block-2, near Pani ki Tanki, Pradhan Enclave, Burari, Delhi','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 01:20:52','2026-05-28 01:20:52','2026-05-21 01:20:52','2026-05-21 01:20:52'),
(2557,9,7,'ChIJFRiKtyv-DDkRzfCcGQSF8SM','Style In Beauty Salon',NULL,NULL,'CLOSED_TEMPORARILY',418,'418 m away',NULL,28.7549026,77.1981031,'Conductor Colony, Burari Garhi, Burari, Delhi','[\"gym\",\"beauty_salon\",\"health\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 01:20:52','2026-05-28 01:20:52','2026-05-21 01:20:52','2026-05-21 01:20:52'),
(2558,9,8,'ChIJP7JlsyH-DDkRL_kAcGlZJ3M','Sant Nagar A1',NULL,NULL,'OPERATIONAL',2210,'2.2 km away',NULL,28.7379400,77.1975200,'India','[\"bus_station\",\"transit_station\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 01:20:52','2026-05-28 01:20:52','2026-05-21 01:20:52','2026-05-21 01:20:52'),
(2559,10,1,'ChIJy_ZtFTAADTkRIbB-LL9jIBU','Kapil Multispeciality Hospital',4.5,1507,'OPERATIONAL',1403,'1.4 km away',1,28.7677065,77.1818522,'A-1 shastri park mor, Nathupura, Burari, New Delhi','[\"hospital\",\"doctor\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-21 02:07:39','2027-05-21 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2560,10,1,'ChIJqwjqSNkBDTkRROt7mqgZJ8E','Tomar medicos',5.0,5,'OPERATIONAL',1133,'1.1 km away',NULL,28.7715007,77.1732554,'D block, near Gali Number 7, Budh Bazar, Nathupura, Burari, Delhi','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-21 02:07:39','2027-05-21 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2561,10,1,'ChIJJxsMIOkBDTkRK3jRb8V7NEQ','Free Homeopathy Dispensary - Run by shri shiv mandir uttrakhand enclave sewa samiti',5.0,7,'OPERATIONAL',1309,'1.3 km away',0,28.7747814,77.1913754,'near Kalki goshala, New Delhi','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-21 02:07:39','2027-05-21 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2562,10,1,'ChIJOW9qhDkADTkRES00MjtQKDM','Bawra Hospital',4.4,14,'OPERATIONAL',1053,'1.1 km away',1,28.7709704,77.1767149,'Q5CG+9MP, Block B, Nathu Pura, Burari, Delhi','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-21 02:07:39','2027-05-21 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2563,10,1,'ChIJu4_XIHwBDTkR9AjllYi926A','Uttrakhand DEF Block.AAp Admi Muhalla Clinic',4.5,6,'OPERATIONAL',1405,'1.4 km away',NULL,28.7722538,77.1906871,'Q5CR+W73, Garhi Khasru, Shankarpura, Burari, Delhi','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-21 02:07:39','2027-05-21 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2564,10,1,'ChIJVVVVFTgADTkRebG6R9_bnXw','उषा मेमोरियल ओर्थोपेडिक सेंटर',4.5,4,'CLOSED_TEMPORARILY',1334,'1.3 km away',NULL,28.7695679,77.1729605,'India','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',1,NULL,'2026-05-21 02:07:39','2027-05-21 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2565,10,1,'ChIJ9-avDIYBDTkRE5UPFfzFaag','Cure Pharma and surgicals',5.0,1,'OPERATIONAL',792,'792 m away',1,28.7739398,77.1754127,'A-Block A86, Gali Number 9, DCM Colony, Nathu Pura, Burari, New Delhi','[\"drugstore\",\"hospital\",\"store\",\"point_of_interest\",\"health\",\"establishment\"]',0,'below_min_reviews','2026-05-21 02:07:39','2027-05-21 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2566,10,1,'ChIJw4LRSyMBDTkRgIrzn6Cn5yA','Ayurvedic Medical Store - Best Natural Herbal Ayurvedic Medicine shop in Burari North Delhi',5.0,2,'OPERATIONAL',854,'854 m away',0,28.7749114,77.1730064,'House no. 531, Block C, Nathu Pura, Burari, Delhi','[\"physiotherapist\",\"hospital\",\"store\",\"point_of_interest\",\"health\",\"establishment\"]',0,'below_min_reviews','2026-05-21 02:07:39','2027-05-21 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2567,10,1,'ChIJ3_r5QgABDTkRkM0oA2WLxyQ','GROW WITH US COUNSELLING BURO FELHI 84',NULL,NULL,'OPERATIONAL',855,'855 m away',NULL,28.7729268,77.1763783,'Q5FG+5HC, DCM Colony, D-Block, Nathu Pura, Burari, Delhi','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',0,'unrated','2026-05-21 02:07:39','2027-05-21 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2568,10,1,'ChIJvan-HaEBDTkRr_JjcXWAOvs','Shri Balaji charitable and blood collection center',NULL,NULL,'OPERATIONAL',1000,'1.0 km away',NULL,28.7727378,77.1735960,'Satish Tent House, Budh Bazar, DCM Colony, Nathu Pura, Delhi','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',0,'unrated','2026-05-21 02:07:39','2027-05-21 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2569,10,1,'ChIJY1R_4FcBDTkRNg8XZPsWB1U','Shresha & Co',NULL,NULL,'OPERATIONAL',1054,'1.1 km away',NULL,28.7709707,77.1766651,'near bawra hospital, B237, Nathupura, Delhi','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',0,'unrated','2026-05-21 02:07:39','2027-05-21 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2570,10,1,'ChIJFykDhiQBDTkRcwV_3c5o0mY','DK Eye Care And Dental Care Centre',5.0,2,'OPERATIONAL',1158,'1.2 km away',0,28.7702633,77.1756620,'Gali no. 14, near Pili Kothi, Main, Nathupura Road, Nathu Pura, New Delhi','[\"hospital\",\"dentist\",\"doctor\",\"point_of_interest\",\"health\",\"establishment\"]',0,'below_min_reviews','2026-05-21 02:07:39','2027-05-21 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2571,10,1,'ChIJLxg3PRsBDTkRx4PLpGY_3zQ','Govt. Dispensary for Pregnancy',3.0,4,'OPERATIONAL',1196,'1.2 km away',0,28.7694273,77.1783669,'near Agarwal Sweets, Nathu Pura Main Road, Nathupura, Burari, Delhi','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',0,'below_min_rating','2026-05-21 02:07:39','2027-05-21 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2572,10,1,'ChIJYfIFIQUBDTkRjZLgTTYLsZ0','N.R.H.M',NULL,NULL,'OPERATIONAL',1204,'1.2 km away',NULL,28.7693614,77.1782968,'Q59H+P8V, Main Road Market, Prem Nagar, Nathupura, Burari, Delhi','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',0,'unrated','2026-05-21 02:07:39','2027-05-21 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2573,10,1,'ChIJKfdzqEQBDTkRa1G3XvECnFE','Pradhan Mantri Jan Aushadhi Kendra',1.0,1,'OPERATIONAL',1228,'1.2 km away',0,28.7691921,77.1778050,'Gali 6, Delhi','[\"hospital\",\"point_of_interest\",\"health\",\"establishment\"]',0,'below_min_rating','2026-05-21 02:07:39','2027-05-21 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2574,10,2,'ChIJ0zEp3z0ADTkR60bmW1BweJQ','Baba Deep Singh Public School',NULL,NULL,'OPERATIONAL',209,'209 m away',0,28.7786958,77.1780406,'opp. mukti ashram, c -30, Gali Number 1, Keshav Nagar, Ibrahimpur, Delhi','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 02:07:39','2026-05-28 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2575,10,2,'ChIJ5bcYyj0ADTkRnWB9JMIDNnY','Barsana Public School',NULL,NULL,'OPERATIONAL',292,'292 m away',NULL,28.7776060,77.1786270,'Prem Nagar Colony, 3, Ibrahimpur, Delhi','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 02:07:39','2026-05-28 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2576,10,2,'ChIJLRIw0TwADTkRNQtGcGUEESM','Shriniwas Vidyalay',NULL,NULL,'OPERATIONAL',433,'433 m away',NULL,28.7772495,77.1824003,'Q5GJ+VXR, Kurar Ibrahimpur Village, Ibrahimpur, Delhi','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 02:07:39','2026-05-28 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2577,10,2,'ChIJNafGmP8BDTkRrA5ELIjrLoI','Matrix-Info Institute',NULL,NULL,'OPERATIONAL',434,'434 m away',NULL,28.7764342,77.1780163,'Q5GH+H6C, Ibrahimpur, Delhi','[\"primary_school\",\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 02:07:39','2026-05-28 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2578,10,2,'ChIJUVHsCpsBDTkRHuSZ1yalL1E','NEO SHANTI NIKETAN PUBLIC SCHOOL',NULL,NULL,'OPERATIONAL',441,'441 m away',0,28.7813110,77.1750970,'B-Block, Main 30 ft, Gurudwara Road, Keshav Nagar, Keshav Nagar, Delhi','[\"primary_school\",\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 02:07:39','2026-05-28 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2579,10,2,'ChIJvWEyXVcBDTkRmSrUODWObtw','MC PRIMARY SCHOOL IBRAHIMPUR VILLAGE',NULL,NULL,'OPERATIONAL',527,'527 m away',NULL,28.7756614,77.1776622,'Q5GH+737, Ibrahimpur Road, D-Block, Nathupura, Ibrahimpur, Delhi','[\"primary_school\",\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 02:07:39','2026-05-28 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2580,10,2,'ChIJrwKS3yABDTkRNj_dI6wogXc','Jsg',NULL,NULL,'OPERATIONAL',546,'546 m away',NULL,28.7774552,77.1747320,'Q5GF+XVQ, Gali Number 6, Ibrahimpur, Delhi','[\"secondary_school\",\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 02:07:39','2026-05-28 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2581,10,2,'ChIJ8wsi1hAADTkRgO1XSv5SaL4','Mahavir IGNOU Community College',2.3,3,'OPERATIONAL',707,'707 m away',NULL,28.7864630,77.1801760,'Kashmiriya Colony, Shiva Enclave, 60A, Hiranki, Delhi','[\"university\",\"school\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-21 02:07:39','2026-05-28 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2582,10,2,'ChIJTYlqCTwADTkRYkwAvduED_c','MCD Primary School, Ibrahimpur',NULL,NULL,'OPERATIONAL',1147,'1.1 km away',NULL,28.7704370,77.1754400,'Q5CG+55G, Nathupura Road, D-Block, Ibrahimpur Extension, Ibrahimpur, Delhi','[\"primary_school\",\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 02:07:39','2026-05-28 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2583,10,2,'ChIJ3aprIDoADTkRyEXx9WLw5qE','S.M.S Public School',NULL,NULL,'OPERATIONAL',1264,'1.3 km away',0,28.7692115,77.1758518,'Q59G+M8Q, Nathu Pura Main Road, Nathupura, Burari, New Delhi','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 02:07:39','2026-05-28 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2584,10,2,'ChIJs8DIbDgADTkRgehal93wAJU','Manava Bhawna Public School',NULL,NULL,'OPERATIONAL',1364,'1.4 km away',0,28.7691638,77.1731826,'Budh Bazar, Nathu Pura, Burari, New Delhi','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 02:07:39','2026-05-28 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2585,10,2,'ChIJh55XTjEADTkRZVn8Gbxwqdw','Paradise Public School',NULL,NULL,'OPERATIONAL',1829,'1.8 km away',NULL,28.7637537,77.1777722,'Q57H+G42, Indraprasth Colony, Burari, New Delhi','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 02:07:39','2026-05-28 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2586,10,2,'ChIJW_lKeDEADTkRItYp01JXXAU','Navodaya Public School',NULL,NULL,'OPERATIONAL',1898,'1.9 km away',1,28.7630847,77.1801741,'B-Block, street no-7, Amrit Vihar, Burari, Delhi','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 02:07:39','2026-05-28 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2587,10,2,'ChIJpcqxaCwADTkRKoNTNLbBxqU','Nai Kiran',NULL,NULL,'OPERATIONAL',1955,'2.0 km away',NULL,28.7641060,77.1876529,'Gali No. 16, T- Point Near Gurudwara, Kaushik Enclave, Burari, Delhi','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 02:07:39','2026-05-28 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2588,10,2,'ChIJw5aYsCkADTkRNRWaOZxF6jE','Great Mission Convent Secondary School',NULL,NULL,'OPERATIONAL',1993,'2.0 km away',0,28.7664560,77.1926278,'Gali Number 37/F, Kaushik Enclave, Shankarpura, Burari, Delhi','[\"school\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 02:07:39','2026-05-28 02:07:39','2026-05-21 02:07:39','2026-05-21 02:07:39'),
(2589,10,3,'ChIJlU-yJgABDTkRtOXa8tfwdts','GAON Resto, keshav nagar',4.9,31,'OPERATIONAL',159,'159 m away',1,28.7814628,77.1800437,'Ibrahimpur Road, Keshav Nagar, Delhi','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:40','2026-05-28 02:07:40','2026-05-21 02:07:40','2026-05-21 02:07:40'),
(2590,10,3,'ChIJjYUagusBDTkRhGKVcLCKNqE','Baked Buddies Cafe',5.0,12,'OPERATIONAL',268,'268 m away',1,28.7824660,77.1801244,'Baked Buddies Cafe, near Kali mata mandir, opposite to Kripal Ashram, Keshav Nagar, Delhi','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:40','2026-05-28 02:07:40','2026-05-21 02:07:40','2026-05-21 02:07:40'),
(2591,10,3,'ChIJHa8VKvMBDTkRTjfu88kT-2A','GOD GRACE CAFE AND RESTAURANT',4.6,15,'OPERATIONAL',243,'243 m away',1,28.7822997,77.1798110,'Front of RAAS BANQUET HALL, Delhi','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:40','2026-05-28 02:07:40','2026-05-21 02:07:40','2026-05-21 02:07:40'),
(2592,10,3,'ChIJ8Um-QAYBDTkRlp5LBz19jLI','Indian swad cafe',5.0,3,'OPERATIONAL',295,'295 m away',0,28.7827316,77.1800868,'Khasra no 446, bus stand, near keshav nagar, Delhi','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:40','2026-05-28 02:07:40','2026-05-21 02:07:40','2026-05-21 02:07:40'),
(2593,10,3,'ChIJkWlpT0IBDTkR1ZNMApQgkIQ','K & B grillz',5.0,10,'OPERATIONAL',546,'546 m away',0,28.7774497,77.1747297,'kings & Bella’s salon, near Uttarakhand chowk, Gali Number 17, Sushant Vihar, Ibrahimpur, Delhi','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:40','2026-05-28 02:07:40','2026-05-21 02:07:40','2026-05-21 02:07:40'),
(2594,10,3,'ChIJzyXiLA4BDTkRjqWFyldZHro','Chaska on table',5.0,7,'OPERATIONAL',544,'544 m away',0,28.7850045,77.1800559,'Chaska on table restraunt, near kirpal ashram, Ibrahimpur Road, Keshav Nagar, Delhi','[\"cafe\",\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:40','2026-05-28 02:07:40','2026-05-21 02:07:40','2026-05-21 02:07:40'),
(2595,10,3,'ChIJ_bZfCQABDTkRWLP2kGpR8kk','Blowsom Biryani',4.9,12,'OPERATIONAL',517,'517 m away',NULL,28.7847647,77.1788400,'Q5MH+WG4, Keshav Nagar, Ibrahimpur, Delhi','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:40','2026-05-28 02:07:40','2026-05-21 02:07:40','2026-05-21 02:07:40'),
(2596,10,3,'ChIJVVVVFTgADTkRpnOWQ1bvJFU','Chaupal',3.9,162,'OPERATIONAL',1317,'1.3 km away',0,28.7692487,77.1741075,'Q59F+MJX, Nathu Pura, Burari, Delhi','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:40','2026-05-28 02:07:40','2026-05-21 02:07:40','2026-05-21 02:07:40'),
(2597,10,3,'ChIJhaqF-jkADTkRXFX0vauoQy8','Aggarwal Sweets Corner',3.7,522,'OPERATIONAL',1204,'1.2 km away',0,28.7693621,77.1782507,'Nathu Pura Main Road, Prem Nagar, Nathupura, Burari, New Delhi','[\"restaurant\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:40','2026-05-28 02:07:40','2026-05-21 02:07:40','2026-05-21 02:07:40'),
(2598,10,3,'ChIJ028sx5cBDTkRvODbEANDBPM','Momo\'s k villa',4.8,4,'OPERATIONAL',527,'527 m away',0,28.7848444,77.1800424,'Momo\'s k villa, near kirpal ashram, Kali Mata mandir, Keshav Nagar, Delhi','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:40','2026-05-28 02:07:40','2026-05-21 02:07:40','2026-05-21 02:07:40'),
(2599,10,3,'ChIJU-TrifYBDTkR1DKUQC2abFI','Bethak Hub',4.1,26,'OPERATIONAL',268,'268 m away',0,28.7824633,77.1801353,'Bethak Hub, opposite Kripal Ashram, near Kali Mata Mandir, Keshav Nagar, Burari, Delhi','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:40','2026-05-28 02:07:40','2026-05-21 02:07:40','2026-05-21 02:07:40'),
(2600,10,3,'ChIJGb1nmD0ADTkRN4pCOvbKxko','Bhojanalay',3.5,8,'CLOSED_TEMPORARILY',141,'141 m away',NULL,28.7788791,77.1795389,'Bus Stand, near New Bus Stand, Keshav Nagar, Pali, Delhi','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:40','2026-05-28 02:07:40','2026-05-21 02:07:40','2026-05-21 02:07:40'),
(2601,10,3,'ChIJaef0OzgADTkR_iWmcOF7hXY','Raju Chowmein Corner',3.6,54,'CLOSED_TEMPORARILY',2043,'2.0 km away',NULL,28.7646023,77.1905999,'Q57R+R6X, Nathu Colony, Burari New Delhi, Delhi','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:40','2026-05-28 02:07:40','2026-05-21 02:07:40','2026-05-21 02:07:40'),
(2602,10,3,'ChIJxZ9JfwABDTkRHjH-EaG-3GI','50 60 cafe & restro',NULL,NULL,'OPERATIONAL',448,'448 m away',NULL,28.7761241,77.1797324,'60, Ibrahimpur Road, Burari, Delhi','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 02:07:40','2026-05-28 02:07:40','2026-05-21 02:07:40','2026-05-21 02:07:40'),
(2603,10,3,'ChIJjYRm2jIBDTkRp9ti0aKZZZs','Sumit Kumar',5.0,1,'OPERATIONAL',480,'480 m away',NULL,28.7758728,77.1786516,'Main, 25 Feet Road, Ibrahimpur, New Delhi','[\"restaurant\",\"food\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-21 02:07:40','2026-05-28 02:07:40','2026-05-21 02:07:40','2026-05-21 02:07:40'),
(2604,10,4,'ChIJVVVVFTgADTkRKNdqqLKTdGU','भारतीय स्टेट बैंक',4.0,3,'OPERATIONAL',1385,'1.4 km away',1,28.7681411,77.1756075,'India','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:40','2026-05-28 02:07:40','2026-05-21 02:07:40','2026-05-21 02:07:40'),
(2605,10,4,'ChIJv9menMUBDTkR8UDtjKzpyBo','PNB Mitra Bank',2.5,8,'OPERATIONAL',776,'776 m away',0,28.7738227,77.1760371,'Q5FG+GCF, D-Block, Nathupura, Ibrahimpur, Delhi','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-21 02:07:40','2026-05-28 02:07:40','2026-05-21 02:07:40','2026-05-21 02:07:40'),
(2606,10,4,'ChIJXZZyCYYBDTkR2k4V9PdEheI','SEHGAL SBI CSP & CSC CENTER',5.0,1,'OPERATIONAL',827,'827 m away',1,28.7736556,77.1752599,'B 105, 30 FEET ROAD, DCM Colony, Ibrahimpur Extension, Delhi','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-21 02:07:40','2026-05-28 02:07:40','2026-05-21 02:07:40','2026-05-21 02:07:40'),
(2607,10,4,'ChIJgSeRYyMBDTkRUYr4Ayfpfmo','Axis Bank ATM',NULL,NULL,'OPERATIONAL',1214,'1.2 km away',1,28.7692580,77.1784480,'Plot No.-2-A/2 Khasra No.-4/25, Prem Nagar, Nathupura, Burari, Delhi','[\"atm\",\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 02:07:40','2026-05-28 02:07:40','2026-05-21 02:07:40','2026-05-21 02:07:40'),
(2608,10,4,'ChIJKzusPzgADTkRmvytMI5tAR0','Union Bank',5.0,1,'OPERATIONAL',1341,'1.3 km away',NULL,28.7694402,77.1730711,'Q59F+Q6G, Nathu Pura Main Road, Block B, Nathu Pura, Burari, Delhi','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-21 02:07:40','2026-05-28 02:07:40','2026-05-21 02:07:40','2026-05-21 02:07:40'),
(2609,10,4,'ChIJjcqUAKQBDTkRxt9BfdJYjCo','ICICI BANK ATM',NULL,NULL,'OPERATIONAL',1770,'1.8 km away',1,28.7644825,77.1827011,'Khasra No-19/22, ICICI Bank Atm, Main Market, H. No-2, Amrit Vihar, New Delhi','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 02:07:40','2026-05-28 02:07:40','2026-05-21 02:07:40','2026-05-21 02:07:40'),
(2610,10,4,'ChIJ2WDCQKz_DDkRw5asd9e6Nuc','Utkarsh co-operative urban thrift and credit society Ltd.',5.0,1,'OPERATIONAL',1880,'1.9 km away',0,28.7646881,77.1716024,'D- block, gali no 07, Swaroop Vihar, Burari, Delhi','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-21 02:07:40','2026-05-28 02:07:40','2026-05-21 02:07:40','2026-05-21 02:07:40'),
(2611,10,4,'ChIJyTLKFDYADTkRtKZ5K6tp1vY','Union Bank',3.0,1,'OPERATIONAL',1947,'1.9 km away',NULL,28.7635798,77.1729413,'Q57F+C5P, Gali Number 13, Swaroop Vihar, Krishna Nagar, Kadipur, Delhi','[\"bank\",\"finance\",\"point_of_interest\",\"establishment\"]',0,'below_min_rating','2026-05-21 02:07:40','2026-05-28 02:07:40','2026-05-21 02:07:40','2026-05-21 02:07:40'),
(2612,10,5,'ChIJ3yOL1zgADTkRWZgWvOTv_6M','Supermarket',4.3,66,'OPERATIONAL',903,'903 m away',0,28.7734010,77.1742454,'Budh Bazar, Nathupura, Burari, Delhi','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:40','2026-05-28 02:07:40','2026-05-21 02:07:40','2026-05-21 02:07:40'),
(2613,10,5,'ChIJu6NRhyUADTkRUUty2bu2BIY','Uttrakhand Enclave Part - 1',4.0,323,'OPERATIONAL',1367,'1.4 km away',0,28.7694259,77.1862883,'1, Nathupura Road, Uttrakhand Colony, Kaushik Enclave, Extension Colony, Burari, Delhi','[\"grocery_or_supermarket\",\"supermarket\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:40','2026-05-28 02:07:40','2026-05-21 02:07:40','2026-05-21 02:07:40'),
(2614,10,5,'ChIJeQR6Pm0BDTkR82yYLXes-WE','Preeti Store',4.5,6,'OPERATIONAL',1352,'1.4 km away',NULL,28.7689870,77.1738940,'Preeti Store, Nathupura, Burari, New Delhi','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:40','2026-05-28 02:07:40','2026-05-21 02:07:40','2026-05-21 02:07:40'),
(2615,10,5,'ChIJrevItoIBDTkRtU7FXWdVU0I','Sonu mother dairy',3.8,12,'OPERATIONAL',1894,'1.9 km away',0,28.7633100,77.1764043,'Q57G+8HC, Street 14, Indraprasth Colony, Burari, Delhi','[\"supermarket\",\"grocery_or_supermarket\",\"food\",\"store\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:40','2026-05-28 02:07:40','2026-05-21 02:07:40','2026-05-21 02:07:40'),
(2616,10,6,'ChIJw9MemT0ADTkR-fw2ooeDu4Q','Kushwaha Nursery',4.4,25,'OPERATIONAL',122,'122 m away',1,28.7791344,77.1799117,'Nathupura Road, Kurar Ibrahimpur Village, Ibrahimpur, Delhi','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:41','2026-05-28 02:07:41','2026-05-21 02:07:41','2026-05-21 02:07:41'),
(2617,10,6,'ChIJq9kJ02UBDTkRWWgqdXgelUM','City Forest Mukhmel Pur',4.6,5,'OPERATIONAL',1837,'1.8 km away',NULL,28.7903472,77.1645902,'Q5R7+4RP, Mukhmelpur, Delhi','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:41','2026-05-28 02:07:41','2026-05-21 02:07:41','2026-05-21 02:07:41'),
(2618,10,6,'ChIJ7b_P1-wBDTkRhn4RPmB4GB8','Saini Parivar Samadhi Sthal',3.6,20,'OPERATIONAL',1455,'1.5 km away',NULL,28.7764450,77.1650944,'Sushant Vihar, Ibrahimpur, Delhi','[\"park\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:41','2026-05-28 02:07:41','2026-05-21 02:07:41','2026-05-21 02:07:41'),
(2619,10,6,'ChIJY7gesz8BDTkRlwz7fkIK1Dw','Prem nursery',NULL,NULL,'OPERATIONAL',501,'501 m away',1,28.7773099,77.1834131,'Kh no 477, village, Ibrahimpur, Delhi','[\"park\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 02:07:41','2026-05-28 02:07:41','2026-05-21 02:07:41','2026-05-21 02:07:41'),
(2620,10,6,'ChIJw4dcfAABDTkRmN5TCtkn5mc','RV Dussehra Group',5.0,1,'OPERATIONAL',1164,'1.2 km away',NULL,28.7699782,77.1765428,'Q59G+XJV, Nathu Pura, Burari, Delhi','[\"park\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-21 02:07:41','2026-05-28 02:07:41','2026-05-21 02:07:41','2026-05-21 02:07:41'),
(2621,10,6,'ChIJD5oScwABDTkRAnSuqfGU3jA','Aadi\'s Farm',NULL,NULL,'OPERATIONAL',1452,'1.5 km away',NULL,28.7822760,77.1941167,'khasra no, 167-168/2, Hiranki, Delhi','[\"park\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 02:07:41','2026-05-28 02:07:41','2026-05-21 02:07:41','2026-05-21 02:07:41'),
(2622,10,6,'ChIJAQAAC0QADTkR84-5W5aJ_QU','Real Green Landscape',5.0,1,'OPERATIONAL',1489,'1.5 km away',1,28.7935304,77.1796992,'to, bhaktawarpur road, Hiranki, burari','[\"park\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-21 02:07:41','2026-05-28 02:07:41','2026-05-21 02:07:41','2026-05-21 02:07:41'),
(2623,10,6,'ChIJBxVKNgABDTkRKLcW0B-1QoY','Satyam',NULL,NULL,'OPERATIONAL',1814,'1.8 km away',NULL,28.7962081,77.1826424,'110036, North, Kushak Number 3, Hiranki, New Delhi','[\"park\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 02:07:41','2026-05-28 02:07:41','2026-05-21 02:07:41','2026-05-21 02:07:41'),
(2624,10,7,'ChIJF52qHxYADTkRXxKbEMBJpoM','star gym',4.7,99,'OPERATIONAL',88,'88 m away',1,28.7803073,77.1785397,'d-22 नई, Keshav Nagar, Ibrahimpur, Delhi','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:41','2026-05-28 02:07:41','2026-05-21 02:07:41','2026-05-21 02:07:41'),
(2625,10,7,'ChIJ2XI9HXkBDTkRYWW4V-su1kc','SK Fitness',5.0,192,'OPERATIONAL',1175,'1.2 km away',1,28.7698316,77.1820706,'khasra no 5, bus stand, near nathupura, 16/1, main road, Shastri Park Extension Colony, Burari, Delhi','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:41','2026-05-28 02:07:41','2026-05-21 02:07:41','2026-05-21 02:07:41'),
(2626,10,7,'ChIJW3TecTAADTkReJeawSp3d3o','Friction Gym',4.5,70,'OPERATIONAL',1311,'1.3 km away',1,28.7684294,77.1809892,'Q59J+99H, Main Burari Road, Nathupura Rd, D-Block, Nathupura Road, Nathupura, Burari, Delhi','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:41','2026-05-28 02:07:41','2026-05-21 02:07:41','2026-05-21 02:07:41'),
(2627,10,7,'ChIJR-AvHjgADTkRmMjZej9aw8M','Singh Gym Fitness Center',4.6,64,'OPERATIONAL',1338,'1.3 km away',1,28.7686413,77.1753588,'Singh Gym & Fitness Center A-166,Gali No.13 Main Road, Nathu Pura, Nathupura, Delhi','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:41','2026-05-28 02:07:41','2026-05-21 02:07:41','2026-05-21 02:07:41'),
(2628,10,7,'ChIJlV3PcAkBDTkR2-HqAc1JVDU','Fitfinity unisex gym',5.0,3,'OPERATIONAL',731,'731 m away',1,28.7751037,77.1746042,'Khasra no. 40 Ground floor, near Swastik public school, Ibrahimpur Road, Sushant Vihar, Delhi','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:41','2026-05-28 02:07:41','2026-05-21 02:07:41','2026-05-21 02:07:41'),
(2629,10,7,'ChIJg3u19Vj_DDkRyBy7HxpIdnQ','Alpha vault fitness',5.0,19,'OPERATIONAL',1399,'1.4 km away',1,28.7686068,77.1736912,'House No - D 763, Second Floor, near Manav Bhawna School, Delhi','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:41','2026-05-28 02:07:41','2026-05-21 02:07:41','2026-05-21 02:07:41'),
(2630,10,7,'ChIJpWBi1-ABDTkRueNavS_1aJ4','A.S.FITNESS',4.9,20,'OPERATIONAL',1386,'1.4 km away',1,28.7677973,77.1813975,'Q59J+4H6, Amrit Vihar, A Block, Nathupura, Burari, New Delhi','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:41','2026-05-28 02:07:41','2026-05-21 02:07:41','2026-05-21 02:07:41'),
(2631,10,7,'ChIJuR8MN_4BDTkRfKk7keOT2Xk','ULTIMATE 7 GYM',4.3,29,'OPERATIONAL',559,'559 m away',1,28.7754126,77.1774675,'Bus Stand, Plot No.7, Main, Ibrahimpur, Delhi','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:41','2026-05-28 02:07:41','2026-05-21 02:07:41','2026-05-21 02:07:41'),
(2632,10,7,'ChIJK6G9wLgBDTkR-x0Ot5j6TII','The growth fitness gym',5.0,8,'OPERATIONAL',1479,'1.5 km away',1,28.7670224,77.1819047,'Delhi','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:41','2026-05-28 02:07:41','2026-05-21 02:07:41','2026-05-21 02:07:41'),
(2633,10,7,'ChIJp_SBTawBDTkRT3D_6jDtxqE','MUSCLE BOX GYM',4.6,17,'OPERATIONAL',1066,'1.1 km away',1,28.7720939,77.1734738,'in front of SHREE RAM DAV PUBLIC SCHOOL, near SAVITA BAZAR, Budh Bazar, Nathupura, Delhi','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:41','2026-05-28 02:07:41','2026-05-21 02:07:41','2026-05-21 02:07:41'),
(2634,10,7,'ChIJXwIRgzsBDTkR0tl_bbj4iiA','Revolution Fitness Club',4.7,13,'OPERATIONAL',1268,'1.3 km away',1,28.7698125,77.1849375,'Garhi Khasru, Shankarpura, Burari, Delhi','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:41','2026-05-28 02:07:41','2026-05-21 02:07:41','2026-05-21 02:07:41'),
(2635,10,7,'ChIJre7_800BDTkRE9rPDO0JKUE','ULTRA FITNESS GYM',5.0,7,'OPERATIONAL',1317,'1.3 km away',NULL,28.7701675,77.1867116,'40 Feet Road, Uttarakhand Enclave, Burari, Delhi','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:41','2026-05-28 02:07:41','2026-05-21 02:07:41','2026-05-21 02:07:41'),
(2636,10,7,'ChIJ9bHqryUBDTkRWau0gWlHpb0','Sweat Box Gym Nathupura',4.0,16,'OPERATIONAL',1119,'1.1 km away',1,28.7700770,77.1796240,'Phoolbagh, Nathupura, Burari, Delhi','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',1,NULL,'2026-05-21 02:07:41','2026-05-28 02:07:41','2026-05-21 02:07:41','2026-05-21 02:07:41'),
(2637,10,7,'ChIJ33FUGlgBDTkRkQayy_6TyYs','The beast gym',5.0,1,'CLOSED_TEMPORARILY',1266,'1.3 km away',NULL,28.7698568,77.1849990,'near Suraj international school, Delhi','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',0,'below_min_reviews','2026-05-21 02:07:41','2026-05-28 02:07:41','2026-05-21 02:07:41','2026-05-21 02:07:41'),
(2638,10,7,'ChIJ3ZfL-SUBDTkREKNWURBLahE','Ganesh Fitness Club',NULL,NULL,'CLOSED_TEMPORARILY',1394,'1.4 km away',NULL,28.7678569,77.1822931,'E-61, Gali Number 5, Nathupura, Burari, Delhi','[\"gym\",\"health\",\"point_of_interest\",\"establishment\"]',0,'unrated','2026-05-21 02:07:41','2026-05-28 02:07:41','2026-05-21 02:07:41','2026-05-21 02:07:41');
/*!40000 ALTER TABLE `nearby_place_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nearby_place_overrides`
--

DROP TABLE IF EXISTS `nearby_place_overrides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nearby_place_overrides` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `property_id` bigint(20) unsigned DEFAULT NULL,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `google_place_id` varchar(120) DEFAULT NULL,
  `normalized_name` varchar(255) DEFAULT NULL,
  `action` varchar(40) NOT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `display_distance_text` varchar(120) DEFAULT NULL,
  `display_order` smallint(5) unsigned DEFAULT NULL,
  `is_recommended` tinyint(1) NOT NULL DEFAULT 0,
  `manual_lat` decimal(10,7) DEFAULT NULL,
  `manual_lng` decimal(10,7) DEFAULT NULL,
  `manual_direction_url` text DEFAULT NULL,
  `disable_directions` tinyint(1) NOT NULL DEFAULT 0,
  `admin_note` text DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nearby_override_scope_idx` (`property_id`,`category_id`,`google_place_id`),
  KEY `nearby_place_overrides_property_id_index` (`property_id`),
  KEY `nearby_place_overrides_category_id_index` (`category_id`),
  KEY `nearby_place_overrides_google_place_id_index` (`google_place_id`),
  KEY `nearby_place_overrides_normalized_name_index` (`normalized_name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nearby_place_overrides`
--

LOCK TABLES `nearby_place_overrides` WRITE;
/*!40000 ALTER TABLE `nearby_place_overrides` DISABLE KEYS */;
INSERT INTO `nearby_place_overrides` VALUES
(1,12,3,'ChIJtZHLZwA7RDkRm_b9GejsSsk','म चर भ जन लay','force_show','माचरा भोजनालay',NULL,NULL,0,NULL,NULL,NULL,1,NULL,1,1,'2026-05-20 11:41:30','2026-05-20 11:41:30'),
(2,12,3,'ChIJpbE7X6U6RDkREmi_3vFcKqM','laziz pizza','force_hide',NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,1,1,'2026-05-20 11:41:30','2026-05-20 11:41:30'),
(3,12,1,'ChIJfWY8BiE7RDkR1IUtO2Okadk','national medical store','force_show','National medical store',NULL,NULL,0,NULL,NULL,NULL,0,NULL,1,1,'2026-05-20 11:44:22','2026-05-20 11:44:22'),
(4,12,1,'ChIJfWY8BiE7RDkR1IUtO2Okadk','national medical store','force_hide','National medical store',NULL,NULL,0,NULL,NULL,NULL,0,NULL,1,1,'2026-05-20 11:44:27','2026-05-20 11:44:27'),
(5,12,1,'ChIJfWY8BiE7RDkR1IUtO2Okadk','national medical store','trust','National medical store',NULL,NULL,0,NULL,NULL,NULL,0,NULL,1,1,'2026-05-20 11:44:31','2026-05-20 11:44:31'),
(6,12,1,'ChIJ3fN8Bco5RDkRZvbJuxihaAE','martala gala barmer','force_show','Martala Gala Barmer',NULL,NULL,0,NULL,NULL,NULL,0,NULL,1,1,'2026-05-20 13:18:13','2026-05-20 13:18:13');
/*!40000 ALTER TABLE `nearby_place_overrides` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) NOT NULL,
  `message` text NOT NULL,
  `image` varchar(191) NOT NULL,
  `type` tinyint(4) NOT NULL COMMENT '0: General 1: Inquiry',
  `send_type` tinyint(4) NOT NULL COMMENT '0: Selected 1: All 2:property',
  `customers_id` text DEFAULT NULL,
  `propertys_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role_context` enum('user','agent','general') NOT NULL DEFAULT 'user',
  PRIMARY KEY (`id`),
  KEY `notification_role_context_index` (`role_context`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
INSERT INTO `notification` VALUES
(1,'test','checkout new property','',2,0,'10,8,9',4,'2026-04-15 03:12:57','2026-04-15 03:12:57','user'),
(2,'Package Payment Failed','Amount :- 10','',2,0,'10',NULL,'2026-04-15 03:21:10','2026-04-15 03:21:10','user'),
(3,'Package Purchased','Amount :- 10','',2,0,'10',NULL,'2026-04-17 08:26:35','2026-04-17 08:26:35','user'),
(4,'Package Payment Failed','Amount :- 10','',2,0,'4',NULL,'2026-04-17 09:56:17','2026-04-17 09:56:17','user'),
(5,'Sukoon Homes','Test Message','',2,0,'15',8,'2026-04-17 13:23:58','2026-04-17 13:23:58','user'),
(6,'Package Payment Failed','Amount :- 1','',2,0,'10',NULL,'2026-04-20 12:15:12','2026-04-20 12:15:12','user'),
(7,'Package Payment Failed','Amount :- 1','',2,0,'16',NULL,'2026-04-22 10:34:13','2026-04-22 10:34:13','user'),
(8,'Package Payment Failed','Amount :- 1','',2,0,'16',NULL,'2026-04-22 10:34:13','2026-04-22 10:34:13','user'),
(9,'Package Purchased','Amount :- 1','',2,0,'4',NULL,'2026-04-25 06:31:22','2026-04-25 06:31:22','user'),
(10,'Agent Verification Request Updated','Your Agent Verification Request is Approved','',1,0,'16',NULL,'2026-04-25 06:50:59','2026-04-25 06:50:59','user'),
(11,'Package Purchased','Amount :- 1','',2,0,'15',NULL,'2026-04-26 04:49:54','2026-04-26 04:49:54','user'),
(12,'Agent Verification Request Updated','Your Agent Verification Request is Approved','',1,0,'15',NULL,'2026-04-26 04:52:37','2026-04-26 04:52:37','user'),
(13,'Test property','Buy now get 10% off','1778731744-1000754850.jpg',2,1,'',1,'2026-05-14 04:09:04','2026-05-14 04:09:04','user'),
(14,'Buy and get 10% off','Buy and get discount','1778731790-1000754850.jpg',2,1,'',3,'2026-05-14 04:09:50','2026-05-14 04:09:50','user'),
(15,'Test','Test','',2,1,'',5,'2026-05-14 04:10:44','2026-05-14 04:10:44','user'),
(16,'test','test 1','1778732204-nl.png',2,0,'18,17,16,15,14,13,12,11,10,9',1,'2026-05-14 04:16:44','2026-05-14 04:16:44','user'),
(17,'yryd','gdfgdfg','',2,0,'18,16,15',3,'2026-05-14 05:43:24','2026-05-14 05:43:24','user'),
(18,'hegsd','ssdfsdfsdf','',2,0,'18,16,15,10',9,'2026-05-14 05:45:18','2026-05-14 05:45:18','user'),
(19,'Package Purchased','Amount :- 1','',2,0,'15',NULL,'2026-05-14 08:34:51','2026-05-14 08:34:51','user'),
(20,'Property Updated :- plot in barmer','Your property post approved by administrator','',1,0,'15',11,'2026-05-14 08:36:49','2026-05-14 08:36:49','user'),
(21,'Property Updated :- test','Your property post approved by administrator','',1,0,'15',12,'2026-05-14 12:51:43','2026-05-14 12:51:43','user'),
(22,'Property Updated :- plot in barmer','Your property post approved by administrator','',1,0,'15',11,'2026-05-16 17:37:02','2026-05-16 17:37:02','user'),
(23,'Property Updated :- plot in barmer','Your property post approved by administrator','',1,0,'15',11,'2026-05-16 18:19:58','2026-05-16 18:19:58','user'),
(24,'Property Updated :- plot in barmer','Your property post approved by administrator','',1,0,'15',11,'2026-05-17 00:20:11','2026-05-17 00:20:11','user'),
(25,'New package assigned','Package :- tests','',2,0,'15',NULL,'2026-05-17 03:07:16','2026-05-17 03:07:16','user'),
(26,'Become Agent Request Approved','Congratulations! Your request to become an agent has been approved.','',1,0,'15',NULL,'2026-05-17 03:28:49','2026-05-17 03:28:49','user'),
(27,'Become Agent Request Approved','Congratulations! Your request to become an agent has been approved.','',1,0,'15',NULL,'2026-05-17 03:31:04','2026-05-17 03:31:04','user'),
(28,'Agent Verification Approved','Your agent verification request has been approved.','',1,0,'15',NULL,'2026-05-17 09:14:45','2026-05-17 09:14:45','user'),
(29,'Property Updated :- Mahaveer Nagar','Your property post approved by administrator','',1,0,'15',13,'2026-05-20 15:13:37','2026-05-20 15:13:37','user'),
(30,'Property Updated :- plot in barmer','Your property post approved by administrator','',1,0,'15',11,'2026-05-20 19:54:28','2026-05-20 19:54:28','user'),
(31,'Property Updated :- plot in barmer','Your property post approved by administrator','',1,0,'15',11,'2026-05-20 20:57:03','2026-05-20 20:57:03','user'),
(32,'Property Updated :- plot in barmer','Your property post approved by administrator','',1,0,'15',11,'2026-05-20 21:04:02','2026-05-20 21:04:02','user'),
(33,'Property Updated :- plot in barmer','Your property post approved by administrator','',1,0,'15',11,'2026-05-20 21:04:34','2026-05-20 21:04:34','user'),
(34,'Property Updated :- Mahaveer Nagar','Your property post approved by administrator','',1,0,'15',13,'2026-05-20 21:07:19','2026-05-20 21:07:19','user'),
(35,'Property Updated :- plot in barmer','Your property post approved by administrator','',1,0,'15',11,'2026-05-20 21:15:37','2026-05-20 21:15:37','user');
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `number_otps`
--

DROP TABLE IF EXISTS `number_otps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `number_otps` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(191) DEFAULT NULL,
  `number` varchar(191) DEFAULT NULL,
  `otp` varchar(191) NOT NULL,
  `expire_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `number_otps_number_unique` (`number`),
  UNIQUE KEY `number_otps_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `number_otps`
--

LOCK TABLES `number_otps` WRITE;
/*!40000 ALTER TABLE `number_otps` DISABLE KEYS */;
INSERT INTO `number_otps` VALUES
(1,'hetviwork06@gmail.com',NULL,'MjIyNjMx','2026-04-10 04:48:06','2026-04-10 04:38:06','2026-04-10 04:38:06'),
(2,'sukoongroup.co@gmail.com',NULL,'NTk5MjM5','2026-04-10 05:22:52','2026-04-10 05:12:52','2026-04-10 05:12:52'),
(3,'hemantsardadl@gmail.com',NULL,'OTI5MzE2','2026-04-10 05:35:09','2026-04-10 05:25:09','2026-04-10 05:25:09');
/*!40000 ALTER TABLE `number_otps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `old_packages`
--

DROP TABLE IF EXISTS `old_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `old_packages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ios_product_id` varchar(191) DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `duration` int(11) NOT NULL COMMENT 'Months',
  `price` double NOT NULL,
  `status` int(11) NOT NULL COMMENT '0:off,1:onn',
  `property_limit` int(11) DEFAULT NULL,
  `advertisement_limit` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `type` varchar(191) NOT NULL COMMENT 'product_listing/premium_user',
  PRIMARY KEY (`id`),
  UNIQUE KEY `packages_ios_product_id_unique` (`ios_product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `old_packages`
--

LOCK TABLES `old_packages` WRITE;
/*!40000 ALTER TABLE `old_packages` DISABLE KEYS */;
INSERT INTO `old_packages` VALUES
(1,NULL,'Trial Package',30,0,1,10,10,NULL,NULL,'');
/*!40000 ALTER TABLE `old_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `old_payments`
--

DROP TABLE IF EXISTS `old_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `old_payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` varchar(191) NOT NULL,
  `amount` double NOT NULL,
  `payment_gateway` varchar(191) NOT NULL,
  `package_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `status` varchar(191) NOT NULL COMMENT '1=success,2=fail',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `old_payments`
--

LOCK TABLES `old_payments` WRITE;
/*!40000 ALTER TABLE `old_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `old_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `old_user_purchased_packages`
--

DROP TABLE IF EXISTS `old_user_purchased_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `old_user_purchased_packages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `modal_type` varchar(191) NOT NULL,
  `modal_id` bigint(20) unsigned NOT NULL,
  `package_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `used_limit_for_property` int(11) NOT NULL DEFAULT 0,
  `used_limit_for_advertisement` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `prop_status` tinyint(1) NOT NULL DEFAULT 1,
  `adv_status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `user_purchased_packages_modal_type_modal_id_index` (`modal_type`,`modal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `old_user_purchased_packages`
--

LOCK TABLES `old_user_purchased_packages` WRITE;
/*!40000 ALTER TABLE `old_user_purchased_packages` DISABLE KEYS */;
/*!40000 ALTER TABLE `old_user_purchased_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `outdoor_facilities`
--

DROP TABLE IF EXISTS `outdoor_facilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `outdoor_facilities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `image` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_demo` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `outdoor_facilities`
--

LOCK TABLES `outdoor_facilities` WRITE;
/*!40000 ALTER TABLE `outdoor_facilities` DISABLE KEYS */;
INSERT INTO `outdoor_facilities` VALUES
(2,'Govement Hospital','1776415127-barmer-government-hospital.svg','2026-04-17 08:38:47','2026-05-21 04:02:46',0);
/*!40000 ALTER TABLE `outdoor_facilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `package_features`
--

DROP TABLE IF EXISTS `package_features`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `package_features` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `package_id` bigint(20) unsigned NOT NULL,
  `feature_id` bigint(20) unsigned NOT NULL,
  `limit_type` enum('limited','unlimited') NOT NULL,
  `limit` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_ids` (`package_id`,`feature_id`),
  KEY `package_features_feature_id_foreign` (`feature_id`),
  CONSTRAINT `package_features_feature_id_foreign` FOREIGN KEY (`feature_id`) REFERENCES `features` (`id`) ON DELETE CASCADE,
  CONSTRAINT `package_features_package_id_foreign` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `package_features`
--

LOCK TABLES `package_features` WRITE;
/*!40000 ALTER TABLE `package_features` DISABLE KEYS */;
INSERT INTO `package_features` VALUES
(1,1,1,'limited',1,'2026-04-15 03:01:38','2026-04-15 03:01:38',NULL),
(2,2,6,'unlimited',NULL,'2026-04-22 09:49:18','2026-04-22 09:49:18',NULL),
(3,3,1,'unlimited',NULL,'2026-05-17 09:17:15','2026-05-17 09:17:15',NULL),
(4,3,2,'unlimited',NULL,'2026-05-17 09:17:15','2026-05-17 09:17:15',NULL);
/*!40000 ALTER TABLE `package_features` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `packages`
--

DROP TABLE IF EXISTS `packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `packages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `ios_product_id` varchar(191) DEFAULT NULL,
  `package_type` enum('free','paid') NOT NULL,
  `purchase_type` enum('unlimited','one_time') NOT NULL DEFAULT 'unlimited',
  `price` double(10,2) DEFAULT NULL,
  `duration` int(11) NOT NULL COMMENT 'In Hours',
  `list_duration_type` varchar(191) DEFAULT NULL,
  `custom_duration` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `user_type` enum('user','agent') NOT NULL DEFAULT 'user',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `packages_ios_product_id_unique` (`ios_product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packages`
--

LOCK TABLES `packages` WRITE;
/*!40000 ALTER TABLE `packages` DISABLE KEYS */;
INSERT INTO `packages` VALUES
(1,'tests',NULL,'paid','unlimited',1.00,24,'Standard',NULL,1,'user','2026-04-15 03:01:38','2026-04-22 09:48:32',NULL),
(2,'test',NULL,'paid','unlimited',1.00,24,'Custom',1,1,'user','2026-04-22 09:49:18','2026-04-22 09:50:24',NULL),
(3,'Free',NULL,'free','unlimited',NULL,720,'Standard',NULL,1,'agent','2026-05-17 09:17:15','2026-05-17 09:17:25',NULL);
/*!40000 ALTER TABLE `packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `packages_backup`
--

DROP TABLE IF EXISTS `packages_backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `packages_backup` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `package_id` bigint(20) unsigned NOT NULL,
  `ios_product_id` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `packages_backup_package_id_foreign` (`package_id`),
  CONSTRAINT `packages_backup_package_id_foreign` FOREIGN KEY (`package_id`) REFERENCES `old_packages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packages_backup`
--

LOCK TABLES `packages_backup` WRITE;
/*!40000 ALTER TABLE `packages_backup` DISABLE KEYS */;
/*!40000 ALTER TABLE `packages_backup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parameters`
--

DROP TABLE IF EXISTS `parameters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parameters` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `type_of_parameter` varchar(191) DEFAULT NULL,
  `type_values` longtext DEFAULT NULL,
  `image` varchar(191) DEFAULT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_demo` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parameters`
--

LOCK TABLES `parameters` WRITE;
/*!40000 ALTER TABLE `parameters` DISABLE KEYS */;
INSERT INTO `parameters` VALUES
(1,'Bedroom','number',NULL,'1775153851-bedroom.svg',0,'2026-04-02 18:17:31','2026-04-02 18:17:31',1),
(2,'Bathroom','number',NULL,'1775153851-bathroom.svg',0,'2026-04-02 18:17:31','2026-04-02 18:17:31',1),
(3,'Kitchen','number',NULL,'1775153851-kitchen.svg',0,'2026-04-02 18:17:31','2026-04-02 18:17:31',1),
(4,'Parking','number',NULL,'1775153851-parking.svg',0,'2026-04-02 18:17:31','2026-04-02 18:17:31',1),
(5,'Area','number',NULL,'1775153851-area.svg',0,'2026-04-02 18:17:31','2026-04-02 18:17:31',1),
(6,'Property Type','dropdown','{\"0\":{\"value\":\"1 BHK\"},\"1\":{\"value\":\"2 BHK\"},\"2\":{\"value\":\"3 BHK\"},\"3\":{\"value\":\"4 BHK\"},\"4\":{\"value\":\"5 BHK\"}}','1775618342-sukoon-group-logo.svg',0,'2026-04-08 03:19:02','2026-04-08 03:19:02',0);
/*!40000 ALTER TABLE `parameters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(191) NOT NULL,
  `token` varchar(191) NOT NULL,
  `expires_at` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `password_resets_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_as_you_gos`
--

DROP TABLE IF EXISTS `pay_as_you_gos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay_as_you_gos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `price` double(8,2) NOT NULL,
  `type` varchar(191) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `ios_product_id` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_as_you_gos`
--

LOCK TABLES `pay_as_you_gos` WRITE;
/*!40000 ALTER TABLE `pay_as_you_gos` DISABLE KEYS */;
INSERT INTO `pay_as_you_gos` VALUES
(1,'Single Property Listing',0.00,'property',0,NULL,'2026-04-10 05:51:36','2026-04-15 03:11:30'),
(2,'Single Project Listing',0.00,'project',0,NULL,'2026-04-10 05:51:36','2026-04-15 03:11:28');
/*!40000 ALTER TABLE `pay_as_you_gos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_transactions`
--

DROP TABLE IF EXISTS `payment_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL COMMENT 'Customers',
  `package_id` bigint(20) unsigned DEFAULT NULL,
  `pay_as_you_go_id` bigint(20) unsigned DEFAULT NULL,
  `property_id` bigint(20) unsigned DEFAULT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `amount` double(10,2) NOT NULL,
  `payment_gateway` varchar(191) DEFAULT NULL,
  `payment_type` enum('online payment','bank transfer','free','manual') NOT NULL DEFAULT 'online payment',
  `reject_reason` text DEFAULT NULL,
  `order_id` varchar(255) DEFAULT NULL COMMENT 'Payment Intent Id / Order Id',
  `transaction_id` varchar(255) DEFAULT NULL COMMENT 'Success Transaction Id',
  `payment_status` enum('success','failed','pending','review','rejected') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role_context` enum('user','agent','general') NOT NULL DEFAULT 'user',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniques` (`payment_gateway`,`order_id`,`transaction_id`,`user_id`),
  KEY `payment_transactions_user_id_foreign` (`user_id`),
  KEY `payment_transactions_package_id_foreign` (`package_id`),
  KEY `payment_transactions_pay_as_you_go_id_foreign` (`pay_as_you_go_id`),
  KEY `payment_transactions_role_context_index` (`role_context`),
  CONSTRAINT `payment_transactions_package_id_foreign` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payment_transactions_pay_as_you_go_id_foreign` FOREIGN KEY (`pay_as_you_go_id`) REFERENCES `pay_as_you_gos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payment_transactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_transactions`
--

LOCK TABLES `payment_transactions` WRITE;
/*!40000 ALTER TABLE `payment_transactions` DISABLE KEYS */;
INSERT INTO `payment_transactions` VALUES
(3,10,1,NULL,NULL,NULL,10.00,'Razorpay','online payment',NULL,'plink_Sdc63EpncW67wa',NULL,'failed','2026-04-15 03:04:12','2026-04-15 03:21:10','user'),
(34,13,1,NULL,NULL,NULL,10.00,'Cashfree','online payment','Transaction Failed Automatically','',NULL,'failed','2026-04-15 11:37:19','2026-05-13 19:44:54','user'),
(35,13,1,NULL,NULL,NULL,10.00,'Cashfree','online payment','Transaction Failed Automatically','',NULL,'failed','2026-04-15 11:38:52','2026-05-13 19:44:54','user'),
(36,13,1,NULL,NULL,NULL,10.00,'Cashfree','online payment','Transaction Failed Automatically','',NULL,'failed','2026-04-15 11:39:00','2026-05-13 19:44:54','user'),
(37,13,1,NULL,NULL,NULL,10.00,'Cashfree','online payment','Transaction Failed Automatically','',NULL,'failed','2026-04-15 11:39:03','2026-05-13 19:44:54','user'),
(39,13,1,NULL,NULL,NULL,10.00,'Cashfree','online payment','Transaction Failed Automatically','',NULL,'failed','2026-04-15 11:39:37','2026-05-13 19:44:54','user'),
(40,13,1,NULL,NULL,NULL,10.00,'Cashfree','online payment','Transaction Failed Automatically','',NULL,'failed','2026-04-15 11:40:26','2026-05-13 19:44:54','user'),
(41,13,1,NULL,NULL,NULL,10.00,'Cashfree','online payment','Transaction Failed Automatically','',NULL,'failed','2026-04-15 11:40:40','2026-05-13 19:44:54','user'),
(53,13,1,NULL,NULL,NULL,10.00,'Cashfree','online payment','Transaction Failed Automatically','link_53',NULL,'failed','2026-04-15 11:51:22','2026-05-13 19:44:54','user'),
(54,13,1,NULL,NULL,NULL,10.00,'Cashfree','online payment','Transaction Failed Automatically','link_54',NULL,'failed','2026-04-15 11:54:35','2026-05-13 19:44:54','user'),
(56,13,1,NULL,NULL,NULL,10.00,'Cashfree','online payment','Transaction Failed Automatically','link_56',NULL,'failed','2026-04-15 12:02:40','2026-05-13 19:44:54','user'),
(57,13,1,NULL,NULL,NULL,10.00,'Cashfree','online payment','Transaction Failed Automatically','link_57',NULL,'failed','2026-04-15 12:02:46','2026-05-13 19:44:54','user'),
(76,10,1,NULL,NULL,NULL,10.00,'Razorpay','online payment',NULL,'plink_SeUdlMu1pO2zjN','pay_SeUem73MKDtpF5','success','2026-04-17 08:25:33','2026-04-17 08:26:35','user'),
(77,4,1,NULL,NULL,NULL,10.00,'Razorpay','online payment',NULL,'plink_SeVuWZpyLlioHW',NULL,'failed','2026-04-17 09:40:07','2026-04-17 09:56:17','user'),
(80,10,1,NULL,NULL,NULL,1.00,'Razorpay','online payment',NULL,'plink_Sfjrkc4azgB4XB',NULL,'failed','2026-04-20 11:58:12','2026-04-20 12:15:12','user'),
(86,10,1,NULL,NULL,NULL,1.00,'Razorpay','online payment',NULL,'plink_SgUgbhvhpvzUto','pay_SgUhMFvcgOJDuO','success','2026-04-22 09:46:15','2026-04-22 09:47:01','user'),
(91,16,2,NULL,NULL,NULL,1.00,'Razorpay','online payment',NULL,'plink_SgVDJxaox8WPEy',NULL,'failed','2026-04-22 10:17:14','2026-04-22 10:34:13','user'),
(92,16,2,NULL,NULL,NULL,1.00,'Razorpay','online payment',NULL,'plink_SgVECT1kDSiqnx',NULL,'failed','2026-04-22 10:18:04','2026-04-22 10:34:13','user'),
(98,4,1,NULL,NULL,NULL,1.00,'Cashfree','online payment',NULL,'link_98','link_98','success','2026-04-25 06:30:34','2026-04-25 06:31:21','user'),
(99,16,2,NULL,NULL,NULL,1.00,NULL,'manual',NULL,'d4f2a696-fe18-4dd6-9275-682b582bdc2a','b554c54a-367a-4f3d-b79d-437788f28adc','success','2026-04-25 06:40:42','2026-04-25 06:40:42','user'),
(100,15,1,NULL,NULL,NULL,1.00,'Cashfree','online payment',NULL,'link_100','link_100','success','2026-04-26 04:49:03','2026-04-26 04:49:53','user'),
(101,15,1,NULL,NULL,NULL,1.00,'Razorpay','online payment',NULL,'plink_SpBDAPL9TehPEn','pay_SpBDlHgWvmsVCL','success','2026-05-14 08:34:13','2026-05-14 08:34:51','user'),
(102,15,1,NULL,NULL,NULL,1.00,NULL,'manual',NULL,'bed0d46a-ec7c-48f6-8d8f-ba0f8501b22c','7c02e500-9728-4b72-9a43-159ef44c6fdb','success','2026-05-17 03:07:16','2026-05-17 03:07:16','user'),
(103,15,3,NULL,NULL,NULL,0.00,NULL,'free',NULL,'e38a72f5-632a-4485-9575-6daa46f74187','c7891130-91e7-42cf-b700-8f80dd8d3ca0','success','2026-05-17 09:17:34','2026-05-17 09:17:34','agent');
/*!40000 ALTER TABLE `payment_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(191) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
INSERT INTO `personal_access_tokens` VALUES
(1,'App\\Models\\Customer',1,'token-name','d347090ca25b5ea42640d1daa258b278a19d1f43b5d906f4f5f4b98be398e822','[\"*\"]','2026-05-14 20:02:45',NULL,'2026-04-06 03:09:52','2026-05-14 20:02:45'),
(2,'App\\Models\\Customer',2,'token-name','dc1197240b710d647d73a5fd02e5acdf6aee15b3c6485f2119766f793e425539','[\"*\"]','2026-04-06 11:47:22',NULL,'2026-04-06 11:23:20','2026-04-06 11:47:22'),
(3,'App\\Models\\Customer',2,'token-name','0919dfa43ee699cb369cba7e0ac61a09eb6782340f939af95e41ae5a98ac1040','[\"*\"]','2026-04-06 12:01:49',NULL,'2026-04-06 11:49:03','2026-04-06 12:01:49'),
(4,'App\\Models\\Customer',2,'token-name','0fbad4d3b437489d676162ad1d4bb18c04a1dacd74f61c4140abbf00a1344708','[\"*\"]','2026-04-06 12:21:35',NULL,'2026-04-06 12:03:35','2026-04-06 12:21:35'),
(5,'App\\Models\\Customer',2,'token-name','598d419e69cfecf186c259a223320cf2c14c5d6757b4017caa698a8746f13150','[\"*\"]','2026-04-06 12:28:43',NULL,'2026-04-06 12:26:25','2026-04-06 12:28:43'),
(6,'App\\Models\\Customer',3,'token-name','f22e3d5c4c3a1018227bb82850352510afa85703a651feade0321e30d4b4d512','[\"*\"]','2026-04-06 12:55:51',NULL,'2026-04-06 12:35:14','2026-04-06 12:55:51'),
(7,'App\\Models\\Customer',3,'token-name','e39175c8b48d92f67dde9fefa55564e886f8199eae61fe35316e8df9d9fc6b2b','[\"*\"]','2026-04-06 13:01:01',NULL,'2026-04-06 12:57:49','2026-04-06 13:01:01'),
(8,'App\\Models\\Customer',4,'token-name','6748b1c911c5c4d7f58e056287278b7445bd80130743866458edac7aee7b1e8d','[\"*\"]','2026-04-15 04:52:19',NULL,'2026-04-06 13:09:25','2026-04-15 04:52:19'),
(9,'App\\Models\\Customer',3,'token-name','4a9c6a76aa66daf6f2b24e6074fc97515cbe6e4e012890bed55092e9192ea98c','[\"*\"]','2026-04-06 13:24:30',NULL,'2026-04-06 13:24:27','2026-04-06 13:24:30'),
(10,'App\\Models\\Customer',3,'token-name','766bc2d91cc0edaa03864cedac6c263a41f4403dcbaae4d7bb8146e514026b97','[\"*\"]','2026-04-07 04:46:16',NULL,'2026-04-06 14:04:50','2026-04-07 04:46:16'),
(11,'App\\Models\\Customer',3,'token-name','faa65881c322a6f35c097a72d4e7b99cdf65e73cf411af9d08edf925ba628bfc','[\"*\"]','2026-04-08 04:40:35',NULL,'2026-04-07 05:22:16','2026-04-08 04:40:35'),
(12,'App\\Models\\Customer',3,'token-name','e92b93d1a45b11797351a40eb1edb438fc245500ec60c37cf0404a7652fa4ae1','[\"*\"]','2026-04-09 11:34:35',NULL,'2026-04-08 04:40:49','2026-04-09 11:34:35'),
(13,'App\\Models\\Customer',4,'token-name','4493d7538927d61bebbe11be8eaade207885e4c1c2cc7aacb959936749bcfa63','[\"*\"]','2026-04-08 04:50:27',NULL,'2026-04-08 04:50:23','2026-04-08 04:50:27'),
(14,'App\\Models\\Customer',3,'token-name','4653bf457994a788356b04d97390db4ac3e34ba6e4db5a02b13de0603bc7345f','[\"*\"]','2026-04-09 12:14:00',NULL,'2026-04-09 12:10:30','2026-04-09 12:14:00'),
(15,'App\\Models\\Customer',3,'token-name','ef974fa472aea43cdf6f455feb456afe3318a5d329fa4c591bdf48ff8acec0c4','[\"*\"]','2026-04-09 12:20:24',NULL,'2026-04-09 12:14:10','2026-04-09 12:20:24'),
(16,'App\\Models\\Customer',3,'token-name','bf8b83710f8ae10d92868c63efec623d3b4e1fe5d24215e51d8196c32a86c026','[\"*\"]','2026-04-09 12:23:32',NULL,'2026-04-09 12:20:32','2026-04-09 12:23:32'),
(17,'App\\Models\\Customer',5,'token-name','908041ea4062cb3b376e06a0ba95e6e7bf5c23310cee922c904b6e1b5167ba64','[\"*\"]','2026-05-17 03:04:38',NULL,'2026-04-10 02:45:41','2026-05-17 03:04:38'),
(18,'App\\Models\\Customer',7,'token-name','a11e8c9ed7a66afd599d31396f71be40e14dcfa9fc2e12a3efe9035bcfebd952','[\"*\"]','2026-04-10 04:41:39',NULL,'2026-04-10 04:41:28','2026-04-10 04:41:39'),
(19,'App\\Models\\Customer',9,'token-name','f002c5777c602c679b34d4cb76e03f75da7bb4237962288fd802e7f718a895b2','[\"*\"]','2026-04-10 05:39:10',NULL,'2026-04-10 05:25:40','2026-04-10 05:39:10'),
(20,'App\\Models\\Customer',10,'token-name','08269e76b0e72f2c582140f1b185b162435bddd3b59bec85fcdeee3271bda529','[\"*\"]','2026-04-10 18:37:56',NULL,'2026-04-10 05:40:11','2026-04-10 18:37:56'),
(21,'App\\Models\\Customer',3,'token-name','c8003d023b88c459255fcf652e37634814c5d4614e8f31e96733c2741dcf8e23','[\"*\"]','2026-04-15 15:56:11',NULL,'2026-04-10 05:48:09','2026-04-15 15:56:11'),
(22,'App\\Models\\Customer',11,'token-name','2271ae29aafb5d9a8b3bffd1d644a717b911403925e5eee050c9404e00e39d26','[\"*\"]','2026-04-11 12:28:19',NULL,'2026-04-11 12:26:27','2026-04-11 12:28:19'),
(23,'App\\Models\\Customer',11,'token-name','792f6b135a762501b3d373f5fae6e12d4e2d5401dc3709cc0fe1e7cad833cf35','[\"*\"]','2026-04-12 07:12:03',NULL,'2026-04-12 07:11:32','2026-04-12 07:12:03'),
(24,'App\\Models\\Customer',3,'token-name','e82fe0fc3457188bdac31f2adbb77836cb58e950a7bb1cdd378275ca46abcaf7','[\"*\"]','2026-04-12 07:12:44',NULL,'2026-04-12 07:12:30','2026-04-12 07:12:44'),
(25,'App\\Models\\Customer',12,'token-name','2913be8ba336d085744eebaa97cfade30d91efa98fe3d7d386670d72fdb11e7f','[\"*\"]','2026-04-12 11:50:16',NULL,'2026-04-12 11:50:01','2026-04-12 11:50:16'),
(26,'App\\Models\\Customer',10,'token-name','88c04c4dcd397ffd4bb993da96cdcdbd4a15a07903812db760e95c8d2bf53eeb','[\"*\"]','2026-04-15 12:39:53',NULL,'2026-04-15 02:59:43','2026-04-15 12:39:53'),
(27,'App\\Models\\Customer',4,'token-name','b2c168a7c4b4ed84303b4ad94998181caddfa377324ab634efa51fa989b43656','[\"*\"]','2026-04-15 08:07:18',NULL,'2026-04-15 04:54:32','2026-04-15 08:07:18'),
(28,'App\\Models\\Customer',13,'token-name','2c13a21e51c3e3ace1386cfb8a2cbad35dac860524b0191020865becf625f447','[\"*\"]','2026-04-15 12:02:46',NULL,'2026-04-15 08:14:39','2026-04-15 12:02:46'),
(29,'App\\Models\\Customer',13,'token-name','0770b9d81285b85ac1576fd4ffc42abaf77d15c2a480a7c615013fe329b61351','[\"*\"]','2026-04-15 12:00:19',NULL,'2026-04-15 12:00:14','2026-04-15 12:00:19'),
(30,'App\\Models\\Customer',14,'token-name','223f4dcc3eb350c978f2803abd7b6a357687288322490e1cdd56dc4b5ca72dcf','[\"*\"]','2026-04-15 12:18:56',NULL,'2026-04-15 12:00:41','2026-04-15 12:18:56'),
(31,'App\\Models\\Customer',10,'token-name','0ead2d2a6e32cac62c1bc6b49d6dfaffa51735aa94f31465c6938c3e77b82502','[\"*\"]','2026-04-22 00:16:19',NULL,'2026-04-16 13:10:44','2026-04-22 00:16:19'),
(32,'App\\Models\\Customer',3,'token-name','addb0f0341ae416fba45e7d16ec6dd1b5dc472149ab5189300daf22189e46097','[\"*\"]','2026-04-16 16:36:43',NULL,'2026-04-16 16:36:06','2026-04-16 16:36:43'),
(33,'App\\Models\\Customer',4,'token-name','335ebaf017aa8e37fe17da21b460b821e69bca268828cc6b1b6aa59b80381f39','[\"*\"]','2026-04-25 07:05:52',NULL,'2026-04-17 09:39:49','2026-04-25 07:05:52'),
(34,'App\\Models\\Customer',15,'token-name','ee4c51003ee84b3840bf0dfc8041fb1313bc2c873b6b241d3ff9b295652c04e2','[\"*\"]','2026-04-22 03:52:02',NULL,'2026-04-17 09:58:32','2026-04-22 03:52:02'),
(35,'App\\Models\\Customer',16,'token-name','e7b8e3c192f2643c44f06bac27e57cecd2db08a96ce4166e3edaba6124d9d345','[\"*\"]','2026-04-30 04:11:41',NULL,'2026-04-17 11:20:20','2026-04-30 04:11:41'),
(36,'App\\Models\\Customer',10,'token-name','5f2cfca31c0d6f80dea0970424f9c91ab103f15ea45702b8ec15c4630394764c','[\"*\"]','2026-04-22 09:39:01',NULL,'2026-04-17 16:37:32','2026-04-22 09:39:01'),
(37,'App\\Models\\Customer',10,'token-name','4bc169140b664010845a0bd5783275a04ae69825dd2b5109bc4333c42581907a','[\"*\"]','2026-04-22 10:05:28',NULL,'2026-04-22 09:40:07','2026-04-22 10:05:28'),
(38,'App\\Models\\Customer',15,'token-name','708e2739175e11906b7dad569a3204924043bf5bd54502477ca46a524fec350e','[\"*\"]','2026-04-26 05:03:05',NULL,'2026-04-25 06:44:12','2026-04-26 05:03:05'),
(39,'App\\Models\\Customer',4,'token-name','92d0807144b8d471f3c7c28d36f39e92a82cdb32a6e71eb8c27ccdb1ab6e7604','[\"*\"]','2026-05-14 06:52:16',NULL,'2026-04-25 07:06:28','2026-05-14 06:52:16'),
(40,'App\\Models\\Customer',17,'token-name','9cb39e72b00654ca9825f052ffea4bb7aa11ba96205153d8eb5a4e71ebec92be','[\"*\"]','2026-04-30 07:54:16',NULL,'2026-04-30 05:27:46','2026-04-30 07:54:16'),
(41,'App\\Models\\Customer',18,'token-name','5e17225bb6f795dc688c7a83e6e60f5c185bfff31fbf05afae62a4c8f3f7f0c4','[\"*\"]','2026-05-14 02:05:39',NULL,'2026-05-14 01:50:27','2026-05-14 02:05:39'),
(42,'App\\Models\\Customer',15,'token-name','964572ed8227ce6455db017b06a88147a3cdbb89752c0f34308dee62d488f847','[\"*\"]','2026-05-14 05:37:54',NULL,'2026-05-14 05:37:12','2026-05-14 05:37:54'),
(43,'App\\Models\\Customer',18,'token-name','11d0ac8037a8c702ae4c5597aa17293cc1272a511ad0c644a8fff6b3341510ab','[\"*\"]','2026-05-14 05:40:16',NULL,'2026-05-14 05:39:58','2026-05-14 05:40:16'),
(44,'App\\Models\\Customer',16,'token-name','8324e0e88309d377a934beac9230a6548ec41bc8f4a3c07df216cd7754b0b165','[\"*\"]','2026-05-14 10:39:05',NULL,'2026-05-14 05:40:27','2026-05-14 10:39:05'),
(45,'App\\Models\\Customer',16,'token-name','f8fa20dccf388926882627082af78781c28f2d9ac483959b30e923b126e305f4','[\"*\"]','2026-05-20 16:19:49',NULL,'2026-05-14 05:44:15','2026-05-20 16:19:49'),
(46,'App\\Models\\Customer',15,'token-name','c741a292636189eca7820f9e991405159c12e7c9917bcfde8b3323b2883d0931','[\"*\"]','2026-05-14 08:37:15',NULL,'2026-05-14 08:27:55','2026-05-14 08:37:15'),
(47,'App\\Models\\Customer',15,'token-name','77b9b6851de758ae445d489203b2843e84ef5a40745bac13201b992c2c72ac25','[\"*\"]','2026-05-14 18:21:54',NULL,'2026-05-14 08:40:37','2026-05-14 18:21:54'),
(48,'App\\Models\\Customer',15,'token-name','4b00c875cedb3b59437e564e9efd1d574fc9e969400dd5cb671af6d7a424e9b0','[\"*\"]','2026-05-14 23:05:40',NULL,'2026-05-14 18:55:12','2026-05-14 23:05:40'),
(49,'App\\Models\\Customer',15,'token-name','1d4d2379303ad71e67627d6f2149fc69b176dd34defa9bbccb600457188581ce','[\"*\"]','2026-05-16 07:18:54',NULL,'2026-05-15 00:02:00','2026-05-16 07:18:54'),
(50,'App\\Models\\Customer',15,'token-name','d6dc0cabdf135661d775ecbc6272cf90f9a950257043f3cda293364daacd5f96','[\"*\"]','2026-05-17 00:42:33',NULL,'2026-05-16 17:05:35','2026-05-17 00:42:33'),
(51,'App\\Models\\Customer',15,'token-name','caf800cfb7bce7e0c70962c52abda63c2626d396a018024e3e44039f32bc6d7e','[\"*\"]','2026-05-18 06:26:32',NULL,'2026-05-16 18:16:28','2026-05-18 06:26:32'),
(52,'App\\Models\\Customer',15,'token-name','e19132416828036012e6ae9a88b2b45ae05d98779f00498f53c32b221268e1e4','[\"*\"]','2026-05-17 00:57:01',NULL,'2026-05-17 00:44:29','2026-05-17 00:57:01'),
(53,'App\\Models\\Customer',15,'token-name','7bff3b0aec19cce3794ef2c1f87a2b9373e4d46758c0726c0aa8305dd8db2cfd','[\"*\"]','2026-05-17 05:20:01',NULL,'2026-05-17 01:15:54','2026-05-17 05:20:01'),
(54,'App\\Models\\Customer',15,'token-name','0dd06fd165080eb7de5087a1ecaf4f1709c54da55f13a5b9b4bb57d5d3a98bec','[\"*\"]','2026-05-17 11:40:10',NULL,'2026-05-17 03:05:09','2026-05-17 11:40:10'),
(55,'App\\Models\\Customer',15,'token-name','c9dcba2915ef05c73278239d57b5ccc4fbf72a54b34ed0329fe5a6fe245939a9','[\"*\"]','2026-05-18 10:00:05',NULL,'2026-05-17 06:09:55','2026-05-18 10:00:05'),
(56,'App\\Models\\Customer',15,'token-name','f20ef350be93c94cc581926dd637609c227667239a6692ce5136f7900fc1500c','[\"*\"]','2026-05-21 03:45:32',NULL,'2026-05-17 11:42:01','2026-05-21 03:45:32'),
(57,'App\\Models\\Customer',15,'token-name','3276efa0f923c402505cecd498ac320b38af54e77b17db68fd465f145bab0a59','[\"*\"]','2026-05-20 04:26:27',NULL,'2026-05-20 04:24:22','2026-05-20 04:26:27'),
(58,'App\\Models\\Customer',15,'token-name','37cbb90b62d0459199202260d7112485d4c523ca6f8fc2faf70ed1636cea4f0a','[\"*\"]','2026-05-20 05:03:02',NULL,'2026-05-20 04:54:35','2026-05-20 05:03:02'),
(59,'App\\Models\\Customer',15,'token-name','b8f3b66b79dcea6c8a0ba69a75b00481a591d3c6d50b6dfcfd5f5cc3b716118c','[\"*\"]','2026-05-20 15:37:27',NULL,'2026-05-20 14:19:13','2026-05-20 15:37:27'),
(60,'App\\Models\\Customer',15,'token-name','9a51307fc8414e3a6ab822f37a8ec9a08aeb0e9fee195547b612a31ec1be593c','[\"*\"]','2026-05-20 15:14:36',NULL,'2026-05-20 15:10:49','2026-05-20 15:14:36'),
(61,'App\\Models\\Customer',15,'token-name','b55831e9cd06136ac746736d740c1b4d11ade59874c25d883caec54c64e02eb8','[\"*\"]','2026-05-20 19:54:48',NULL,'2026-05-20 15:17:21','2026-05-20 19:54:48'),
(62,'App\\Models\\Customer',15,'token-name','c60bde2041609c34314ecad4cb844a07fcfa1f9cb07b29435d435696afc26bf0','[\"*\"]','2026-05-21 02:07:39',NULL,'2026-05-20 15:24:15','2026-05-21 02:07:39'),
(63,'App\\Models\\Customer',15,'token-name','d7e1a13b97bf9b4bd89622e9d12053943bf5ff87400b46f90a5ca86fcb8a803d','[\"*\"]','2026-05-20 22:02:46',NULL,'2026-05-20 16:20:00','2026-05-20 22:02:46'),
(67,'App\\Models\\Customer',1,'throttle-test-2-1','365fd3db135c3c9525a447b3c69713100a7f4832c5141928ac827ca0bb3ba0c4','[\"*\"]','2026-05-20 16:31:32',NULL,'2026-05-20 16:30:28','2026-05-20 16:31:32'),
(68,'App\\Models\\Customer',1,'throttle-test','0f6b31fb98229323f64365ff35cc0a96e9e47389c0d6d5c38d54e6aaf62fb278','[\"*\"]','2026-05-20 16:31:45',NULL,'2026-05-20 16:31:38','2026-05-20 16:31:45');
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_documents`
--

DROP TABLE IF EXISTS `project_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_documents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `type` varchar(191) NOT NULL COMMENT 'image/doc',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `project_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_documents_project_id_foreign` (`project_id`),
  CONSTRAINT `project_documents_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_documents`
--

LOCK TABLES `project_documents` WRITE;
/*!40000 ALTER TABLE `project_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_plans`
--

DROP TABLE IF EXISTS `project_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_plans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) NOT NULL,
  `document` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `project_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_plans_project_id_foreign` (`project_id`),
  CONSTRAINT `project_plans_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_plans`
--

LOCK TABLES `project_plans` WRITE;
/*!40000 ALTER TABLE `project_plans` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_views`
--

DROP TABLE IF EXISTS `project_views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_views` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `views` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_project_view_user` (`user_id`,`project_id`,`date`),
  KEY `project_id_index` (`project_id`),
  CONSTRAINT `project_views_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `project_views_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_views`
--

LOCK TABLES `project_views` WRITE;
/*!40000 ALTER TABLE `project_views` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_views` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) NOT NULL,
  `slug_id` varchar(191) NOT NULL,
  `description` text NOT NULL,
  `meta_title` text DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `meta_keywords` text DEFAULT NULL,
  `meta_image` varchar(191) DEFAULT NULL,
  `image` varchar(191) NOT NULL,
  `video_link` varchar(191) DEFAULT NULL,
  `video_type` tinyint(4) DEFAULT NULL COMMENT '0:Custom, 1:YouTube, 2:Vimeo',
  `location` varchar(191) NOT NULL,
  `latitude` varchar(191) NOT NULL,
  `longitude` varchar(191) NOT NULL,
  `city` varchar(191) NOT NULL,
  `state` varchar(191) NOT NULL,
  `country` varchar(191) NOT NULL,
  `type` varchar(191) NOT NULL COMMENT 'under_construction,upcoming',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `added_by` bigint(20) unsigned DEFAULT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `is_premium` tinyint(1) NOT NULL DEFAULT 0,
  `request_status` enum('approved','rejected','pending','draft') NOT NULL DEFAULT 'pending',
  `expiry_date` timestamp NULL DEFAULT NULL,
  `edit_reason` text DEFAULT NULL,
  `total_click` bigint(20) NOT NULL DEFAULT 0,
  `is_admin_listing` tinyint(1) NOT NULL DEFAULT 0,
  `role_context` enum('user','agent','general') NOT NULL DEFAULT 'user',
  PRIMARY KEY (`id`),
  UNIQUE KEY `projects_slug_id_unique` (`slug_id`),
  KEY `projects_added_by_foreign` (`added_by`),
  KEY `projects_category_id_foreign` (`category_id`),
  KEY `projects_role_context_index` (`role_context`),
  CONSTRAINT `projects_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `projects_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `properties_documents`
--

DROP TABLE IF EXISTS `properties_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `properties_documents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `property_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL COMMENT 'file name with folder',
  `type` varchar(191) NOT NULL COMMENT 'file type',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `properties_documents_property_id_foreign` (`property_id`),
  CONSTRAINT `properties_documents_property_id_foreign` FOREIGN KEY (`property_id`) REFERENCES `propertys` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `properties_documents`
--

LOCK TABLES `properties_documents` WRITE;
/*!40000 ALTER TABLE `properties_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `properties_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `property_images`
--

DROP TABLE IF EXISTS `property_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `property_images` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `propertys_id` bigint(20) NOT NULL,
  `image` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `property_images`
--

LOCK TABLES `property_images` WRITE;
/*!40000 ALTER TABLE `property_images` DISABLE KEYS */;
INSERT INTO `property_images` VALUES
(1,1,'1775153852-living-room.jpg','2026-04-02 18:17:32','2026-04-02 18:17:32'),
(2,1,'1775153852-kitchen.jpg','2026-04-02 18:17:32','2026-04-02 18:17:32'),
(3,1,'1775153852-bedroom.jpg','2026-04-02 18:17:32','2026-04-02 18:17:32'),
(4,2,'1775153853-living-room.jpg','2026-04-02 18:17:33','2026-04-02 18:17:33'),
(5,2,'1775153853-kitchen.jpg','2026-04-02 18:17:33','2026-04-02 18:17:33'),
(6,2,'1775153853-bedroom.jpg','2026-04-02 18:17:33','2026-04-02 18:17:33'),
(7,3,'1775153854-living-room.jpg','2026-04-02 18:17:34','2026-04-02 18:17:34'),
(8,3,'1775153854-kitchen.jpg','2026-04-02 18:17:34','2026-04-02 18:17:34'),
(9,3,'1775153854-bedroom.jpg','2026-04-02 18:17:34','2026-04-02 18:17:34'),
(10,4,'1775153855-living-room.jpg','2026-04-02 18:17:35','2026-04-02 18:17:35'),
(11,4,'1775153855-kitchen.jpg','2026-04-02 18:17:35','2026-04-02 18:17:35'),
(12,4,'1775153855-bedroom.jpg','2026-04-02 18:17:35','2026-04-02 18:17:35'),
(13,5,'1775153855-living-room.jpg','2026-04-02 18:17:35','2026-04-02 18:17:35'),
(14,5,'1775153855-kitchen.jpg','2026-04-02 18:17:35','2026-04-02 18:17:35'),
(15,5,'1775153855-bedroom.jpg','2026-04-02 18:17:35','2026-04-02 18:17:35'),
(16,6,'1775153856-living-room.jpg','2026-04-02 18:17:36','2026-04-02 18:17:36'),
(17,6,'1775153856-kitchen.jpg','2026-04-02 18:17:36','2026-04-02 18:17:36'),
(18,6,'1775153856-bedroom.jpg','2026-04-02 18:17:36','2026-04-02 18:17:36'),
(19,7,'1775153856-living-room.jpg','2026-04-02 18:17:36','2026-04-02 18:17:36'),
(20,7,'1775153856-kitchen.jpg','2026-04-02 18:17:36','2026-04-02 18:17:36'),
(21,7,'1775153856-bedroom.jpg','2026-04-02 18:17:36','2026-04-02 18:17:36'),
(22,8,'1775153857-living-room.jpg','2026-04-02 18:17:37','2026-04-02 18:17:37'),
(23,8,'1775153857-kitchen.jpg','2026-04-02 18:17:37','2026-04-02 18:17:37'),
(24,8,'1775153857-bedroom.jpg','2026-04-02 18:17:37','2026-04-02 18:17:37');
/*!40000 ALTER TABLE `property_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `property_views`
--

DROP TABLE IF EXISTS `property_views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `property_views` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `property_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `views` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_property_view_user` (`user_id`,`property_id`,`date`),
  KEY `property_id_index` (`property_id`),
  CONSTRAINT `property_views_property_id_foreign` FOREIGN KEY (`property_id`) REFERENCES `propertys` (`id`) ON DELETE CASCADE,
  CONSTRAINT `property_views_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `property_views`
--

LOCK TABLES `property_views` WRITE;
/*!40000 ALTER TABLE `property_views` DISABLE KEYS */;
INSERT INTO `property_views` VALUES
(1,4,10,'2026-04-15',1,'2026-04-15 02:59:57','2026-04-15 02:59:57'),
(2,4,5,'2026-04-16',1,'2026-04-16 11:02:29','2026-04-16 11:02:29'),
(3,4,3,'2026-04-16',1,'2026-04-16 16:36:43','2026-04-16 16:36:43'),
(4,7,15,'2026-04-17',1,'2026-04-17 10:00:38','2026-04-17 10:00:38'),
(5,5,16,'2026-04-17',1,'2026-04-17 11:20:31','2026-04-17 11:20:31'),
(6,1,10,'2026-04-19',1,'2026-04-19 04:21:05','2026-04-19 04:21:05'),
(7,5,16,'2026-04-19',1,'2026-04-19 06:45:17','2026-04-19 06:45:17'),
(8,2,16,'2026-04-22',1,'2026-04-22 03:55:58','2026-04-22 03:55:58'),
(9,1,16,'2026-04-22',1,'2026-04-22 03:56:04','2026-04-22 03:56:04'),
(10,4,4,'2026-04-25',1,'2026-04-25 06:21:51','2026-04-25 06:21:51'),
(11,1,16,'2026-04-25',1,'2026-04-25 06:53:19','2026-04-25 06:53:19'),
(12,10,16,'2026-04-25',1,'2026-04-25 07:02:42','2026-04-25 07:02:42'),
(13,4,16,'2026-04-26',1,'2026-04-26 03:59:12','2026-04-26 03:59:12'),
(14,8,15,'2026-05-14',1,'2026-05-14 05:37:22','2026-05-14 05:37:22'),
(15,4,15,'2026-05-14',1,'2026-05-14 05:37:40','2026-05-14 05:37:40'),
(16,2,16,'2026-05-14',1,'2026-05-14 05:40:44','2026-05-14 05:40:44'),
(17,4,16,'2026-05-14',1,'2026-05-14 05:44:43','2026-05-14 05:44:43'),
(18,9,16,'2026-05-14',1,'2026-05-14 07:48:42','2026-05-14 07:48:42'),
(19,7,15,'2026-05-14',1,'2026-05-14 08:29:27','2026-05-14 08:29:27'),
(20,11,15,'2026-05-14',1,'2026-05-14 08:40:47','2026-05-14 08:40:47'),
(21,11,16,'2026-05-14',1,'2026-05-14 10:39:05','2026-05-14 10:39:05'),
(22,4,15,'2026-05-15',1,'2026-05-15 00:02:40','2026-05-15 00:02:40'),
(23,8,15,'2026-05-15',1,'2026-05-15 02:28:04','2026-05-15 02:28:04'),
(24,10,15,'2026-05-16',1,'2026-05-16 18:20:20','2026-05-16 18:20:20'),
(25,2,15,'2026-05-16',1,'2026-05-16 18:21:33','2026-05-16 18:21:33'),
(26,11,5,'2026-05-17',1,'2026-05-17 02:44:43','2026-05-17 02:44:43'),
(27,12,5,'2026-05-17',1,'2026-05-17 02:44:58','2026-05-17 02:44:58'),
(28,5,15,'2026-05-17',1,'2026-05-17 17:55:34','2026-05-17 17:55:34'),
(29,8,15,'2026-05-18',1,'2026-05-18 00:27:15','2026-05-18 00:27:15'),
(30,10,15,'2026-05-18',1,'2026-05-18 05:12:54','2026-05-18 05:12:54'),
(31,5,15,'2026-05-18',1,'2026-05-18 06:06:32','2026-05-18 06:06:32'),
(32,7,15,'2026-05-18',1,'2026-05-18 06:07:16','2026-05-18 06:07:16'),
(33,9,15,'2026-05-18',1,'2026-05-18 06:10:29','2026-05-18 06:10:29'),
(34,2,15,'2026-05-18',1,'2026-05-18 06:24:50','2026-05-18 06:24:50'),
(35,4,15,'2026-05-18',1,'2026-05-18 06:26:32','2026-05-18 06:26:32'),
(36,2,15,'2026-05-20',1,'2026-05-20 04:26:14','2026-05-20 04:26:14'),
(37,5,15,'2026-05-20',1,'2026-05-20 04:57:22','2026-05-20 04:57:22'),
(38,1,15,'2026-05-20',1,'2026-05-20 05:01:59','2026-05-20 05:01:59'),
(39,4,15,'2026-05-20',1,'2026-05-20 14:19:59','2026-05-20 14:19:59'),
(40,13,15,'2026-05-20',1,'2026-05-20 15:17:35','2026-05-20 15:17:35'),
(41,8,15,'2026-05-20',1,'2026-05-20 15:19:22','2026-05-20 15:19:22'),
(42,12,16,'2026-05-20',1,'2026-05-20 16:19:24','2026-05-20 16:19:24'),
(43,11,16,'2026-05-20',1,'2026-05-20 16:19:33','2026-05-20 16:19:33'),
(44,13,16,'2026-05-20',1,'2026-05-20 16:19:40','2026-05-20 16:19:40'),
(45,1,15,'2026-05-21',1,'2026-05-21 01:05:47','2026-05-21 01:05:47'),
(46,8,15,'2026-05-21',1,'2026-05-21 01:10:49','2026-05-21 01:10:49'),
(47,4,15,'2026-05-21',1,'2026-05-21 01:16:03','2026-05-21 01:16:03'),
(48,9,15,'2026-05-21',1,'2026-05-21 01:20:47','2026-05-21 01:20:47'),
(49,10,15,'2026-05-21',1,'2026-05-21 02:07:38','2026-05-21 02:07:38');
/*!40000 ALTER TABLE `property_views` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `propertys`
--

DROP TABLE IF EXISTS `propertys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `propertys` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` varchar(191) NOT NULL,
  `package_id` int(11) DEFAULT NULL,
  `title` varchar(191) NOT NULL,
  `description` longtext NOT NULL,
  `address` varchar(191) NOT NULL,
  `client_address` varchar(191) NOT NULL,
  `propery_type` tinyint(4) NOT NULL COMMENT '0:Sell 1:Rent',
  `price` bigint(20) NOT NULL,
  `post_type` varchar(191) DEFAULT NULL COMMENT '0 :admin 1:customer',
  `city` varchar(191) DEFAULT 'Kutch',
  `country` varchar(191) DEFAULT NULL,
  `state` varchar(191) DEFAULT NULL,
  `title_image` text NOT NULL,
  `three_d_image` varchar(191) NOT NULL,
  `video_link` varchar(191) DEFAULT NULL,
  `video_type` tinyint(4) DEFAULT NULL COMMENT '0=custom,1=youtube,2=vimeo',
  `latitude` varchar(191) NOT NULL,
  `longitude` varchar(191) NOT NULL,
  `added_by` int(11) NOT NULL DEFAULT 0,
  `status` tinyint(4) NOT NULL DEFAULT 0 COMMENT ' 0: Deactive 1: Active',
  `request_status` enum('approved','rejected','pending','draft') NOT NULL DEFAULT 'pending',
  `expiry_date` timestamp NULL DEFAULT NULL,
  `edit_reason` text DEFAULT NULL,
  `total_click` bigint(20) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `rentduration` varchar(191) DEFAULT NULL,
  `slug_id` varchar(191) NOT NULL,
  `meta_title` text DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `meta_keywords` text DEFAULT NULL,
  `meta_image` varchar(191) DEFAULT NULL,
  `is_premium` tinyint(1) NOT NULL DEFAULT 0,
  `is_demo` tinyint(1) NOT NULL DEFAULT 0,
  `role_context` enum('user','agent','general') NOT NULL DEFAULT 'user',
  PRIMARY KEY (`id`),
  UNIQUE KEY `propertys_slug_id_unique` (`slug_id`),
  KEY `propertys_role_context_index` (`role_context`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `propertys`
--

LOCK TABLES `propertys` WRITE;
/*!40000 ALTER TABLE `propertys` DISABLE KEYS */;
INSERT INTO `propertys` VALUES
(1,'1',NULL,'Luxury Sunset Villa','Experience luxury living in this stunning villa with breathtaking sunset views. Features modern architecture, spacious rooms, and premium finishes throughout.','Jadura Road, Bhuj, Bhuj Taluka, Kutch, Gujarat, 370001, India','Barmer Rajasthan',0,2500000,'0','Bhuj','India','Gujarat','1775153852-luxury-sunset-villa.png','','',NULL,'23.183189','69.684075',0,1,'approved',NULL,NULL,5,'2026-04-02 18:17:32','2026-05-21 01:05:47',NULL,'luxury-sunset-villa','Luxury Sunset Villa - Premium Property','Experience luxury living in this stunning villa with breathtaking sunset views.','villa, luxury, sunset, modern, premium',NULL,0,1,'agent'),
(2,'2',NULL,'Modern Family House','Perfect family home with spacious rooms, beautiful garden, and located in a peaceful neighborhood. Close to schools and shopping centers.','Bhuj, Bhuj Taluka, Kutch, Gujarat, 370001, India','Barmer Rajasthan',0,850000,'0','Bhuj','India','Gujarat','1775153853-modern-family-house.png','','',NULL,'23.193023','69.73511',0,1,'approved',NULL,NULL,5,'2026-04-02 18:17:33','2026-05-20 04:26:14',NULL,'modern-family-house','Modern Family House - Comfortable Living','Perfect family home with spacious rooms and beautiful garden.','house, family, modern, garden, suburban',NULL,0,1,'agent'),
(3,'3',NULL,'Downtown Luxury Apartment','Stylish apartment in the heart of downtown with stunning city views. Walking distance to restaurants, shops, and entertainment.','Makanpar- Ratiya, ઢોંસા, Bhuj Taluka, Kutch, Gujarat, 370030, India','Barmer Rajasthan',1,3500,'0','ઢોંસા','India','Gujarat','1775153853-downtown-luxury-apartment.png','','',NULL,'23.316917','69.619828',0,1,'approved',NULL,NULL,0,'2026-04-02 18:17:34','2026-04-02 18:17:34','Monthly','downtown-luxury-apartment','Downtown Luxury Apartment - City Living','Stylish apartment in the heart of downtown with stunning city views.','apartment, downtown, luxury, city view, modern',NULL,1,1,'agent'),
(4,'4',NULL,'Prime Office Space','Modern office space in premium business district. Perfect for startups and established businesses. High-speed internet and modern amenities included.','Ray Colony, Barmer, Rajasthan 344001, India','Barmer Rajasthan',1,8000,'0','Barmer','India','Rajasthan','1775153854-prime-office-space.png','',NULL,NULL,'25.7522057','71.3865196',0,1,'approved',NULL,NULL,11,'2026-04-02 18:17:35','2026-05-21 01:16:03','Monthly','prime-office-space','Prime Office Space - Business District','Modern office space in premium business district.','commercial, office, business, modern, premium',NULL,0,1,'agent'),
(5,'5',NULL,'Residential Plot - Prime Location','Excellent investment opportunity! Prime residential plot in developing area with all utilities available. Perfect for building your dream home.','Mandvi Road, Shajanand Nagar, કુરબાઈ, Bhuj Taluka, Kutch, Gujarat, 370001, India','Barmer Rajasthan',0,450000,'0','કુરબાઈ','India','Gujarat','1775153855-residential-plot-prime-location.png','','',NULL,'23.197362','69.60907',0,1,'approved',NULL,NULL,5,'2026-04-02 18:17:35','2026-05-20 04:57:22',NULL,'residential-plot-prime-location','Residential Plot - Prime Location','Prime residential plot in developing area with all utilities available.','plot, land, residential, investment, development',NULL,0,1,'agent'),
(6,'1',NULL,'Beachfront Paradise Villa','Wake up to ocean views every day! This magnificent beachfront villa offers direct beach access, infinity pool, and luxurious amenities.','Barmer, Rajasthan 344001, India','Barmer Rajasthan',0,3200000,'0','Barmer','India','Rajasthan','1775153856-beachfront-paradise-villa.jpg','',NULL,NULL,'25.7521467','71.3966865',0,1,'approved',NULL,NULL,0,'2026-04-02 18:17:36','2026-05-20 20:45:57',NULL,'beachfront-paradise-villa','Beachfront Paradise Villa - Ocean Views','Magnificent beachfront villa with direct beach access and infinity pool.','villa, beachfront, ocean, luxury, paradise',NULL,1,1,'agent'),
(7,'2',NULL,'Cozy Cottage House','Charming cottage-style house perfect for small families or couples. Features a beautiful garden, fireplace, and peaceful surroundings.','પાલારા, Bhuj Taluka, Kutch, Gujarat, 370001, India','Barmer Rajasthan',1,2200,'0','પાલારા','India','Gujarat','1775153856-cozy-cottage-house.png','','',NULL,'23.298981','69.660412',0,1,'approved',NULL,NULL,3,'2026-04-02 18:17:36','2026-05-18 06:07:16','Yearly','cozy-cottage-house','Cozy Cottage House - Peaceful Living','Charming cottage-style house with beautiful garden and fireplace.','house, cottage, cozy, garden, peaceful',NULL,0,1,'agent'),
(8,'3',NULL,'Modern Studio Apartment','Efficient and stylish studio apartment perfect for young professionals. Fully furnished with modern appliances and great location.','Nehru Nagar, Barmer, Rajasthan 344001, India','Barmer Rajasthan',1,1800,'0','Barmer','India','Rajasthan','1775153857-modern-studio-apartment.png','',NULL,NULL,'25.7461698','71.39717739999999',0,1,'approved',NULL,NULL,5,'2026-04-02 18:17:37','2026-05-21 01:10:49','Monthly','modern-studio-apartment','Modern Studio Apartment - Urban Living','Efficient and stylish studio apartment for young professionals.','apartment, studio, modern, urban, furnished',NULL,0,1,'agent'),
(9,'2',0,'Modern Studio Apartment','Efficient and stylish studio apartment perfect for young professionals. Fully furnished with modern appliances and great location.','Q55W+333, Conductor Colony, Burari Garhi, Burari, New Delhi, Delhi, 110084, India','New Delhi',1,2000,'0','New Delhi','India','Delhi','1777095412-1775153857-modern-studio-apartment.png','',NULL,NULL,'28.757714746679035','77.19525898311815',0,1,'approved',NULL,NULL,3,'2026-04-25 05:36:53','2026-05-21 01:20:47','Monthly','modern-studio-apartment-1','Modern Studio Apartment - Urban Living','Efficient and stylish studio apartment for young professionals.','apartment, studio, modern, urban, furnished',NULL,0,0,'agent'),
(10,'5',0,'plot','## Prime Plot for Sale in [Desirable Neighborhood Name], [City Name]\r\n\r\n**Discover your dream opportunity with this exceptional plot of land, perfectly situated in the highly sought-after [Desirable Neighborhood Name] of [City Name].** This is more than just a piece of land; it\'s a canvas for your future, offering an unparalleled chance to build your ideal home or investment property in a location that truly has it all.\r\n\r\nBoasting a generous [mention approximate size, e.g., 500 sqm] of cleared and ready-to-build space, this plot presents incredible potential. Imagine designing and constructing a residence that perfectly reflects your lifestyle, from a modern family home to a luxurious villa. The [mention any specific features of the plot itself, e.g., flat topography, mature trees, pre-approved plans if applicable] makes for seamless development.\r\n\r\nThe location is a significant draw. Nestled within [Desirable Neighborhood Name], you\'ll enjoy the perfect blend of tranquility and convenience. This vibrant community offers easy access to a wealth of amenities, including [mention 2-3 key amenities, e.g., top-rated schools, bustling shopping districts, beautiful parks, excellent public transport links]. Commuting is a breeze with [mention proximity to major roads or transport hubs]. Furthermore, the area is renowned for its [mention positive neighborhood characteristics, e.g., family-friendly atmosphere, growing infrastructure, natural beauty].\r\n\r\nDon\'t miss this rare chance to secure a prime parcel of land in one of [City Name]\'s most desirable areas. Whether you\'re a discerning homeowner looking to build your forever home or a savvy investor seeking a valuable addition to your portfolio, this plot is an opportunity not to be overlooked.\r\n\r\n**Contact us today to learn more and schedule a viewing!**','64, Keshav Nagar, Kadipur, New Delhi, Delhi, 110084, India','Barmer Rajasthan',1,100,'0','New Delhi','India','Delhi','1777095593-1775153857-modern-studio-apartment.png','',NULL,NULL,'28.78014066438572','77.17941825667292',0,1,'approved',NULL,NULL,4,'2026-04-25 05:39:54','2026-05-21 02:07:38','Daily','plot','plot','','',NULL,0,0,'agent'),
(11,'5',NULL,'plot in barmer','test','HPG2+86W, Maharana Udai Singh Market, Ganesh Ghati, Udaipur, Rajasthan 313001, India','Opp lalit shop gaur chatrawas',0,123,'1','Udaipur','India','Rajasthan','1778747787-capture.png','',NULL,NULL,'24.5761','73.7005',15,1,'approved','2026-06-13 08:36:49','test',4,'2026-05-14 08:32:52','2026-05-20 21:15:37',NULL,'plot-in-barmer',NULL,NULL,NULL,NULL,0,0,'user'),
(12,'2',NULL,'test','tesy','new Barmer, Rajasthan 344001, India','rai colony krishna nagar barmer',1,22,'1','Barmer','India','Rajasthan','1778763041-nl.png','',NULL,NULL,'25.7521467','71.3966865',15,1,'approved','2026-06-13 12:51:43','new',2,'2026-05-14 12:50:41','2026-05-20 16:19:24','Daily','test','','','',NULL,0,0,'user'),
(13,'2',NULL,'Mahaveer Nagar','2bhk fully furnish','krishna Nagar, Barmer, Rajasthan 344001, India','opp lalit store gaur chatravas',1,8000,'1','Barmer','India','Rajasthan','1779290002-sc.jpg','',NULL,NULL,'25.751482','71.392473',15,1,'approved','2026-06-19 15:13:37',NULL,2,'2026-05-20 15:13:22','2026-05-20 21:07:19','Monthly','mahaveer-nagar',NULL,NULL,NULL,NULL,0,0,'agent');
/*!40000 ALTER TABLE `propertys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `propertys_inquiry`
--

DROP TABLE IF EXISTS `propertys_inquiry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `propertys_inquiry` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `propertys_id` bigint(20) unsigned NOT NULL,
  `customers_id` bigint(20) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0 : Pending 1:Accept  2: Complete 3:Cancle',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `propertys_inquiry_propertys_id_foreign` (`propertys_id`),
  KEY `propertys_inquiry_customers_id_foreign` (`customers_id`),
  CONSTRAINT `propertys_inquiry_customers_id_foreign` FOREIGN KEY (`customers_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `propertys_inquiry_propertys_id_foreign` FOREIGN KEY (`propertys_id`) REFERENCES `propertys` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `propertys_inquiry`
--

LOCK TABLES `propertys_inquiry` WRITE;
/*!40000 ALTER TABLE `propertys_inquiry` DISABLE KEYS */;
/*!40000 ALTER TABLE `propertys_inquiry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reject_reasons`
--

DROP TABLE IF EXISTS `reject_reasons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reject_reasons` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `property_id` bigint(20) unsigned DEFAULT NULL,
  `project_id` bigint(20) unsigned DEFAULT NULL,
  `agent_verification_id` bigint(20) unsigned DEFAULT NULL,
  `verify_customer_id` bigint(20) unsigned DEFAULT NULL,
  `reason` longtext NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reject_reasons_property_id_foreign` (`property_id`),
  KEY `reject_reasons_project_id_foreign` (`project_id`),
  KEY `reject_reasons_agent_verification_id_foreign` (`agent_verification_id`),
  KEY `reject_reasons_verify_customer_id_foreign` (`verify_customer_id`),
  CONSTRAINT `reject_reasons_agent_verification_id_foreign` FOREIGN KEY (`agent_verification_id`) REFERENCES `agent_verifications` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reject_reasons_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reject_reasons_property_id_foreign` FOREIGN KEY (`property_id`) REFERENCES `propertys` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reject_reasons_verify_customer_id_foreign` FOREIGN KEY (`verify_customer_id`) REFERENCES `verify_customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reject_reasons`
--

LOCK TABLES `reject_reasons` WRITE;
/*!40000 ALTER TABLE `reject_reasons` DISABLE KEYS */;
/*!40000 ALTER TABLE `reject_reasons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_reasons`
--

DROP TABLE IF EXISTS `report_reasons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report_reasons` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `reason` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_reasons`
--

LOCK TABLES `report_reasons` WRITE;
/*!40000 ALTER TABLE `report_reasons` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_reasons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_user_by_agents`
--

DROP TABLE IF EXISTS `report_user_by_agents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report_user_by_agents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `is_admin_data` tinyint(1) NOT NULL DEFAULT 0,
  `admin_id` bigint(20) unsigned DEFAULT NULL,
  `agent_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `reason` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_admin_agent_user` (`admin_id`,`agent_id`,`user_id`),
  KEY `report_user_by_agents_agent_id_foreign` (`agent_id`),
  KEY `report_user_by_agents_user_id_foreign` (`user_id`),
  CONSTRAINT `report_user_by_agents_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `report_user_by_agents_agent_id_foreign` FOREIGN KEY (`agent_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `report_user_by_agents_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_user_by_agents`
--

LOCK TABLES `report_user_by_agents` WRITE;
/*!40000 ALTER TABLE `report_user_by_agents` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_user_by_agents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seo_settings`
--

DROP TABLE IF EXISTS `seo_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seo_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `page` varchar(191) NOT NULL,
  `image` varchar(191) NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `schema_markup` text DEFAULT NULL,
  `keywords` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seo_settings`
--

LOCK TABLES `seo_settings` WRITE;
/*!40000 ALTER TABLE `seo_settings` DISABLE KEYS */;
INSERT INTO `seo_settings` VALUES
(1,'homepage','1775579242-sukoon-homes-logo.png','Sukoon Group','Buy, Sell and Rent properties with Sukoon Homes Available Now In Barmer, Rajasthan','{\r\n  \"@context\": \"https://schema.org\",\r\n  \"@type\": \"RealEstateAgent\",\r\n  \"name\": \"Sukoon Homes\",\r\n  \"url\": \"https://homes.sukoon.group\",\r\n  \"description\": \"Buy, Sell and Rent properties with Sukoon Homes\",\r\n  \"telephone\": \"+91-8594882948\",\r\n  \"address\": {\r\n    \"@type\": \"PostalAddress\",\r\n    \"addressCountry\": \"IN\"\r\n  }\r\n}','real estate, buy, sell, rent, property, Sukoon Homes. Barmer','2026-04-07 16:27:22','2026-04-17 03:20:05');
/*!40000 ALTER TABLE `seo_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_health_logs`
--

DROP TABLE IF EXISTS `service_health_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service_health_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` enum('valid','invalid') NOT NULL,
  `response_message` text DEFAULT NULL,
  `domain_checked` varchar(191) NOT NULL,
  `checksum` varchar(64) DEFAULT NULL,
  `checked_at` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `service_health_logs_checked_at_index` (`checked_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_health_logs`
--

LOCK TABLES `service_health_logs` WRITE;
/*!40000 ALTER TABLE `service_health_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `service_health_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(191) NOT NULL,
  `data` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=195 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES
(1,'category_background','#087C7C14','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(2,'sell_web_color','#14B8DCFF','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(3,'sell_web_background_color','#14B8DC1F','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(4,'rent_web_color','#E48D18FF','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(5,'rent_web_background_color','#E48D181F','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(6,'number_with_otp_login','1','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(7,'social_login','1','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(8,'distance_option','km','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(9,'otp_service_provider','firebase','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(10,'text_property_submission','Your property has been added and is pending review. The admin will enable it once the review is complete.','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(11,'email_configuration_verification','1','2026-04-01 12:38:22','2026-04-10 05:23:53'),
(12,'verify_mail_template','<p>Hello,</p> <p>Thank you for signing up with <strong>{app_name}</strong>. To complete your registration and verify your email address, please use the following One-Time Password (OTP): <strong>{otp}</strong>. This OTP is valid for the next 10 minutes.</p> <p>If you did not initiate this request, please ignore this email.</p> <p>Best regards,</p> <p>The <strong>{app_name} </strong>Team</p>','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(13,'property_status_mail_template','<p>Hello <strong>{user_name}</strong>,</p> <p>We wanted to inform you that the status of your property, <strong>{property_name}</strong>, has been <strong>{status}</strong>.</p> <p><strong>{reject_reason}</strong></p> <p>If you have any questions or need further assistance, please feel free to reach out to our support team.</p> <p>Best regards,</p> <p>The <strong>{app_name}</strong>&nbsp;Team</p> <div>&nbsp;</div>','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(14,'project_status_mail_template','<p>Hello <strong>{user_name}</strong>,</p> <p>We wanted to inform you that the status of your project, <strong>{project_name}</strong>, in <strong>{app_name}</strong> has been <strong>{status}</strong>.</p> <p>If you have any questions or need further assistance, please feel free to reach out to our support team.</p> <p>Best regards,</p> <p>The <strong>{app_name}</strong>&nbsp;Team</p>','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(15,'property_ads_mail_template','<p>Dear<strong> <strong>{user_name}</strong>,</strong></p> <p>We are excited to inform you about the latest update regarding your property on <strong>{app_name}</strong>.</p> <p>Property Name: <strong>{property_name}</strong>,&nbsp;Advertisement Status: <strong>{advertisement_status}</strong></p> <p>If you have any questions or need further assistance, please feel free to reach out to our support team.</p> <p>Thank you for using <strong>{app_name}</strong>!<br /><br /></p> <p>Best regards,</p> <p><strong>{app_name}</strong>,</p> <p><strong>Support Team</strong></p>','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(16,'user_status_mail_template','<p>Hello <strong>{user_name}</strong>,</p> <p>We wanted to inform you that your account status on <strong>{app_name}</strong> has been updated to <strong>{status}</strong>.</p> <p>If you have any questions or need further assistance, please feel free to reach out to our support team.</p> <p>Best regards,</p> <p>The <strong>{app_name}</strong>&nbsp;Team</p>','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(17,'password_reset_mail_template','<p>Hello,</p> <p>We received a request to reset your password for your <strong>{app_name}</strong>&nbsp;account. To reset your password, please click on the following link:</p> <p><a title=\'{link}\' href=\'{link}\'><strong>{link}</strong></a></p> <p>If you did not request a password reset, please ignore this email or contact support for assistance.</p> <p>Best regards,</p> <p>The <strong>{app_name}</strong>&nbsp;Team</p>','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(18,'welcome_mail_template','<p>Hello <strong>{user_name}</strong>,</p> <p>Welcome to <strong>{app_name}</strong>! We\'re thrilled to have you on board. Thank you for registering with us.</p> <p>Get ready to explore and enjoy all the features we have to offer. If you have any questions or need assistance, feel free to reach out to our support team.</p> <p>Best regards,</p> <p>The <strong>{app_name}</strong>&nbsp;Team</p>','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(19,'agent_verification_status_mail_template','<p><strong>Dear <strong>{user_name}</strong>,</strong></p> <p>We hope this email finds you well.</p> <p>We are writing to inform you about the current status of your agent verification process with <strong>{app_name}</strong>.</p> <p><strong>Status:</strong> <strong>{status}</strong></p> <p>If you have any questions or need further assistance, please don\'t hesitate to reach out to our support team.</p> <p>Thank you for your patience and cooperation.</p> <p>Best regards,</p> <p><strong>{app_name}</strong>,<br /><strong>Support Team</strong></p>','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(20,'min_radius_range','0','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(21,'max_radius_range','100','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(22,'timezone','Asia/Kolkata','2026-04-01 12:38:22','2026-04-01 13:44:48'),
(23,'auto_approve_edited_listings','0','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(24,'homepage_location_alert_status','1','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(25,'appointment_status_mail_template','<p>Hello <strong>{user_name}</strong>,</p><p>The status of your appointment request on <strong>{app_name}</strong> has been updated.</p> <p><strong>Appointment Details:</strong>&nbsp;&nbsp;</p> <ul> <ul> <li><strong>Agent:</strong> {agent_name}&nbsp; &nbsp;</li> <li><strong>Customer:&nbsp;</strong>{customer_name}</li> <li><strong>Property:</strong> {property_name}&nbsp; &nbsp;</li> <li><strong>Status:</strong> {meeting_status}&nbsp; &nbsp;</li> <li><strong>Meeting Type:</strong> {meeting_type}&nbsp; &nbsp;</li> <li><strong>Date:</strong> {date}&nbsp; &nbsp;</li> <li><strong>Start Time:</strong> {start_time}&nbsp;&nbsp;</li> <li><strong>End Time:</strong> {end_time} <strong>{start_reason}</strong></li> <li><strong>Reason: </strong>{reason}<strong> (end_reason)</strong></li> </ul> </ul> <p>Thank you,<br />The <strong>{app_name}</strong> Team</p>','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(26,'new_appointment_request_mail_template','<p>Hello <strong>{agent_name}</strong>,</p><p>You have received a new appointment request on <strong>{app_name}</strong>.</p> <p><strong>Appointment Details:</strong>&nbsp;&nbsp;</p> <ul> <li><strong>User:</strong> {user_name}&nbsp; &nbsp;</li> <li><strong>Property:</strong> {property_name}&nbsp;&nbsp;</li> <li><strong>Status:</strong> {meeting_status}&nbsp; &nbsp;</li> <li><strong>Meeting Type:</strong> {meeting_type}&nbsp; &nbsp;</li> <li><strong>Date:</strong> {date}&nbsp; &nbsp;</li> <li><strong>Start Time:</strong> {start_time}&nbsp; &nbsp;</li> <li><strong>End Time:</strong> {end_time}</li> </ul> <p><strong>{start_notes} Notes: </strong>{notes}<strong> (end_notes)</strong></p> <p>Thank you,<br />The <strong>{app_name}</strong> Team</p>','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(27,'appointment_meeting_type_change_mail_template','<p data-start=\"141\" data-end=\"162\">Dear <strong>{user_name}</strong>,</p><p data-start=\"164\" data-end=\"323\">Your appointment related to <strong>{property_name}</strong>&nbsp;has been updated.<br data-start=\"231\" data-end=\"234\" />The meeting type has changed from <strong>{old_meeting_type}</strong> to <strong>{new_meeting_type}</strong>.</p> <p data-start=\"325\" data-end=\"351\"><strong data-start=\"325\" data-end=\"349\">Appointment Details:</strong></p> <ul data-start=\"352\" data-end=\"486\"> <li data-start=\"352\" data-end=\"377\"> <p data-start=\"354\" data-end=\"377\">Agent: <strong>{agent_name}</strong></p> </li> <li data-start=\"378\" data-end=\"409\"> <p data-start=\"380\" data-end=\"409\">Customer: <strong>{customer_name}</strong></p> </li> <li data-start=\"410\" data-end=\"428\"> <p data-start=\"412\" data-end=\"428\">Date: <strong>{date}</strong></p> </li> <li data-start=\"429\" data-end=\"459\"> <p data-start=\"431\" data-end=\"459\">Start Time: <strong>{start_time}</strong></p> </li> <li data-start=\"460\" data-end=\"486\"> <p data-start=\"462\" data-end=\"486\">End Time: <strong>{end_time}</strong></p> </li> </ul> <p data-start=\"488\" data-end=\"582\">Please make note of this change. If you have any questions, feel free to contact your agent.</p> <p data-start=\"584\" data-end=\"623\">Best regards,<br data-start=\"597\" data-end=\"600\" />The <strong>{app_name}</strong> Team</p>','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(28,'gemini_ai_search','0','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(29,'email_password_login','1','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(30,'dark_mode_logo','dark_mode_logo.png','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(31,'app_login_background','app_login_background.jpg','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(32,'gemini_ai_enabled','1','2026-04-01 12:38:22','2026-04-07 13:41:28'),
(33,'gemini_description_limit','10','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(34,'gemini_meta_limit','10','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(35,'gemini_description_limit_global','10','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(36,'gemini_meta_limit_global','10','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(37,'gemini_search_limit_user','50','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(38,'gemini_search_limit_global','50','2026-04-01 12:38:22','2026-04-01 12:38:22'),
(39,'company_name','Sukoon Infratech Innovation Group',NULL,'2026-04-01 13:44:48'),
(40,'currency_symbol','₹',NULL,'2026-04-01 13:44:48'),
(41,'ios_version','1.0.0',NULL,NULL),
(42,'default_language','en',NULL,NULL),
(43,'force_update','0',NULL,NULL),
(44,'android_version','1.0.0',NULL,NULL),
(45,'number_with_suffix','0',NULL,NULL),
(46,'maintenance_mode','0',NULL,NULL),
(47,'privacy_policy','<h2 data-path-to-node=\"0\">Privacy Policy | Sukoon Homes</h2>\r\n<p data-path-to-node=\"1\">At <strong data-path-to-node=\"1\" data-index-in-node=\"3\">Sukoon Homes</strong> (a part of <strong data-path-to-node=\"1\" data-index-in-node=\"27\">Sukoon Infratech Innovation Group</strong>), we value your trust as much as your peace of mind. This Privacy Policy outlines how we collect, use, and protect your information across our real estate platform.</p>\r\n<hr data-path-to-node=\"2\" />\r\n<h3 data-path-to-node=\"3\">1. Information We Collect</h3>\r\n<p data-path-to-node=\"4\">To provide a seamless property experience, we collect the following types of information:</p>\r\n<ul data-path-to-node=\"5\">\r\n<li>\r\n<p data-path-to-node=\"5,0,0\"><strong data-path-to-node=\"5,0,0\" data-index-in-node=\"0\">Personal Identity:</strong> Name, contact number, email address, and physical address.</p>\r\n</li>\r\n<li>\r\n<p data-path-to-node=\"5,1,0\"><strong data-path-to-node=\"5,1,0\" data-index-in-node=\"0\">Property Preferences:</strong> Your search history, budget, preferred locations, and interest in residential or commercial listings.</p>\r\n</li>\r\n<li>\r\n<p data-path-to-node=\"5,2,0\"><strong data-path-to-node=\"5,2,0\" data-index-in-node=\"0\">Verification Data:</strong> To ensure a secure ecosystem, we may collect government-issued IDs or documents required for KYC (Know Your Customer) during buy, sell, or rent transactions.</p>\r\n</li>\r\n<li>\r\n<p data-path-to-node=\"5,3,0\"><strong data-path-to-node=\"5,3,0\" data-index-in-node=\"0\">Technical Data:</strong> IP address, browser type, and usage patterns on our website or app.</p>\r\n</li>\r\n</ul>\r\n<h3 data-path-to-node=\"6\">2. How We Use Your Information</h3>\r\n<p data-path-to-node=\"7\">We use your data to make your property journey \"Sukoon\" (peaceful) and efficient:</p>\r\n<ul data-path-to-node=\"8\">\r\n<li>\r\n<p data-path-to-node=\"8,0,0\"><strong data-path-to-node=\"8,0,0\" data-index-in-node=\"0\">Service Delivery:</strong> To facilitate property listings, site visits, and transactions.</p>\r\n</li>\r\n<li>\r\n<p data-path-to-node=\"8,1,0\"><strong data-path-to-node=\"8,1,0\" data-index-in-node=\"0\">Verification:</strong> To protect our community from fraud by verifying the identity of buyers, sellers, and renters.</p>\r\n</li>\r\n<li>\r\n<p data-path-to-node=\"8,2,0\"><strong data-path-to-node=\"8,2,0\" data-index-in-node=\"0\">Personalization:</strong> To suggest properties that match your specific needs and lifestyle.</p>\r\n</li>\r\n<li>\r\n<p data-path-to-node=\"8,3,0\"><strong data-path-to-node=\"8,3,0\" data-index-in-node=\"0\">Support:</strong> To assist you with legal documentation, home loans, or maintenance services.</p>\r\n</li>\r\n<li>\r\n<p data-path-to-node=\"8,4,0\"><strong data-path-to-node=\"8,4,0\" data-index-in-node=\"0\">Communication:</strong> To send updates regarding your inquiries or new opportunities within the Sukoon ecosystem.</p>\r\n</li>\r\n</ul>\r\n<h3 data-path-to-node=\"9\">3. Data Sharing &amp; Third Parties</h3>\r\n<p data-path-to-node=\"10\">We do not sell your personal data. We only share information with:</p>\r\n<ul data-path-to-node=\"11\">\r\n<li>\r\n<p data-path-to-node=\"11,0,0\"><strong data-path-to-node=\"11,0,0\" data-index-in-node=\"0\">Authorized Partners:</strong> Trusted legal advisors, banks, or verification agencies necessary to complete your transaction.</p>\r\n</li>\r\n<li>\r\n<p data-path-to-node=\"11,1,0\"><strong data-path-to-node=\"11,1,0\" data-index-in-node=\"0\">Service Providers:</strong> Technology partners who help us maintain our platform&rsquo;s security and performance.</p>\r\n</li>\r\n<li>\r\n<p data-path-to-node=\"11,2,0\"><strong data-path-to-node=\"11,2,0\" data-index-in-node=\"0\">Legal Compliance:</strong> When required by law to protect our rights or comply with judicial proceedings.</p>\r\n</li>\r\n</ul>\r\n<h3 data-path-to-node=\"12\">4. Security Measures</h3>\r\n<p data-path-to-node=\"13\">Your data is stored with high-level encryption. As we build our \"Super App\" ecosystem, we implement rigorous security protocols to ensure that your personal and financial information remains confidential and protected against unauthorized access.</p>\r\n<h3 data-path-to-node=\"14\">5. Your Rights</h3>\r\n<p data-path-to-node=\"15\">You have the right to:</p>\r\n<ul data-path-to-node=\"16\">\r\n<li>\r\n<p data-path-to-node=\"16,0,0\"><strong data-path-to-node=\"16,0,0\" data-index-in-node=\"0\">Access &amp; Correct:</strong> Request a copy of the data we hold or ask for corrections.</p>\r\n</li>\r\n<li>\r\n<p data-path-to-node=\"16,1,0\"><strong data-path-to-node=\"16,1,0\" data-index-in-node=\"0\">Data Deletion:</strong> Request the removal of your personal information from our active databases.</p>\r\n</li>\r\n<li>\r\n<p data-path-to-node=\"16,2,0\"><strong data-path-to-node=\"16,2,0\" data-index-in-node=\"0\">Opt-Out:</strong> Unsubscribe from marketing communications at any time.</p>\r\n</li>\r\n</ul>\r\n<h3 data-path-to-node=\"17\">6. Updates to This Policy</h3>\r\n<p data-path-to-node=\"18\">As <strong data-path-to-node=\"18\" data-index-in-node=\"3\">Sukoon Infratech Innovation Group</strong> evolves and introduces new services like <em data-path-to-node=\"18\" data-index-in-node=\"78\">Sukoon Seva</em>, this policy may be updated. We encourage you to review this page periodically.</p>\r\n<hr data-path-to-node=\"19\" />\r\n<h3 data-path-to-node=\"20\">Contact Us</h3>\r\n<p data-path-to-node=\"21\">If you have any questions regarding your privacy or how we handle your data, please reach out to us:</p>\r\n<p data-path-to-node=\"22\"><strong data-path-to-node=\"22\" data-index-in-node=\"0\">Sukoon Infratech Innovation Group</strong></p>\r\n<p data-path-to-node=\"22\"><em data-path-to-node=\"22\" data-index-in-node=\"34\">Location: Barmer</em></p>\r\n<p data-path-to-node=\"22\">&nbsp;</p>',NULL,'2026-04-02 10:07:28'),
(48,'terms_conditions','<h2 data-path-to-node=\"0\">Terms and Conditions | Sukoon Homes</h2>\r\n<p data-path-to-node=\"1\">Welcome to <strong data-path-to-node=\"1\" data-index-in-node=\"11\">Sukoon Homes</strong>. These Terms and Conditions govern your use of the Sukoon Homes platform and services provided by <strong data-path-to-node=\"1\" data-index-in-node=\"122\">Sukoon Infratech Innovation Group</strong>. By accessing our website or using our services, you agree to comply with and be bound by the following terms.</p>\r\n<hr data-path-to-node=\"2\" />\r\n<h3 data-path-to-node=\"3\">1. Services Provided</h3>\r\n<p data-path-to-node=\"4\">Sukoon Homes&nbsp;acts as a specialized real estate platform facilitating:</p>\r\n<ul data-path-to-node=\"5\">\r\n<li>\r\n<p data-path-to-node=\"5,0,0\">The buying, selling, and renting of residential and commercial properties.</p>\r\n</li>\r\n<li>\r\n<p data-path-to-node=\"5,1,0\">Property verification and documentation assistance.</p>\r\n</li>\r\n<li>\r\n<p data-path-to-node=\"5,2,0\">An ecosystem of home-related services aimed at simplifying the property ownership journey.</p>\r\n</li>\r\n</ul>\r\n<h3 data-path-to-node=\"6\">2. User Eligibility &amp; Registration</h3>\r\n<ul data-path-to-node=\"7\">\r\n<li>\r\n<p data-path-to-node=\"7,0,0\"><strong data-path-to-node=\"7,0,0\" data-index-in-node=\"0\">Accuracy:</strong> You agree to provide true, current, and complete information during the registration and verification process.</p>\r\n</li>\r\n<li>\r\n<p data-path-to-node=\"7,1,0\"><strong data-path-to-node=\"7,1,0\" data-index-in-node=\"0\">Account Responsibility:</strong> You are responsible for maintaining the confidentiality of your account credentials.</p>\r\n</li>\r\n<li>\r\n<p data-path-to-node=\"7,2,0\"><strong data-path-to-node=\"7,2,0\" data-index-in-node=\"0\">Legal Age:</strong> By using this platform, you represent that you are at least 18 years of age and legally capable of entering into binding contracts.</p>\r\n</li>\r\n</ul>\r\n<h3 data-path-to-node=\"8\">3. Verification &amp; Trust</h3>\r\n<p data-path-to-node=\"9\">To ensure a secure environment&mdash;true to the meaning of \"Sukoon\"&mdash;we implement a strict verification process:</p>\r\n<ul data-path-to-node=\"10\">\r\n<li>\r\n<p data-path-to-node=\"10,0,0\"><strong data-path-to-node=\"10,0,0\" data-index-in-node=\"0\">User Verification:</strong> Users (Buyers, Sellers, and Renters) may be required to submit government-approved identification.</p>\r\n</li>\r\n<li>\r\n<p data-path-to-node=\"10,1,0\"><strong data-path-to-node=\"10,1,0\" data-index-in-node=\"0\">Property Verification:</strong> While we strive to verify listings, users are encouraged to conduct their own due diligence before making financial commitments.</p>\r\n</li>\r\n<li>\r\n<p data-path-to-node=\"10,2,0\"><strong data-path-to-node=\"10,2,0\" data-index-in-node=\"0\">Right to Refuse:</strong> Sukoon Homes reserves the right to suspend accounts or remove listings that provide false information or engage in suspicious activity.</p>\r\n</li>\r\n</ul>\r\n<h3 data-path-to-node=\"11\">4. Listings &amp; Transactions</h3>\r\n<ul data-path-to-node=\"12\">\r\n<li>\r\n<p data-path-to-node=\"12,0,0\"><strong data-path-to-node=\"12,0,0\" data-index-in-node=\"0\">Accuracy of Content:</strong> Sellers and landlords are responsible for the accuracy of the property details, images, and pricing provided.</p>\r\n</li>\r\n<li>\r\n<p data-path-to-node=\"12,1,0\"><strong data-path-to-node=\"12,1,0\" data-index-in-node=\"0\">Third-Party Transactions:</strong> Sukoon Homes facilitates connections. While we provide support, the final sale or lease agreement is a legal contract between the buyer/tenant and the seller/landlord.</p>\r\n</li>\r\n<li>\r\n<p data-path-to-node=\"12,2,0\"><strong data-path-to-node=\"12,2,0\" data-index-in-node=\"0\">Professionalism:</strong> All users must interact with transparency and integrity. Misrepresentation of property status is strictly prohibited.</p>\r\n</li>\r\n</ul>\r\n<h3 data-path-to-node=\"13\">5. Intellectual Property</h3>\r\n<p data-path-to-node=\"14\">All content on this platform&mdash;including logos, trademarks (Sukoon Homes, Sukoon Infratech Innovation Group), text, and UI design&mdash;is the exclusive property of the group. Unauthorized use, reproduction, or distribution is prohibited.</p>\r\n<h3 data-path-to-node=\"15\">6. Limitation of Liability</h3>\r\n<p data-path-to-node=\"16\">Sukoon Homes acts as a facilitator to make property work \"easy.\" We are not liable for:</p>\r\n<ul data-path-to-node=\"17\">\r\n<li>\r\n<p data-path-to-node=\"17,0,0\">Disputes arising between parties after a transaction is initiated.</p>\r\n</li>\r\n<li>\r\n<p data-path-to-node=\"17,1,0\">Technical interruptions or temporary downtime of the platform.</p>\r\n</li>\r\n<li>\r\n<p data-path-to-node=\"17,2,0\">Indirect or consequential losses resulting from property market fluctuations.</p>\r\n</li>\r\n</ul>\r\n<h3 data-path-to-node=\"18\">7. Fees and Payments</h3>\r\n<ul data-path-to-node=\"19\">\r\n<li>\r\n<p data-path-to-node=\"19,0,0\">Service fees, brokerage, or subscription charges for premium listings will be clearly communicated.</p>\r\n</li>\r\n<li>\r\n<p data-path-to-node=\"19,1,0\">All payments made through the platform are subject to our refund policy and the specific terms of the service being utilized.</p>\r\n</li>\r\n</ul>\r\n<h3 data-path-to-node=\"20\">8. Governing Law</h3>\r\n<p data-path-to-node=\"21\">These terms are governed by the laws of India. Any disputes arising from the use of our services shall be subject to the exclusive jurisdiction of the courts in <strong data-path-to-node=\"21\" data-index-in-node=\"161\">Barmer Rajasthan</strong>.</p>\r\n<hr data-path-to-node=\"22\" />\r\n<h3 data-path-to-node=\"23\">9. Modifications</h3>\r\n<p data-path-to-node=\"24\">We reserve the right to update these terms as our \"Super App\" ecosystem expands. Continued use of the platform after changes are posted constitutes acceptance of the new terms.</p>\r\n<p data-path-to-node=\"25\"><strong data-path-to-node=\"25\" data-index-in-node=\"0\">Contact Us:</strong> If you have questions regarding these Terms, please contact the <strong data-path-to-node=\"25\" data-index-in-node=\"76\">Sukoon Infratech Innovation Group</strong> legal department at sitigroup.co@gmail.com</p>',NULL,'2026-04-02 10:08:36'),
(49,'company_tel1','+91 85948 82948',NULL,'2026-04-01 13:44:48'),
(50,'company_tel2',NULL,NULL,'2026-04-10 18:33:35'),
(51,'razorpay_gateway','1',NULL,'2026-04-17 08:25:22'),
(52,'paystack_gateway','0',NULL,NULL),
(53,'paypal_gateway','0',NULL,NULL),
(54,'system_version','1.4.0',NULL,'2026-05-14 06:48:10'),
(55,'company_logo','logo.png',NULL,'2026-04-04 06:58:49'),
(56,'web_logo','Gemini_Generated_Image_dratoddratoddrat (2).png',NULL,'2026-04-09 11:33:46'),
(57,'favicon_icon','favicon.png',NULL,'2026-04-04 06:46:49'),
(58,'web_favicon','Group 15.png',NULL,'2026-04-07 04:51:46'),
(59,'web_footer_logo','Gemini_Generated_Image_dratoddratoddrat (2).png',NULL,'2026-04-09 11:33:46'),
(60,'web_placeholder_logo','Group 15.png',NULL,'2026-04-07 04:51:33'),
(61,'app_home_screen','homeLogo.png',NULL,NULL),
(62,'placeholder_logo','placeholder.png',NULL,NULL),
(63,'system_color','#000000',NULL,'2026-04-01 13:44:48'),
(64,'facebook_id','https://www.facebook.com/sukoon.groups',NULL,'2026-04-02 10:02:33'),
(65,'instagram_id','https://www.instagram.com/sukoon.group',NULL,'2026-04-02 10:02:33'),
(66,'twitter_id','https://twitter.com/sukoon.group',NULL,'2026-04-02 10:02:33'),
(67,'youtube_id','https://www.youtube.com/sukoon.group',NULL,'2026-04-02 10:02:33'),
(68,'iframe_link','https://www.google.com/maps?q=25.7505779,71.3929531&hl=en&z=15&output=embed',NULL,'2026-04-17 13:33:27'),
(69,'latitude','25.7506',NULL,'2026-05-14 01:23:18'),
(70,'longitude','71.3930',NULL,'2026-05-14 01:23:18'),
(71,'company_address','Barmer Rajasthan',NULL,'2026-04-01 13:44:48'),
(72,'company_email','sitigroup.co@gmail.com',NULL,'2026-04-01 13:44:48'),
(73,'playstore_id',NULL,NULL,'2026-04-15 03:14:40'),
(74,'appstore_id',NULL,NULL,'2026-04-15 03:14:40'),
(75,'currency_code','INR','2026-04-01 13:44:48','2026-04-01 13:44:48'),
(76,'unsplash_api_key',NULL,'2026-04-01 13:44:48','2026-04-01 13:44:48'),
(77,'rgb_color','rgb(0, 0, 0,0.15)','2026-04-01 13:44:48','2026-04-01 13:44:48'),
(78,'web_url','https://homes.sukoon.group/','2026-04-01 13:44:48','2026-04-17 09:39:19'),
(79,'notify_user_for_subscription_expiry','1','2026-04-01 13:44:48','2026-04-10 18:33:35'),
(80,'days_before_subscription_expiry',NULL,'2026-04-01 13:44:48','2026-04-01 13:44:48'),
(81,'show_direct_video_upload','0','2026-04-01 13:44:48','2026-04-01 13:44:48'),
(82,'show_premium_toggle','0','2026-04-01 13:44:48','2026-04-01 13:44:48'),
(83,'map_api_key','AIzaSyBWGE7fsVD4ohudAQ6nf6aJjN3AhVhNjKo','2026-04-01 13:44:48','2026-04-04 05:42:12'),
(84,'place_api_key','AIzaSyBOFzTVDTr2HFiKLf5wz3FUPeLbTKzz8Zk','2026-04-01 13:44:48','2026-04-07 16:07:27'),
(85,'twilio_account_sid',NULL,'2026-04-01 13:44:48','2026-04-01 13:44:48'),
(86,'twilio_auth_token',NULL,'2026-04-01 13:44:48','2026-04-01 13:44:48'),
(87,'twilio_my_phone_number',NULL,'2026-04-01 13:44:48','2026-04-01 13:44:48'),
(88,'schema_for_deeplink','homes','2026-04-01 13:44:48','2026-04-09 12:04:18'),
(89,'login_image','Login_BG.jpg','2026-04-01 13:48:22','2026-04-01 13:48:22'),
(90,'web_maintenance_mode','0','2026-04-02 10:02:33','2026-04-02 10:02:33'),
(91,'allow_cookies','0','2026-04-02 10:02:33','2026-04-02 10:02:33'),
(92,'btnAdd1','btnAdd','2026-04-02 10:02:33','2026-04-02 10:02:33'),
(93,'about_us','<h2 data-path-to-node=\"0\">Elevate Your Living: The Sukoon Experience</h2>\r\n<p data-path-to-node=\"1\"><strong data-path-to-node=\"1\" data-index-in-node=\"0\">Sukoon Homes</strong> isn&rsquo;t just a real estate brand; it&rsquo;s a movement toward <strong data-path-to-node=\"1\" data-index-in-node=\"68\">intentional living</strong>. We specialize in creating environments where luxury meets emotional well-being. Our mission is to transform the \"four walls\" of a house into a sanctuary of stillness.</p>\r\n<hr data-path-to-node=\"2\" />\r\n<h3 data-path-to-node=\"3\">The Sukoon Philosophy</h3>\r\n<p data-path-to-node=\"4\">The word <em data-path-to-node=\"4\" data-index-in-node=\"9\">Sukoon</em> represents the quiet moment after a long day&mdash;the breath of relief when you step through your front door. We achieve this through a blend of <strong data-path-to-node=\"4\" data-index-in-node=\"156\">Biophilic Design</strong>, <strong data-path-to-node=\"4\" data-index-in-node=\"174\">Smart Integration</strong>, and <strong data-path-to-node=\"4\" data-index-in-node=\"197\">Atmospheric Architecture</strong>.</p>\r\n<table data-path-to-node=\"5\">\r\n<thead>\r\n<tr>\r\n<td><strong>Feature</strong></td>\r\n<td><strong>The Sukoon Advantage</strong></td>\r\n<td><strong>Your Benefit</strong></td>\r\n</tr>\r\n</thead>\r\n<tbody>\r\n<tr>\r\n<td><span data-path-to-node=\"5,1,0,0\"><strong data-path-to-node=\"5,1,0,0\" data-index-in-node=\"0\">Aesthetics</strong></span></td>\r\n<td><span data-path-to-node=\"5,1,1,0\">Minimalism infused with organic textures.</span></td>\r\n<td><span data-path-to-node=\"5,1,2,0\">Reduced visual clutter and mental clarity.</span></td>\r\n</tr>\r\n<tr>\r\n<td><span data-path-to-node=\"5,2,0,0\"><strong data-path-to-node=\"5,2,0,0\" data-index-in-node=\"0\">Environment</strong></span></td>\r\n<td><span data-path-to-node=\"5,2,1,0\">Maximized natural light and airflow.</span></td>\r\n<td><span data-path-to-node=\"5,2,2,0\">Improved mood and sustainable energy use.</span></td>\r\n</tr>\r\n<tr>\r\n<td><span data-path-to-node=\"5,3,0,0\"><strong data-path-to-node=\"5,3,0,0\" data-index-in-node=\"0\">Technology</strong></span></td>\r\n<td><span data-path-to-node=\"5,3,1,0\">Discrete, \"human-first\" smart home tech.</span></td>\r\n<td><span data-path-to-node=\"5,3,2,0\">Effortless control over your surroundings.</span></td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<hr data-path-to-node=\"6\" />\r\n<h3 data-path-to-node=\"7\">Our Core Commitments</h3>\r\n<h3 data-path-to-node=\"8\"><em data-path-to-node=\"8\" data-index-in-node=\"0\">01. Architecture with Soul</em></h3>\r\n<p data-path-to-node=\"9\">We move away from the \"cookie-cutter\" approach. Every Sukoon project is a study in balance&mdash;balancing modern innovation with the timeless need for privacy and comfort.</p>\r\n<h3 data-path-to-node=\"10\"><em data-path-to-node=\"10\" data-index-in-node=\"0\">02. Uncompromising Quality</em></h3>\r\n<p data-path-to-node=\"11\">From the grade of the timber to the precision of the masonry, we partner with world-class artisans who share our obsession with detail. A Sukoon home is built to be a legacy, not just a residence.</p>\r\n<h3 data-path-to-node=\"12\"><em data-path-to-node=\"12\" data-index-in-node=\"0\">03. Client-Centric Journey</em></h3>\r\n<p data-path-to-node=\"13\">We recognize that the path to your dream home should be as peaceful as the destination. Our team provides white-glove service, ensuring transparency, expert guidance, and a seamless transition into your new life.</p>\r\n<p data-path-to-node=\"13\">&nbsp;</p>\r\n<blockquote data-path-to-node=\"15\">\r\n<h3 data-path-to-node=\"15,0\">\"A home is the physical manifestation of your inner peace.\"</h3>\r\n<p data-path-to-node=\"15,1\">At Sukoon Homes, we build for the person you want to become.</p>\r\n</blockquote>','2026-04-02 10:05:21','2026-04-02 10:05:21'),
(94,'verification_required_for_user','1','2026-04-02 10:14:01','2026-04-20 12:00:24'),
(95,'city_image_style','style_1','2026-04-02 18:29:22','2026-05-17 17:22:59'),
(96,'apiKey','AIzaSyBWGE7fsVD4ohudAQ6nf6aJjN3AhVhNjKo','2026-04-04 05:43:36','2026-04-10 04:56:03'),
(97,'authDomain','sukoon-groups.firebaseapp.com','2026-04-04 05:43:36','2026-04-10 04:56:03'),
(98,'projectId','sukoon-groups','2026-04-04 05:43:36','2026-04-10 04:56:03'),
(99,'storageBucket','sukoon-groups.firebasestorage.app','2026-04-04 05:43:36','2026-04-10 04:56:03'),
(100,'messagingSenderId','168614703336','2026-04-04 05:43:36','2026-04-10 04:56:03'),
(101,'appId','1:168614703336:web:78a6d8630e0388ccd7d95d','2026-04-04 05:43:36','2026-04-10 04:56:03'),
(102,'measurementId','G-M3S65B3ZDL','2026-04-04 05:43:36','2026-04-10 04:56:03'),
(103,'mail_mailer','smtp',NULL,NULL),
(104,'mail_host','smtp.gmail.com',NULL,NULL),
(105,'mail_port','465',NULL,NULL),
(106,'mail_username','sitigroup.co@gmail.com',NULL,NULL),
(107,'mail_password','xlho gwwx gxyj mqcw',NULL,NULL),
(108,'mail_encryption','ssl',NULL,NULL),
(109,'mail_send_from','sitigroup.co@gmail.com',NULL,NULL),
(110,'firebase_project_id','sukoon-groups','2026-04-06 02:11:58','2026-04-06 02:11:58'),
(111,'firebase_service_json_file','firebase-service.json','2026-04-06 02:11:58','2026-04-06 02:11:58'),
(112,'gemini_api_key','AIzaSyDISfwYP-n2FawAaAYUnCpoPW_htZoDMB0','2026-04-07 13:41:28','2026-04-07 13:41:28'),
(113,'light_tertiary','#212121','2026-04-09 12:15:31','2026-04-09 12:16:43'),
(114,'light_secondary','#ffffff','2026-04-09 12:15:31','2026-04-09 12:15:31'),
(115,'light_primary','#fafafa','2026-04-09 12:15:31','2026-04-09 12:15:31'),
(116,'dark_tertiary','#ffffff','2026-04-09 12:15:31','2026-04-09 12:16:43'),
(117,'dark_secondary','#1c1c1c','2026-04-09 12:15:31','2026-04-09 12:15:31'),
(118,'dark_primary','#0c0c0c','2026-04-09 12:15:31','2026-04-09 12:15:31'),
(119,'show_admob_ads','0','2026-04-09 12:15:31','2026-04-09 12:15:31'),
(120,'android_banner_ad_id',NULL,'2026-04-09 12:15:31','2026-04-09 12:15:31'),
(121,'ios_banner_ad_id',NULL,'2026-04-09 12:15:31','2026-04-09 12:15:31'),
(122,'android_interstitial_ad_id',NULL,'2026-04-09 12:15:31','2026-04-09 12:15:31'),
(123,'ios_interstitial_ad_id',NULL,'2026-04-09 12:15:31','2026-04-09 12:15:31'),
(124,'android_native_ad_id',NULL,'2026-04-09 12:15:31','2026-04-09 12:15:31'),
(125,'ios_native_ad_id',NULL,'2026-04-09 12:15:31','2026-04-09 12:15:31'),
(126,'paypal_client_id',NULL,'2026-04-10 03:11:27','2026-04-10 03:11:27'),
(127,'paypal_client_secret',NULL,'2026-04-10 03:11:27','2026-04-10 03:11:27'),
(128,'paypal_webhook_url','https://admin-homes.sukoon.group/webhook/paypal','2026-04-10 03:11:27','2026-04-10 03:11:27'),
(129,'paypal_webhook_id',NULL,'2026-04-10 03:11:27','2026-04-10 03:11:27'),
(130,'paypal_currency','AUD','2026-04-10 03:11:27','2026-04-10 03:11:27'),
(131,'sandbox_mode','0','2026-04-10 03:11:27','2026-04-10 03:11:27'),
(132,'razor_key','rzp_live_SgUdGZmDabcBRz','2026-04-10 03:11:27','2026-04-22 09:46:03'),
(133,'razorpay_webhook_url','https://admin-homes.sukoon.group/webhook/razorpay','2026-04-10 03:11:27','2026-04-10 03:11:27'),
(134,'razor_secret','8SgQoPVP8JETa053mek7G0tz','2026-04-10 03:11:27','2026-04-22 09:46:03'),
(135,'op','on','2026-04-10 03:11:27','2026-04-10 03:11:27'),
(136,'razor_webhook_secret','J_xAYdH9DpBZusp','2026-04-10 03:11:27','2026-04-22 09:46:03'),
(137,'paystack_secret_key',NULL,'2026-04-10 03:11:27','2026-04-10 03:11:27'),
(138,'paystack_webhook_url','https://admin-homes.sukoon.group/webhook/paystack','2026-04-10 03:11:27','2026-04-10 03:11:27'),
(139,'paystack_currency','GHS','2026-04-10 03:11:27','2026-04-10 03:11:27'),
(140,'paystack_public_key',NULL,'2026-04-10 03:11:27','2026-04-10 03:11:27'),
(141,'stripe_publishable_key',NULL,'2026-04-10 03:11:27','2026-04-10 03:11:27'),
(142,'stripe_webhook_url','https://admin-homes.sukoon.group/webhook/stripe','2026-04-10 03:11:27','2026-04-10 03:11:27'),
(143,'stripe_currency','USD','2026-04-10 03:11:27','2026-04-10 03:11:27'),
(144,'stripe_gateway','0','2026-04-10 03:11:27','2026-04-10 03:11:27'),
(145,'stripe_secret_key',NULL,'2026-04-10 03:11:27','2026-04-10 03:11:27'),
(146,'stripe_webhook_secret_key',NULL,'2026-04-10 03:11:27','2026-04-10 03:11:27'),
(147,'flutterwave_public_key',NULL,'2026-04-10 03:11:27','2026-04-10 03:11:27'),
(148,'flutterwave_secret_key',NULL,'2026-04-10 03:11:27','2026-04-10 03:11:27'),
(149,'flutterwave_encryption_key',NULL,'2026-04-10 03:11:27','2026-04-10 03:11:27'),
(150,'flutterwave_webhook_url','https://admin-homes.sukoon.group/webhook/flutterwave','2026-04-10 03:11:27','2026-04-10 03:11:27'),
(151,'flutterwave_currency','GBP','2026-04-10 03:11:27','2026-04-10 03:11:27'),
(152,'flutterwave_status','0','2026-04-10 03:11:27','2026-04-10 03:11:27'),
(153,'cashfree_app_id','TEST11048012f7a5657af3df9b7e314f21084011','2026-04-10 03:11:27','2026-04-16 05:19:19'),
(154,'cashfree_secret_key','cfsk_ma_test_6ff3eccf01def6ac44a572edaf4a483b_b5ede147','2026-04-10 03:11:28','2026-04-16 05:19:19'),
(155,'cashfree_currency','INR','2026-04-10 03:11:28','2026-04-10 03:11:28'),
(156,'cashfree_gateway','1','2026-04-10 03:11:28','2026-04-15 02:59:14'),
(157,'cashfree_sandbox_mode','1','2026-04-10 03:11:28','2026-04-25 06:30:26'),
(158,'phonepe_client_id',NULL,'2026-04-10 03:11:28','2026-04-10 03:11:28'),
(159,'phonepe_client_secret',NULL,'2026-04-10 03:11:28','2026-04-10 03:11:28'),
(160,'phonepe_client_version',NULL,'2026-04-10 03:11:28','2026-04-10 03:11:28'),
(161,'phonepe_merchant_id',NULL,'2026-04-10 03:11:28','2026-04-10 03:11:28'),
(162,'phonepe_webhook_url','https://admin-homes.sukoon.group/webhook/phonepe','2026-04-10 03:11:28','2026-04-10 03:11:28'),
(163,'phonepe_webhook_username',NULL,'2026-04-10 03:11:28','2026-04-10 03:11:28'),
(164,'phonepe_webhook_password',NULL,'2026-04-10 03:11:28','2026-04-10 03:11:28'),
(165,'phonepe_gateway','0','2026-04-10 03:11:28','2026-04-10 03:11:28'),
(166,'phonepe_sandbox_mode','0','2026-04-10 03:11:28','2026-04-10 03:11:28'),
(167,'midtrans_server_key',NULL,'2026-04-10 03:11:28','2026-04-10 03:11:28'),
(168,'midtrans_client_key',NULL,'2026-04-10 03:11:28','2026-04-10 03:11:28'),
(169,'midtrans_merchant_id',NULL,'2026-04-10 03:11:28','2026-04-10 03:11:28'),
(170,'midtrans_webhook_url','https://admin-homes.sukoon.group/webhook/midtrans','2026-04-10 03:11:28','2026-04-10 03:11:28'),
(171,'midtrans_gateway','0','2026-04-10 03:11:28','2026-04-10 03:11:28'),
(172,'midtrans_sandbox_mode','0','2026-04-10 03:11:28','2026-04-10 03:11:28'),
(173,'bank_transfer_status','0','2026-04-10 03:11:28','2026-04-10 03:11:28'),
(174,'property_detail_layout','official','2026-05-18 05:23:21','2026-05-20 15:19:45'),
(175,'custom_property_show_agent_card','1','2026-05-20 03:32:22','2026-05-20 03:45:42'),
(176,'custom_property_show_share_save','1','2026-05-20 03:32:22','2026-05-20 03:45:42'),
(177,'custom_property_show_schedule_visit','1','2026-05-20 03:32:22','2026-05-20 03:45:42'),
(178,'custom_property_show_nearby','1','2026-05-20 03:32:22','2026-05-20 03:45:42'),
(179,'custom_property_show_similar_properties','1','2026-05-20 04:12:41','2026-05-20 04:12:41'),
(180,'custom_property_show_highlights','1','2026-05-20 04:12:41','2026-05-20 04:12:41'),
(181,'custom_property_show_amenities','1','2026-05-20 04:12:41','2026-05-20 04:12:41'),
(182,'custom_property_enable_call','1','2026-05-20 04:12:41','2026-05-20 04:12:41'),
(183,'custom_property_enable_whatsapp','1','2026-05-20 04:12:41','2026-05-20 04:12:41'),
(184,'custom_property_enable_enquiry','1','2026-05-20 04:12:41','2026-05-20 04:12:41'),
(185,'custom_property_enable_gallery_lightbox','1','2026-05-20 04:12:41','2026-05-20 04:12:41'),
(186,'custom_property_enable_thumbnail_strip','1','2026-05-20 04:12:41','2026-05-20 04:12:41'),
(187,'custom_property_enable_sticky_mobile_actions','1','2026-05-20 04:12:41','2026-05-20 04:12:41'),
(188,'nearby_places_enabled','1',NULL,'2026-05-20 08:50:50'),
(189,'nearby_places_default_radius_m','2000',NULL,NULL),
(190,'nearby_places_default_max_results','5',NULL,NULL),
(191,'nearby_places_cache_ttl_hours','168',NULL,NULL),
(192,'nearby_places_travel_time_enabled','0',NULL,NULL),
(193,'nearby_places_travel_cache_ttl_hours','168',NULL,NULL),
(194,'nearby_places_public_directions_enabled','0','2026-05-20 21:52:49','2026-05-20 21:52:49');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sliders`
--

DROP TABLE IF EXISTS `sliders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sliders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('1','2','3','4') NOT NULL COMMENT '1 - only image, 2 - category, 3 - property, 4 - link',
  `image` text DEFAULT NULL COMMENT 'app_image',
  `web_image` text DEFAULT NULL,
  `link` text DEFAULT NULL,
  `sequence` tinyint(4) NOT NULL DEFAULT 0,
  `category_id` bigint(20) DEFAULT 0,
  `propertys_id` bigint(20) DEFAULT 0,
  `show_property_details` tinyint(1) NOT NULL DEFAULT 0,
  `default_data` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sliders`
--

LOCK TABLES `sliders` WRITE;
/*!40000 ALTER TABLE `sliders` DISABLE KEYS */;
INSERT INTO `sliders` VALUES
(1,'1',NULL,NULL,NULL,0,0,0,0,1,'2026-04-01 12:38:22','2026-04-01 12:38:22');
/*!40000 ALTER TABLE `sliders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sukoon_areas`
--

DROP TABLE IF EXISTS `sukoon_areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sukoon_areas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `state_id` bigint(20) unsigned DEFAULT NULL,
  `city_id` bigint(20) unsigned DEFAULT NULL,
  `city` varchar(191) DEFAULT NULL,
  `state` varchar(191) DEFAULT NULL,
  `country` varchar(191) DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `center_lat` decimal(10,7) DEFAULT NULL,
  `center_lng` decimal(10,7) DEFAULT NULL,
  `radius_meters` int(10) unsigned DEFAULT NULL,
  `polygon_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`polygon_json`)),
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `seo_title` varchar(191) DEFAULT NULL,
  `seo_description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sukoon_areas_city_id_slug_unique` (`city_id`,`slug`),
  KEY `sukoon_areas_state_id_foreign` (`state_id`),
  KEY `sukoon_areas_slug_index` (`slug`),
  CONSTRAINT `sukoon_areas_city_id_foreign` FOREIGN KEY (`city_id`) REFERENCES `sukoon_cities` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sukoon_areas_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `sukoon_states` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sukoon_areas`
--

LOCK TABLES `sukoon_areas` WRITE;
/*!40000 ALTER TABLE `sukoon_areas` DISABLE KEYS */;
INSERT INTO `sukoon_areas` VALUES
(1,1,1,'Barmer','Rajasthan','India','Krishna Nagar','krishna-nagar',NULL,NULL,NULL,NULL,0,1,NULL,NULL,'2026-05-14 08:32:52','2026-05-14 20:15:29'),
(2,1,1,'Barmer','Rajasthan','India','Rai Colony Road','rai-colony-road',NULL,NULL,NULL,NULL,0,1,NULL,NULL,'2026-05-14 08:36:27','2026-05-14 20:15:29'),
(3,1,1,'Barmer','Rajasthan','India','Mahaveer Nagar','mahaveer-nagar',NULL,NULL,NULL,NULL,0,1,NULL,NULL,'2026-05-14 18:22:52','2026-05-14 20:15:29');
/*!40000 ALTER TABLE `sukoon_areas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sukoon_cities`
--

DROP TABLE IF EXISTS `sukoon_cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sukoon_cities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `state_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `state` varchar(191) DEFAULT NULL,
  `country` varchar(191) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sukoon_cities_state_id_slug_unique` (`state_id`,`slug`),
  KEY `sukoon_cities_slug_index` (`slug`),
  CONSTRAINT `sukoon_cities_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `sukoon_states` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sukoon_cities`
--

LOCK TABLES `sukoon_cities` WRITE;
/*!40000 ALTER TABLE `sukoon_cities` DISABLE KEYS */;
INSERT INTO `sukoon_cities` VALUES
(1,1,'Barmer','barmer','Rajasthan','India',0,1,'2026-05-14 20:15:29','2026-05-14 20:15:29');
/*!40000 ALTER TABLE `sukoon_cities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sukoon_project_locations`
--

DROP TABLE IF EXISTS `sukoon_project_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sukoon_project_locations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint(20) unsigned NOT NULL,
  `state_id` bigint(20) unsigned DEFAULT NULL,
  `city_id` bigint(20) unsigned DEFAULT NULL,
  `area_id` bigint(20) unsigned DEFAULT NULL,
  `sub_area_id` bigint(20) unsigned DEFAULT NULL,
  `state` varchar(191) DEFAULT NULL,
  `city` varchar(191) DEFAULT NULL,
  `area_name` varchar(191) DEFAULT NULL,
  `sub_area_name` varchar(191) DEFAULT NULL,
  `detected_area_name` varchar(191) DEFAULT NULL,
  `detected_sub_area_name` varchar(191) DEFAULT NULL,
  `full_address` text DEFAULT NULL,
  `display_address` varchar(191) DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `location_source` varchar(191) NOT NULL DEFAULT 'manual',
  `source` varchar(191) DEFAULT NULL,
  `is_verified` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sukoon_project_locations_project_id_unique` (`project_id`),
  KEY `sukoon_project_locations_state_id_foreign` (`state_id`),
  KEY `sukoon_project_locations_city_id_foreign` (`city_id`),
  KEY `sukoon_project_locations_area_id_foreign` (`area_id`),
  KEY `sukoon_project_locations_sub_area_id_foreign` (`sub_area_id`),
  CONSTRAINT `sukoon_project_locations_area_id_foreign` FOREIGN KEY (`area_id`) REFERENCES `sukoon_areas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sukoon_project_locations_city_id_foreign` FOREIGN KEY (`city_id`) REFERENCES `sukoon_cities` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sukoon_project_locations_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `sukoon_states` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sukoon_project_locations_sub_area_id_foreign` FOREIGN KEY (`sub_area_id`) REFERENCES `sukoon_sub_areas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sukoon_project_locations`
--

LOCK TABLES `sukoon_project_locations` WRITE;
/*!40000 ALTER TABLE `sukoon_project_locations` DISABLE KEYS */;
/*!40000 ALTER TABLE `sukoon_project_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sukoon_property_locations`
--

DROP TABLE IF EXISTS `sukoon_property_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sukoon_property_locations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `property_id` bigint(20) unsigned NOT NULL,
  `state_id` bigint(20) unsigned DEFAULT NULL,
  `city_id` bigint(20) unsigned DEFAULT NULL,
  `area_id` bigint(20) unsigned DEFAULT NULL,
  `sub_area_id` bigint(20) unsigned DEFAULT NULL,
  `state` varchar(191) DEFAULT NULL,
  `city` varchar(191) DEFAULT NULL,
  `area_name` varchar(191) DEFAULT NULL,
  `sub_area_name` varchar(191) DEFAULT NULL,
  `detected_area_name` varchar(191) DEFAULT NULL,
  `detected_sub_area_name` varchar(191) DEFAULT NULL,
  `full_address` text DEFAULT NULL,
  `display_address` varchar(191) DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `location_source` varchar(191) NOT NULL DEFAULT 'manual',
  `source` varchar(191) DEFAULT NULL,
  `is_verified` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sukoon_property_locations_property_id_unique` (`property_id`),
  KEY `sukoon_property_locations_state_id_foreign` (`state_id`),
  KEY `sukoon_property_locations_city_id_foreign` (`city_id`),
  KEY `sukoon_property_locations_area_id_foreign` (`area_id`),
  KEY `sukoon_property_locations_sub_area_id_foreign` (`sub_area_id`),
  CONSTRAINT `sukoon_property_locations_area_id_foreign` FOREIGN KEY (`area_id`) REFERENCES `sukoon_areas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sukoon_property_locations_city_id_foreign` FOREIGN KEY (`city_id`) REFERENCES `sukoon_cities` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sukoon_property_locations_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `sukoon_states` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sukoon_property_locations_sub_area_id_foreign` FOREIGN KEY (`sub_area_id`) REFERENCES `sukoon_sub_areas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sukoon_property_locations`
--

LOCK TABLES `sukoon_property_locations` WRITE;
/*!40000 ALTER TABLE `sukoon_property_locations` DISABLE KEYS */;
INSERT INTO `sukoon_property_locations` VALUES
(1,11,1,1,2,2,'Rajasthan','Barmer','Rai Colony Road','Bariyon Ka Vas','Rai Colony Road','Bariyon ka Vas',NULL,'Bariyon Ka Vas, Rai Colony Road, Barmer, Rajasthan',NULL,NULL,'google','google',0,NULL,NULL,'2026-05-14 08:36:27','2026-05-14 20:15:29'),
(2,12,1,1,2,2,'Rajasthan','Barmer','Rai Colony Road','Bariyon Ka Vas','Rai Colony Road','Bariyon ka Vas',NULL,'Bariyon Ka Vas, Rai Colony Road, Barmer, Rajasthan',NULL,NULL,'google','google',0,NULL,NULL,'2026-05-14 12:50:41','2026-05-14 20:15:29');
/*!40000 ALTER TABLE `sukoon_property_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sukoon_states`
--

DROP TABLE IF EXISTS `sukoon_states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sukoon_states` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `country` varchar(191) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sukoon_states_country_slug_unique` (`country`,`slug`),
  KEY `sukoon_states_slug_index` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sukoon_states`
--

LOCK TABLES `sukoon_states` WRITE;
/*!40000 ALTER TABLE `sukoon_states` DISABLE KEYS */;
INSERT INTO `sukoon_states` VALUES
(1,'Rajasthan','rajasthan','India',0,1,'2026-05-14 20:15:29','2026-05-14 20:15:29');
/*!40000 ALTER TABLE `sukoon_states` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sukoon_sub_areas`
--

DROP TABLE IF EXISTS `sukoon_sub_areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sukoon_sub_areas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `area_id` bigint(20) unsigned NOT NULL,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `center_lat` decimal(10,7) DEFAULT NULL,
  `center_lng` decimal(10,7) DEFAULT NULL,
  `radius_meters` int(10) unsigned DEFAULT NULL,
  `polygon_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`polygon_json`)),
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `seo_title` varchar(191) DEFAULT NULL,
  `seo_description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sukoon_sub_areas_area_id_slug_unique` (`area_id`,`slug`),
  KEY `sukoon_sub_areas_slug_index` (`slug`),
  CONSTRAINT `sukoon_sub_areas_area_id_foreign` FOREIGN KEY (`area_id`) REFERENCES `sukoon_areas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sukoon_sub_areas`
--

LOCK TABLES `sukoon_sub_areas` WRITE;
/*!40000 ALTER TABLE `sukoon_sub_areas` DISABLE KEYS */;
INSERT INTO `sukoon_sub_areas` VALUES
(1,1,'Rai Colony','rai-colony',NULL,NULL,NULL,NULL,0,1,NULL,NULL,'2026-05-14 08:32:52','2026-05-14 20:15:29'),
(2,2,'Bariyon Ka Vas','bariyon-ka-vas',NULL,NULL,NULL,NULL,0,1,NULL,NULL,'2026-05-14 08:36:27','2026-05-14 20:15:29');
/*!40000 ALTER TABLE `sukoon_sub_areas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telescope_entries`
--

DROP TABLE IF EXISTS `telescope_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telescope_entries` (
  `sequence` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `batch_id` char(36) NOT NULL,
  `family_hash` varchar(191) DEFAULT NULL,
  `should_display_on_index` tinyint(1) NOT NULL DEFAULT 1,
  `type` varchar(20) NOT NULL,
  `content` longtext NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`sequence`),
  UNIQUE KEY `telescope_entries_uuid_unique` (`uuid`),
  KEY `telescope_entries_batch_id_index` (`batch_id`),
  KEY `telescope_entries_family_hash_index` (`family_hash`),
  KEY `telescope_entries_created_at_index` (`created_at`),
  KEY `telescope_entries_type_should_display_on_index_index` (`type`,`should_display_on_index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telescope_entries`
--

LOCK TABLES `telescope_entries` WRITE;
/*!40000 ALTER TABLE `telescope_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `telescope_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telescope_entries_tags`
--

DROP TABLE IF EXISTS `telescope_entries_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telescope_entries_tags` (
  `entry_uuid` char(36) NOT NULL,
  `tag` varchar(191) NOT NULL,
  PRIMARY KEY (`entry_uuid`,`tag`),
  KEY `telescope_entries_tags_tag_index` (`tag`),
  CONSTRAINT `telescope_entries_tags_entry_uuid_foreign` FOREIGN KEY (`entry_uuid`) REFERENCES `telescope_entries` (`uuid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telescope_entries_tags`
--

LOCK TABLES `telescope_entries_tags` WRITE;
/*!40000 ALTER TABLE `telescope_entries_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `telescope_entries_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telescope_monitoring`
--

DROP TABLE IF EXISTS `telescope_monitoring`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telescope_monitoring` (
  `tag` varchar(191) NOT NULL,
  PRIMARY KEY (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telescope_monitoring`
--

LOCK TABLES `telescope_monitoring` WRITE;
/*!40000 ALTER TABLE `telescope_monitoring` DISABLE KEYS */;
/*!40000 ALTER TABLE `telescope_monitoring` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `translations`
--

DROP TABLE IF EXISTS `translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `translations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `language_id` bigint(20) unsigned NOT NULL,
  `key` varchar(100) NOT NULL,
  `value` text NOT NULL,
  `translatable_type` varchar(191) NOT NULL,
  `translatable_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_translation` (`language_id`,`key`,`translatable_id`,`translatable_type`),
  KEY `translations_translatable_type_translatable_id_index` (`translatable_type`,`translatable_id`),
  CONSTRAINT `translations_language_id_foreign` FOREIGN KEY (`language_id`) REFERENCES `languages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `translations`
--

LOCK TABLES `translations` WRITE;
/*!40000 ALTER TABLE `translations` DISABLE KEYS */;
INSERT INTO `translations` VALUES
(2,2,'name','राजकीय अस्पताल','App\\Models\\OutdoorFacilities',2,'2026-05-21 04:02:46','2026-05-21 04:02:46',NULL);
/*!40000 ALTER TABLE `translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `travel_time_cache`
--

DROP TABLE IF EXISTS `travel_time_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `travel_time_cache` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `property_id` bigint(20) unsigned NOT NULL,
  `google_place_id` varchar(191) NOT NULL,
  `duration_seconds` int(10) unsigned DEFAULT NULL,
  `duration_text` varchar(191) DEFAULT NULL,
  `fetched_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `travel_time_cache_property_place_unique` (`property_id`,`google_place_id`),
  KEY `travel_time_cache_property_id_expires_at_index` (`property_id`,`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `travel_time_cache`
--

LOCK TABLES `travel_time_cache` WRITE;
/*!40000 ALTER TABLE `travel_time_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `travel_time_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_interests`
--

DROP TABLE IF EXISTS `user_interests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_interests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `category_ids` varchar(191) DEFAULT NULL,
  `outdoor_facilitiy_ids` varchar(191) DEFAULT NULL,
  `price_range` varchar(191) DEFAULT NULL,
  `city` varchar(191) DEFAULT NULL,
  `state_id` bigint(20) unsigned DEFAULT NULL,
  `city_id` bigint(20) unsigned DEFAULT NULL,
  `area_id` bigint(20) unsigned DEFAULT NULL,
  `sub_area_id` bigint(20) unsigned DEFAULT NULL,
  `area_name` varchar(255) DEFAULT NULL,
  `sub_area_name` varchar(255) DEFAULT NULL,
  `property_type` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_interests`
--

LOCK TABLES `user_interests` WRITE;
/*!40000 ALTER TABLE `user_interests` DISABLE KEYS */;
INSERT INTO `user_interests` VALUES
(1,15,'',NULL,'22,3200000','Barmer',NULL,NULL,NULL,NULL,NULL,NULL,'0,1','2026-05-21 01:34:39','2026-05-21 01:34:39');
/*!40000 ALTER TABLE `user_interests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_package_limits`
--

DROP TABLE IF EXISTS `user_package_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_package_limits` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_package_id` bigint(20) unsigned NOT NULL,
  `package_feature_id` bigint(20) unsigned NOT NULL,
  `total_limit` int(11) NOT NULL,
  `used_limit` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_package_limits_user_package_id_foreign` (`user_package_id`),
  KEY `user_package_limits_package_feature_id_foreign` (`package_feature_id`),
  CONSTRAINT `user_package_limits_package_feature_id_foreign` FOREIGN KEY (`package_feature_id`) REFERENCES `package_features` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_package_limits_user_package_id_foreign` FOREIGN KEY (`user_package_id`) REFERENCES `user_packages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_package_limits`
--

LOCK TABLES `user_package_limits` WRITE;
/*!40000 ALTER TABLE `user_package_limits` DISABLE KEYS */;
INSERT INTO `user_package_limits` VALUES
(1,1,1,1,0,'2026-04-17 08:26:35','2026-04-17 08:26:35'),
(2,2,1,1,0,'2026-04-22 09:47:01','2026-04-22 09:47:01'),
(3,3,1,1,0,'2026-04-25 06:31:21','2026-04-25 06:31:21'),
(4,5,1,1,1,'2026-04-26 04:49:53','2026-05-14 08:36:27'),
(5,6,1,1,1,'2026-05-14 08:34:51','2026-05-14 12:50:41'),
(6,7,1,1,0,'2026-05-17 03:07:16','2026-05-17 03:07:16');
/*!40000 ALTER TABLE `user_package_limits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_packages`
--

DROP TABLE IF EXISTS `user_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_packages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL COMMENT 'customers',
  `package_id` bigint(20) unsigned NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `role_context` enum('user','agent','general') NOT NULL DEFAULT 'user',
  PRIMARY KEY (`id`),
  KEY `user_packages_user_id_foreign` (`user_id`),
  KEY `user_packages_package_id_foreign` (`package_id`),
  KEY `user_packages_role_context_index` (`role_context`),
  CONSTRAINT `user_packages_package_id_foreign` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_packages_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_packages`
--

LOCK TABLES `user_packages` WRITE;
/*!40000 ALTER TABLE `user_packages` DISABLE KEYS */;
INSERT INTO `user_packages` VALUES
(1,10,1,'2026-04-17 08:26:35','2026-04-18 08:26:35','2026-04-17 08:26:35','2026-04-17 08:26:35',NULL,'user'),
(2,10,1,'2026-04-22 09:47:01','2026-04-23 09:47:01','2026-04-22 09:47:01','2026-04-22 09:47:01',NULL,'user'),
(3,4,1,'2026-04-25 06:31:21','2026-04-26 06:31:21','2026-04-25 06:31:21','2026-04-25 06:31:21',NULL,'user'),
(4,16,2,'2026-04-25 06:40:42','2026-04-26 06:40:42','2026-04-25 06:40:42','2026-04-25 06:40:42',NULL,'user'),
(5,15,1,'2026-04-26 04:49:53','2026-04-27 04:49:53','2026-04-26 04:49:53','2026-04-26 04:49:53',NULL,'user'),
(6,15,1,'2026-05-14 08:34:51','2026-05-15 08:34:51','2026-05-14 08:34:51','2026-05-14 08:34:51',NULL,'user'),
(7,15,1,'2026-05-17 03:07:16','2026-05-18 03:07:16','2026-05-17 03:07:16','2026-05-17 03:07:16',NULL,'user'),
(8,15,3,'2026-05-17 09:17:34','2026-06-16 09:17:34','2026-05-17 09:17:34','2026-05-17 09:17:34',NULL,'agent');
/*!40000 ALTER TABLE `user_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_pay_as_you_go_credits`
--

DROP TABLE IF EXISTS `user_pay_as_you_go_credits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_pay_as_you_go_credits` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `pay_as_you_go_id` bigint(20) unsigned NOT NULL,
  `payment_transaction_id` bigint(20) unsigned DEFAULT NULL,
  `used` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_pay_as_you_go_credits`
--

LOCK TABLES `user_pay_as_you_go_credits` WRITE;
/*!40000 ALTER TABLE `user_pay_as_you_go_credits` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_pay_as_you_go_credits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_reports`
--

DROP TABLE IF EXISTS `user_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_reports` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `reason_id` int(11) NOT NULL,
  `customer_id` bigint(20) NOT NULL,
  `property_id` bigint(20) NOT NULL,
  `other_message` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_reports`
--

LOCK TABLES `user_reports` WRITE;
/*!40000 ALTER TABLE `user_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `profile` text DEFAULT NULL,
  `slug_id` varchar(191) NOT NULL COMMENT 'Slug of name',
  `email` varchar(191) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) NOT NULL,
  `type` tinyint(4) NOT NULL COMMENT '0:Admin 1:Users',
  `permissions` text NOT NULL,
  `status` int(11) NOT NULL COMMENT '0:Inactive 1:Active',
  `fcm_id` varchar(191) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'admin',NULL,'admin','admin@gmail.com',NULL,'$2y$10$B/RIY0kfhSEB//ctKnhXAeltAXsJ1xS0MupfJTFX9yWfW7hRVrx22',0,'',1,'coIBDqJUwkxvjLnnZVI06p:APA91bE_Mk6g8edrn6D8608vnLnUKrRwUt82gu_xmOYzB0FA_VUppsAHHnMDAbxaCHhn5rau74kWaTdyl_Bk3RzCYyqNB6UXE33W8WvZSIGTbwZKjQF8zA4',NULL,NULL,'2026-05-14 07:43:10');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usertokens`
--

DROP TABLE IF EXISTS `usertokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usertokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `fcm_id` varchar(191) NOT NULL,
  `api_token` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `usertokens_fcm_id_unique` (`fcm_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usertokens`
--

LOCK TABLES `usertokens` WRITE;
/*!40000 ALTER TABLE `usertokens` DISABLE KEYS */;
INSERT INTO `usertokens` VALUES
(1,1,'dd-6C4uP6JL_oqLTu1ulPx:APA91bENaGPsDD0nQFybHqYf0o7K9vwRXZtREYFVLXpGcFiLy5tC2cY1-3WGVcrQjG-1lbR0n4uQyZP4UXCEsFA4MdkFFmFSVKcYK4vRQT-XAuulTAsKnsI','','2026-04-06 03:09:52','2026-04-06 03:09:52'),
(2,2,'cxyHdmJvNTkX-91gMdr4YI:APA91bFoqQsmjszMOypuBb51_Q3f89Mkic1gGUMqMu-YD7m0RiELwkxL85maEdyhDWWxyRfaJFWfCxkVL_Fp7Bs5uuooMqGq2cX3U3xuu435nqoSthgzTn4','','2026-04-06 11:49:03','2026-04-06 11:49:03'),
(3,2,'cQQ-5IPrSPLEuoPUhI7vT0:APA91bEEvUTkdzDXoxQFcXA6p8xb8ZGfA6jLOko8LM4erK0PdNemOUUrsOsNbSEkd9N-Cps73LTxmHzH8kcy6P39lVs9sBiqpYhqFnIoVMFwcHSTXUuHrNE','','2026-04-06 12:26:25','2026-04-06 12:26:25'),
(18,3,'dyNoMsOIy-xAH3bxt_3fXt:APA91bEahUMNVuqiJStA9FYxfez34ohlaqtwSUIzRij1-kYEL0vSMJoLKP1gGIofbwW137TeKqf6v_t58i6wghMcg4KYIf02YpU2Z0-ub11qTsq6WudcD3g','','2026-04-16 16:36:06','2026-04-16 16:36:06'),
(21,4,'eHtSiAOKWR9tSCWWVf4SXG:APA91bF619eUM7JXXiX__ZEMyLt63MgT2W_68eX0xsyrIbtfgbCaHaDm2PWAmOy-IIVyu-yk9S8JZmduq1asVsj2RvOsPZdaUDwG9EkXjfpDz9MKu1AbP9g','','2026-04-25 07:06:28','2026-04-25 07:06:28'),
(30,15,'dRWNWkdkdVqvj2hCeeAlFm:APA91bHc20inwWExJL4W19Qwn-MD_XuuN28EfDoTcReGfc62xTlVttvdyFAopRNYRq0xgnkSnh2DHR9oczdPdzYGzOkjx_-pCEgt-2lvuujETWRak2HJZG0','','2026-05-20 15:17:21','2026-05-20 15:17:21'),
(31,15,'dTVwTb8xSeioy0-MeWa__-:APA91bFtjXUr8Qyuo5OZM1EB1g3-MU-9Hl6baBsIRuc0TrUooEhMVInpSlNC3D0HfMftBH7giVfHsp_fw18IzDbbtl0IVHkOE_tNHLN9uvWO7YNBzd3VRpM','','2026-05-20 16:20:00','2026-05-20 16:20:00');
/*!40000 ALTER TABLE `usertokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verify_customer_form_values`
--

DROP TABLE IF EXISTS `verify_customer_form_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `verify_customer_form_values` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `verify_customer_form_id` bigint(20) unsigned NOT NULL,
  `value` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `verify_customer_form_values_verify_customer_form_id_foreign` (`verify_customer_form_id`),
  CONSTRAINT `verify_customer_form_values_verify_customer_form_id_foreign` FOREIGN KEY (`verify_customer_form_id`) REFERENCES `verify_customer_forms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verify_customer_form_values`
--

LOCK TABLES `verify_customer_form_values` WRITE;
/*!40000 ALTER TABLE `verify_customer_form_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `verify_customer_form_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verify_customer_forms`
--

DROP TABLE IF EXISTS `verify_customer_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `verify_customer_forms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `field_type` enum('text','number','radio','checkbox','dropdown','textarea','file') NOT NULL,
  `rank` int(11) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verify_customer_forms`
--

LOCK TABLES `verify_customer_forms` WRITE;
/*!40000 ALTER TABLE `verify_customer_forms` DISABLE KEYS */;
INSERT INTO `verify_customer_forms` VALUES
(1,'Aadhar Card','file',NULL,'active','2026-04-25 06:48:25','2026-04-25 06:48:25',NULL),
(2,'Pan Card','file',NULL,'active','2026-04-25 06:49:07','2026-04-25 06:49:07',NULL);
/*!40000 ALTER TABLE `verify_customer_forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verify_customer_values`
--

DROP TABLE IF EXISTS `verify_customer_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `verify_customer_values` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `verify_customer_id` bigint(20) unsigned NOT NULL,
  `verify_customer_form_id` bigint(20) unsigned NOT NULL,
  `value` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_id` (`verify_customer_id`,`verify_customer_form_id`),
  KEY `verify_customer_values_verify_customer_form_id_foreign` (`verify_customer_form_id`),
  CONSTRAINT `verify_customer_values_verify_customer_form_id_foreign` FOREIGN KEY (`verify_customer_form_id`) REFERENCES `verify_customer_forms` (`id`) ON DELETE CASCADE,
  CONSTRAINT `verify_customer_values_verify_customer_id_foreign` FOREIGN KEY (`verify_customer_id`) REFERENCES `verify_customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verify_customer_values`
--

LOCK TABLES `verify_customer_values` WRITE;
/*!40000 ALTER TABLE `verify_customer_values` DISABLE KEYS */;
INSERT INTO `verify_customer_values` VALUES
(1,1,1,'1777099804-img-20260425-wa0007.jpg','2026-04-25 06:50:04','2026-04-25 06:50:04',NULL),
(2,1,2,'1777099804-a68088fc8d82c82912a7fb70a240aea2.jpg','2026-04-25 06:50:04','2026-04-25 06:50:04',NULL),
(3,2,1,'1777099958-speaker-panel-18-1.png','2026-04-25 06:52:38','2026-04-25 06:52:38',NULL),
(4,2,2,'1777099958-ene.png','2026-04-25 06:52:38','2026-04-25 06:52:38',NULL);
/*!40000 ALTER TABLE `verify_customer_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verify_customers`
--

DROP TABLE IF EXISTS `verify_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `verify_customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `verify_customers_user_id_foreign` (`user_id`),
  CONSTRAINT `verify_customers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verify_customers`
--

LOCK TABLES `verify_customers` WRITE;
/*!40000 ALTER TABLE `verify_customers` DISABLE KEYS */;
INSERT INTO `verify_customers` VALUES
(1,16,'approved','2026-04-25 06:50:04','2026-04-25 06:50:59',NULL),
(2,15,'approved','2026-04-25 06:52:38','2026-04-26 04:52:36',NULL);
/*!40000 ALTER TABLE `verify_customers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-21  4:06:52
