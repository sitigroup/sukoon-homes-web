/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.10-MariaDB, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: sql_admin_homes
-- ------------------------------------------------------
-- Server version	10.11.10-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `area_listing_states`
--

DROP TABLE IF EXISTS `area_listing_states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area_listing_states` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `country` varchar(191) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `area_listing_states_country_slug_unique` (`country`,`slug`),
  KEY `area_listing_states_slug_index` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area_listing_states`
--

LOCK TABLES `area_listing_states` WRITE;
/*!40000 ALTER TABLE `area_listing_states` DISABLE KEYS */;
INSERT INTO `area_listing_states` VALUES
(1,'Rajasthan','rajasthan','India',0,1,'2026-05-14 20:18:10','2026-05-14 20:18:10'),
(2,'Test State 6A0De0F383551','test-state-6a0de0f383551','India',0,1,'2026-05-20 16:27:32','2026-05-20 16:27:32'),
(3,'Test State 6A0De1F097Ce0','test-state-6a0de1f097ce0','India',0,1,'2026-05-20 16:31:45','2026-05-20 16:31:45'),
(6,'Gujarat','gujarat','India',0,1,'2026-05-20 16:52:51','2026-05-20 16:52:51'),
(7,'Delhi','delhi','India',0,1,'2026-05-20 16:52:51','2026-05-20 16:52:51');
/*!40000 ALTER TABLE `area_listing_states` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `area_listing_cities`
--

DROP TABLE IF EXISTS `area_listing_cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area_listing_cities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `state_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `normalized_name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `state` varchar(191) NOT NULL DEFAULT '',
  `country` varchar(191) NOT NULL DEFAULT 'India',
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `area_listing_cities_normalized_state_country_unique` (`normalized_name`,`state`,`country`),
  UNIQUE KEY `area_listing_cities_state_id_slug_unique` (`state_id`,`slug`),
  KEY `area_listing_cities_state_id_index` (`state_id`),
  KEY `area_listing_cities_slug_index` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area_listing_cities`
--

LOCK TABLES `area_listing_cities` WRITE;
/*!40000 ALTER TABLE `area_listing_cities` DISABLE KEYS */;
INSERT INTO `area_listing_cities` VALUES
(1,1,'Barmer','barmer','barmer','Rajasthan','India',0,1,'2026-05-14 20:18:10','2026-05-14 20:18:10'),
(7,6,'Bhuj','bhuj','bhuj','Gujarat','India',0,1,'2026-05-20 16:52:51','2026-05-20 16:52:51'),
(8,6,'ઢોંસા','ઢોંસા','','Gujarat','India',0,1,'2026-05-20 16:52:51','2026-05-20 16:52:51'),
(9,7,'New Delhi','new delhi','new-delhi','Delhi','India',0,1,'2026-05-20 16:52:51','2026-05-20 16:52:51'),
(10,1,'Udaipur','udaipur','udaipur','Rajasthan','India',0,1,'2026-05-20 21:15:23','2026-05-20 21:15:23'),
(11,1,'Jaipur','jaipur','jaipur','Rajasthan','India',0,1,'2026-05-20 21:29:36','2026-05-20 21:29:36');
/*!40000 ALTER TABLE `area_listing_cities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `area_listing_areas`
--

DROP TABLE IF EXISTS `area_listing_areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area_listing_areas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `state_id` bigint(20) unsigned DEFAULT NULL,
  `city_id` bigint(20) unsigned DEFAULT NULL,
  `city_name` varchar(191) DEFAULT NULL,
  `city` varchar(191) DEFAULT NULL,
  `state` varchar(191) DEFAULT NULL,
  `country` varchar(191) DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `normalized_name` varchar(191) DEFAULT NULL,
  `slug` varchar(191) NOT NULL,
  `center_lat` decimal(10,7) DEFAULT NULL,
  `center_lng` decimal(10,7) DEFAULT NULL,
  `radius_meters` int(10) unsigned DEFAULT NULL,
  `polygon_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`polygon_json`)),
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `workflow_status` varchar(20) NOT NULL DEFAULT 'active',
  `archived_at` timestamp NULL DEFAULT NULL,
  `seo_title` varchar(191) DEFAULT NULL,
  `seo_description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `area_listing_areas_city_state_name_unique` (`city`,`state`,`name`),
  UNIQUE KEY `area_listing_areas_city_state_country_normalized_unique` (`city`,`state`,`country`,`normalized_name`),
  KEY `area_listing_areas_city_index` (`city`),
  KEY `area_listing_areas_state_index` (`state`),
  KEY `area_listing_areas_country_index` (`country`),
  KEY `area_listing_areas_name_index` (`name`),
  KEY `area_listing_areas_slug_index` (`slug`),
  KEY `area_listing_areas_status_index` (`status`),
  KEY `area_listing_areas_state_id_index` (`state_id`),
  KEY `area_listing_areas_city_id_index` (`city_id`),
  KEY `area_listing_areas_workflow_status_index` (`workflow_status`),
  KEY `area_listing_areas_city_name_index` (`city_name`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area_listing_areas`
--

LOCK TABLES `area_listing_areas` WRITE;
/*!40000 ALTER TABLE `area_listing_areas` DISABLE KEYS */;
INSERT INTO `area_listing_areas` VALUES
(2,1,1,'Barmer','Barmer','Rajasthan','India','Rai Colony Road','rai colony road','rai-colony-road',NULL,NULL,NULL,NULL,0,1,'active',NULL,NULL,NULL,'2026-05-14 08:36:27','2026-05-14 20:18:10'),
(3,1,1,'Barmer','Barmer','Rajasthan','India','Mahaveer Nagar','mahaveer nagar','mahaveer-nagar',NULL,NULL,NULL,NULL,0,1,'active',NULL,NULL,NULL,'2026-05-14 18:22:52','2026-05-14 20:18:10'),
(42,1,1,'Barmer','Barmer','Rajasthan','India','Baldev Nagar','baldev nagar','baldev-nagar',NULL,NULL,NULL,NULL,0,1,'active','2026-05-20 20:50:21',NULL,NULL,'2026-05-20 19:51:29','2026-05-20 21:51:37'),
(43,NULL,NULL,'Udaipur','Udaipur','Rajasthan','India','Maharana Udai Singh Market','maharana udai singh market','maharana-udai-singh-market',NULL,NULL,NULL,NULL,0,1,'active',NULL,NULL,NULL,'2026-05-20 21:14:29','2026-05-20 21:14:29'),
(45,1,1,'Barmer','Barmer','Rajasthan','India','Krishna Nagar','krishna nagar','krishna-nagar',NULL,NULL,NULL,NULL,0,1,'active',NULL,NULL,NULL,'2026-05-21 03:16:16','2026-05-21 03:16:16');
/*!40000 ALTER TABLE `area_listing_areas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `area_listing_sub_areas`
--

DROP TABLE IF EXISTS `area_listing_sub_areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area_listing_sub_areas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `area_id` bigint(20) unsigned NOT NULL,
  `name` varchar(191) NOT NULL,
  `normalized_name` varchar(191) DEFAULT NULL,
  `slug` varchar(191) NOT NULL,
  `center_lat` decimal(10,7) DEFAULT NULL,
  `center_lng` decimal(10,7) DEFAULT NULL,
  `radius_meters` int(10) unsigned DEFAULT NULL,
  `polygon_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`polygon_json`)),
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `workflow_status` varchar(20) NOT NULL DEFAULT 'active',
  `archived_at` timestamp NULL DEFAULT NULL,
  `seo_title` varchar(191) DEFAULT NULL,
  `seo_description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `area_listing_sub_areas_area_slug_unique` (`area_id`,`slug`),
  UNIQUE KEY `area_listing_sub_areas_area_normalized_unique` (`area_id`,`normalized_name`),
  KEY `area_listing_sub_areas_name_index` (`name`),
  KEY `area_listing_sub_areas_slug_index` (`slug`),
  KEY `area_listing_sub_areas_status_index` (`status`),
  KEY `area_listing_sub_areas_workflow_status_index` (`workflow_status`),
  CONSTRAINT `area_listing_sub_areas_area_id_foreign` FOREIGN KEY (`area_id`) REFERENCES `area_listing_areas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area_listing_sub_areas`
--

LOCK TABLES `area_listing_sub_areas` WRITE;
/*!40000 ALTER TABLE `area_listing_sub_areas` DISABLE KEYS */;
INSERT INTO `area_listing_sub_areas` VALUES
(2,2,'Bariyon Ka Vas','bariyon ka vas','bariyon-ka-vas',NULL,NULL,NULL,NULL,0,1,'active',NULL,NULL,NULL,'2026-05-14 08:36:27','2026-05-17 12:14:11'),
(27,42,'Nichla Was','nichla was','nichla-was',25.7521467,71.3966865,NULL,NULL,0,1,'active',NULL,NULL,NULL,'2026-05-20 20:53:49','2026-05-20 20:53:49'),
(29,45,'Rai Colony Road','rai colony road','rai-colony-road',NULL,NULL,NULL,NULL,0,1,'active',NULL,NULL,NULL,'2026-05-21 03:16:39','2026-05-21 03:16:39');
/*!40000 ALTER TABLE `area_listing_sub_areas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `area_listing_property_locations`
--

DROP TABLE IF EXISTS `area_listing_property_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area_listing_property_locations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `property_id` bigint(20) unsigned NOT NULL,
  `state_id` bigint(20) unsigned DEFAULT NULL,
  `city_id` bigint(20) unsigned DEFAULT NULL,
  `area_id` bigint(20) unsigned DEFAULT NULL,
  `sub_area_id` bigint(20) unsigned DEFAULT NULL,
  `state` varchar(191) DEFAULT NULL,
  `city` varchar(191) DEFAULT NULL,
  `area_name` varchar(191) DEFAULT NULL,
  `sub_area_name` varchar(191) DEFAULT NULL,
  `detected_area_name` varchar(191) DEFAULT NULL,
  `detected_sub_area_name` varchar(191) DEFAULT NULL,
  `full_address` text DEFAULT NULL,
  `manual_address` text DEFAULT NULL,
  `display_address` varchar(191) DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `location_source` varchar(191) NOT NULL DEFAULT 'manual',
  `is_verified` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `source` varchar(191) NOT NULL DEFAULT 'manual',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `area_listing_property_locations_property_id_unique` (`property_id`),
  KEY `area_listing_property_locations_sub_area_id_foreign` (`sub_area_id`),
  KEY `area_listing_property_locations_area_id_sub_area_id_index` (`area_id`,`sub_area_id`),
  KEY `area_listing_property_locations_state_id_index` (`state_id`),
  KEY `area_listing_property_locations_city_id_index` (`city_id`),
  CONSTRAINT `area_listing_property_locations_area_id_foreign` FOREIGN KEY (`area_id`) REFERENCES `area_listing_areas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `area_listing_property_locations_property_id_foreign` FOREIGN KEY (`property_id`) REFERENCES `propertys` (`id`) ON DELETE CASCADE,
  CONSTRAINT `area_listing_property_locations_sub_area_id_foreign` FOREIGN KEY (`sub_area_id`) REFERENCES `area_listing_sub_areas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area_listing_property_locations`
--

LOCK TABLES `area_listing_property_locations` WRITE;
/*!40000 ALTER TABLE `area_listing_property_locations` DISABLE KEYS */;
INSERT INTO `area_listing_property_locations` VALUES
(1,11,1,10,43,NULL,'Rajasthan','Udaipur','Maharana Udai Singh Market',NULL,'Maharana Udai Singh Market',NULL,'HPG2+86W, Maharana Udai Singh Market, Ganesh Ghati, Udaipur, Rajasthan 313001, India','Opp lalit shop gaur chatrawas','Maharana Udai Singh Market, Udaipur, Rajasthan',24.5761000,73.7005000,'google',0,NULL,15,'google','2026-05-20 21:15:23','2026-05-20 21:20:12'),
(2,12,1,1,2,2,'Rajasthan','Barmer','Rai Colony Road','Bariyon Ka Vas','Rai Colony Road','Bariyon Ka Vas','new Barmer, Rajasthan 344001, India','rai colony krishna nagar barmer','Bariyon Ka Vas, Rai Colony Road, Barmer, Rajasthan',25.7521467,71.3966865,'google',0,NULL,1,'google','2026-05-20 11:45:55','2026-05-20 11:45:55'),
(8,13,1,1,42,27,'Rajasthan','Barmer','Baldev Nagar','Nichla Was','Baldev Nagar','Nichla Was','krishna Nagar, Barmer, Rajasthan 344001, India','opp lalit store gaur chatravas','Nichla Was, Baldev Nagar, Barmer, Rajasthan',25.7514820,71.3924730,'google',0,NULL,15,'google','2026-05-20 21:07:03','2026-05-20 21:07:03'),
(19,1,6,7,NULL,NULL,'Gujarat','Bhuj',NULL,NULL,NULL,NULL,NULL,NULL,'Bhuj, Gujarat',23.1831890,69.6840750,'manual',0,NULL,NULL,'manual','2026-05-20 16:52:51','2026-05-20 16:52:51'),
(20,2,6,7,NULL,NULL,'Gujarat','Bhuj',NULL,NULL,NULL,NULL,NULL,NULL,'Bhuj, Gujarat',23.1930230,69.7351100,'manual',0,NULL,NULL,'manual','2026-05-20 16:52:51','2026-05-20 16:52:51'),
(21,3,6,8,NULL,NULL,'Gujarat','ઢોંસા',NULL,NULL,NULL,NULL,NULL,NULL,'ઢોંસા, Gujarat',23.3169170,69.6198280,'manual',0,NULL,NULL,'manual','2026-05-20 16:52:51','2026-05-20 16:52:51'),
(22,4,1,1,NULL,NULL,'Rajasthan','Barmer',NULL,NULL,NULL,NULL,NULL,NULL,'Barmer, Rajasthan',25.7522057,71.3865196,'manual',0,NULL,NULL,'manual','2026-05-20 16:52:51','2026-05-20 16:52:51'),
(23,5,6,8,NULL,NULL,'Gujarat','કુરબાઈ',NULL,NULL,NULL,NULL,NULL,NULL,'કુરબાઈ, Gujarat',23.1973620,69.6090700,'manual',0,NULL,NULL,'manual','2026-05-20 16:52:51','2026-05-20 16:52:51'),
(24,6,1,1,42,27,'Rajasthan','Barmer','Baldev Nagar','Nichla Was','Baldev Nagar','Nichla Was','Barmer, Rajasthan 344001, India','Barmer Rajasthan','Nichla Was, Baldev Nagar, Barmer, Rajasthan',25.7521467,71.3966865,'manual',0,NULL,1,'manual','2026-05-20 20:53:54','2026-05-20 20:53:54'),
(25,7,6,8,NULL,NULL,'Gujarat','પાલારા',NULL,NULL,NULL,NULL,NULL,NULL,'પાલારા, Gujarat',23.2989810,69.6604120,'manual',0,NULL,NULL,'manual','2026-05-20 16:52:51','2026-05-20 16:52:51'),
(26,8,1,1,NULL,NULL,'Rajasthan','Barmer',NULL,NULL,NULL,NULL,NULL,NULL,'Barmer, Rajasthan',25.7461698,71.3971774,'manual',0,NULL,NULL,'manual','2026-05-20 16:52:51','2026-05-20 16:52:51'),
(27,9,7,9,NULL,NULL,'Delhi','New Delhi',NULL,NULL,NULL,NULL,NULL,NULL,'New Delhi, Delhi',28.7577147,77.1952590,'manual',0,NULL,NULL,'manual','2026-05-20 16:52:51','2026-05-20 16:52:51'),
(28,10,7,9,NULL,NULL,'Delhi','New Delhi',NULL,NULL,NULL,NULL,NULL,NULL,'New Delhi, Delhi',28.7801407,77.1794183,'manual',0,NULL,NULL,'manual','2026-05-20 16:52:51','2026-05-20 16:52:51');
/*!40000 ALTER TABLE `area_listing_property_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `area_listing_project_locations`
--

DROP TABLE IF EXISTS `area_listing_project_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area_listing_project_locations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint(20) unsigned NOT NULL,
  `state_id` bigint(20) unsigned DEFAULT NULL,
  `city_id` bigint(20) unsigned DEFAULT NULL,
  `area_id` bigint(20) unsigned DEFAULT NULL,
  `sub_area_id` bigint(20) unsigned DEFAULT NULL,
  `state` varchar(191) DEFAULT NULL,
  `city` varchar(191) DEFAULT NULL,
  `area_name` varchar(191) DEFAULT NULL,
  `sub_area_name` varchar(191) DEFAULT NULL,
  `detected_area_name` varchar(191) DEFAULT NULL,
  `detected_sub_area_name` varchar(191) DEFAULT NULL,
  `full_address` text DEFAULT NULL,
  `manual_address` text DEFAULT NULL,
  `display_address` varchar(191) DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `location_source` varchar(191) NOT NULL DEFAULT 'manual',
  `is_verified` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `source` varchar(191) NOT NULL DEFAULT 'manual',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `area_listing_project_locations_project_id_unique` (`project_id`),
  KEY `area_listing_project_locations_sub_area_id_foreign` (`sub_area_id`),
  KEY `area_listing_project_locations_area_id_sub_area_id_index` (`area_id`,`sub_area_id`),
  KEY `area_listing_project_locations_state_id_index` (`state_id`),
  KEY `area_listing_project_locations_city_id_index` (`city_id`),
  CONSTRAINT `area_listing_project_locations_area_id_foreign` FOREIGN KEY (`area_id`) REFERENCES `area_listing_areas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `area_listing_project_locations_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `area_listing_project_locations_sub_area_id_foreign` FOREIGN KEY (`sub_area_id`) REFERENCES `area_listing_sub_areas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area_listing_project_locations`
--

LOCK TABLES `area_listing_project_locations` WRITE;
/*!40000 ALTER TABLE `area_listing_project_locations` DISABLE KEYS */;
/*!40000 ALTER TABLE `area_listing_project_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `area_listing_suggestions`
--

DROP TABLE IF EXISTS `area_listing_suggestions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area_listing_suggestions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  `area_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `normalized_name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `city` varchar(191) DEFAULT NULL,
  `state` varchar(191) DEFAULT NULL,
  `country` varchar(191) DEFAULT NULL,
  `suggested_by` bigint(20) unsigned DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `review_note` text DEFAULT NULL,
  `reviewed_by` bigint(20) unsigned DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `area_listing_suggestions_type_status` (`type`,`status`),
  KEY `area_listing_suggestions_status_index` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area_listing_suggestions`
--

LOCK TABLES `area_listing_suggestions` WRITE;
/*!40000 ALTER TABLE `area_listing_suggestions` DISABLE KEYS */;
INSERT INTO `area_listing_suggestions` VALUES
(29,'sub_area',42,'Nichla Was','nichla was','nichla-was',NULL,NULL,'India',15,'approved',NULL,1,'2026-05-20 19:52:38','2026-05-20 19:52:21','2026-05-20 19:52:38'),
(30,'sub_area',42,'Taliyo Ka Was','taliyo ka was','taliyo-ka-was',NULL,NULL,'India',15,'merged',NULL,1,'2026-05-20 20:58:58','2026-05-20 20:58:30','2026-05-20 20:58:58'),
(31,'area',NULL,'Maharana Udai Singh Market','maharana udai singh market','maharana-udai-singh-market','Udaipur','Rajasthan','India',15,'approved',NULL,1,'2026-05-20 21:14:29','2026-05-20 21:14:13','2026-05-20 21:14:29'),
(32,'sub_area',42,'Dsdsfds','dsdsfds','dsdsfds',NULL,NULL,'India',15,'rejected','fake',1,'2026-05-20 21:41:28','2026-05-20 21:41:03','2026-05-20 21:41:28');
/*!40000 ALTER TABLE `area_listing_suggestions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `area_listing_merge_audits`
--

DROP TABLE IF EXISTS `area_listing_merge_audits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area_listing_merge_audits` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `entity_type` varchar(20) NOT NULL,
  `old_id` bigint(20) unsigned NOT NULL,
  `new_id` bigint(20) unsigned NOT NULL,
  `affected_properties` int(10) unsigned NOT NULL DEFAULT 0,
  `affected_projects` int(10) unsigned NOT NULL DEFAULT 0,
  `admin_user_id` bigint(20) unsigned DEFAULT NULL,
  `snapshot` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`snapshot`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `area_listing_merge_audit_lookup` (`entity_type`,`old_id`,`new_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area_listing_merge_audits`
--

LOCK TABLES `area_listing_merge_audits` WRITE;
/*!40000 ALTER TABLE `area_listing_merge_audits` DISABLE KEYS */;
INSERT INTO `area_listing_merge_audits` VALUES
(5,'sub_area',30,27,0,0,1,'{\"source\":\"suggestion_merge\",\"suggested_name\":\"Taliyo Ka Was\",\"review_note\":null,\"merged_at\":\"2026-05-20 20:58:58\"}','2026-05-20 20:58:58','2026-05-20 20:58:58');
/*!40000 ALTER TABLE `area_listing_merge_audits` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-21  4:06:52
