<?php



use App\Plugins\TrustVerification\Http\Controllers\Admin\TrustVerificationAdminController;

use App\Plugins\TrustVerification\Http\Controllers\Admin\TrustVerificationAutomationAdminController;

use App\Plugins\TrustVerification\Http\Controllers\Admin\TrustVerificationCityAdminController;

use App\Plugins\TrustVerification\Http\Controllers\Admin\TrustVerificationPackageAdminController;

use App\Plugins\TrustVerification\Http\Controllers\Admin\TrustVerificationContentAdminController;

use App\Plugins\TrustVerification\Http\Controllers\Admin\TrustVerificationSampleReportAdminController;

use Illuminate\Support\Facades\Route;



Route::prefix('trust-verification')->name('trust-verification.')->group(function () {

    Route::get('/', [TrustVerificationAdminController::class, 'index'])->name('index');

    Route::get('orders/{order}', [TrustVerificationAdminController::class, 'show'])->name('orders.show');

    Route::post('orders/{order}/status', [TrustVerificationAdminController::class, 'updateStatus'])->name('orders.status');

    Route::post('orders/{order}/checks', [TrustVerificationAdminController::class, 'updateChecks'])->name('orders.checks');

    Route::post('orders/{order}/references', [TrustVerificationAdminController::class, 'storeReference'])->name('orders.references.store');
    Route::post('orders/{order}/references/{reference}', [TrustVerificationAdminController::class, 'updateReference'])->name('orders.references.update');

    Route::post('orders/{order}/report', [TrustVerificationAdminController::class, 'uploadReport'])->name('orders.report');

    Route::get('orders/{order}/report/download', [TrustVerificationAdminController::class, 'downloadReport'])->name('orders.report.download');

    Route::post('orders/{order}/payment', [TrustVerificationAdminController::class, 'markPayment'])->name('orders.payment');

    Route::post('orders/{order}/automation/run', [TrustVerificationAdminController::class, 'runAutomation'])->name('orders.automation.run');

    Route::get('orders/{order}/documents/{document}/download', [TrustVerificationAdminController::class, 'downloadDocument'])->name('orders.documents.download');

    Route::post('orders/{order}/documents/delete', [TrustVerificationAdminController::class, 'deleteDocuments'])->name('orders.documents.delete');

    Route::post('orders/{order}/report/delete', [TrustVerificationAdminController::class, 'deleteReport'])->name('orders.report.delete');



    Route::get('packages', [TrustVerificationPackageAdminController::class, 'index'])->name('packages.index');

    Route::get('packages/create', [TrustVerificationPackageAdminController::class, 'create'])->name('packages.create');

    Route::post('packages', [TrustVerificationPackageAdminController::class, 'store'])->name('packages.store');

    Route::get('packages/{package}/edit', [TrustVerificationPackageAdminController::class, 'edit'])->name('packages.edit');

    Route::put('packages/{package}', [TrustVerificationPackageAdminController::class, 'update'])->name('packages.update');



    Route::get('cities', [TrustVerificationCityAdminController::class, 'index'])->name('cities.index');

    Route::post('cities', [TrustVerificationCityAdminController::class, 'store'])->name('cities.store');

    Route::put('cities/{city}', [TrustVerificationCityAdminController::class, 'update'])->name('cities.update');

    Route::post('cities/{city}/toggle', [TrustVerificationCityAdminController::class, 'toggle'])->name('cities.toggle');



    Route::get('automation', [TrustVerificationAutomationAdminController::class, 'index'])->name('automation.index');

    Route::put('automation', [TrustVerificationAutomationAdminController::class, 'update'])->name('automation.update');

    Route::post('automation/reconcile-payments', [TrustVerificationAutomationAdminController::class, 'reconcilePayments'])->name('automation.reconcile');

    Route::get('content', [TrustVerificationContentAdminController::class, 'index'])->name('content.index');
    Route::post('content/seed', [TrustVerificationContentAdminController::class, 'seed'])->name('content.seed');
    Route::post('content/faq', [TrustVerificationContentAdminController::class, 'storeFaq'])->name('content.faq.store');
    Route::post('content/reorder', [TrustVerificationContentAdminController::class, 'reorder'])->name('content.reorder');
    Route::get('content/blocks/{block}/edit', [TrustVerificationContentAdminController::class, 'edit'])->name('content.edit');
    Route::put('content/blocks/{block}', [TrustVerificationContentAdminController::class, 'update'])->name('content.update');
    Route::post('content/blocks/{block}/publish', [TrustVerificationContentAdminController::class, 'togglePublish'])->name('content.publish');
    Route::post('content/blocks/{block}/reset', [TrustVerificationContentAdminController::class, 'reset'])->name('content.reset');

    Route::get('sample-reports', [TrustVerificationSampleReportAdminController::class, 'index'])->name('sample-reports.index');
    Route::get('sample-reports/create', [TrustVerificationSampleReportAdminController::class, 'create'])->name('sample-reports.create');
    Route::post('sample-reports', [TrustVerificationSampleReportAdminController::class, 'store'])->name('sample-reports.store');
    Route::get('sample-reports/{sampleReport}/edit', [TrustVerificationSampleReportAdminController::class, 'edit'])->name('sample-reports.edit');
    Route::put('sample-reports/{sampleReport}', [TrustVerificationSampleReportAdminController::class, 'update'])->name('sample-reports.update');
    Route::post('sample-reports/{sampleReport}/delete', [TrustVerificationSampleReportAdminController::class, 'destroy'])->name('sample-reports.destroy');
    Route::get('sample-reports/{sampleReport}/download', [TrustVerificationSampleReportAdminController::class, 'download'])->name('sample-reports.download');

});
