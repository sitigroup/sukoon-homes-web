@extends('layouts.main')

@section('title')
    Trust Verification Packages
@endsection

@section('content')
    <section class="section tv-admin">
        @include('trust-verification::admin.partials.tv-admin-theme')
        @include('trust-verification::admin.partials.nav')

        <div class="tv-card">
            <div class="tv-card__header">
                <div>
                    <h4 class="tv-page-header__title mb-0">Packages</h4>
                    <p class="tv-page-header__meta mb-0 mt-1">Active packages appear on the web wizard.</p>
                </div>
                <div class="d-flex align-items-center gap-2 flex-wrap">
                    <span class="tv-page-header__meta">{{ $packages->count() }} shown</span>
                    <a href="{{ route('trust-verification.packages.create') }}" class="btn tv-btn-primary">
                        <i class="bi bi-plus-lg"></i> Add package
                    </a>
                </div>
            </div>
            <div class="tv-card__body">
                @if(session('success'))
                    <div class="alert alert-success">{{ session('success') }}</div>
                @endif

                <form method="get" class="tv-filter row g-2">
                    <div class="col-md-3">
                        <label class="form-label small mb-0 text-muted">Search</label>
                        <input type="text" name="q" class="form-control form-control-sm" placeholder="Name or slug"
                               value="{{ $filters['q'] ?? '' }}">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label small mb-0 text-muted">City</label>
                        <select name="city_slug" class="form-select form-select-sm">
                            <option value="">All cities</option>
                            @foreach($cityOptions as $slug => $label)
                                <option value="{{ $slug }}" @selected(($filters['city_slug'] ?? '') === $slug)>{{ $label }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label small mb-0 text-muted">Type</label>
                        <select name="type" class="form-select form-select-sm">
                            <option value="">All types</option>
                            <option value="tenant" @selected(($filters['type'] ?? '') === 'tenant')>Tenant</option>
                            <option value="owner" @selected(($filters['type'] ?? '') === 'owner')>Owner</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label small mb-0 text-muted">Status</label>
                        <select name="is_active" class="form-select form-select-sm">
                            <option value="">All</option>
                            <option value="1" @selected(($filters['is_active'] ?? '') === '1')>Active</option>
                            <option value="0" @selected(($filters['is_active'] ?? '') === '0')>Inactive</option>
                        </select>
                    </div>
                    <div class="col-md-3 d-flex align-items-end gap-2">
                        <button type="submit" class="btn tv-btn-primary flex-grow-1">Apply</button>
                        <a href="{{ route('trust-verification.packages.index') }}" class="btn tv-btn-secondary">Reset</a>
                    </div>
                </form>

                <div class="table-responsive">
                    <table class="table table-striped align-middle mb-0">
                        <thead>
                        <tr>
                            <th>Package</th>
                            <th>City</th>
                            <th>Type</th>
                            <th>Price</th>
                            <th>Delivery</th>
                            <th>Checks</th>
                            <th>Orders</th>
                            <th>Status</th>
                            <th>Sort</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                        @forelse($packages as $package)
                            @php
                                $included = collect($package->features ?? [])->where('included', true)->count();
                                $total = count($package->features ?? []);
                            @endphp
                            <tr>
                                <td>
                                    <strong>{{ $package->name }}</strong><br>
                                    <code class="small text-muted">{{ $package->slug }}</code>
                                </td>
                                <td>{{ $cityCatalog[$package->city_slug] ?? $package->city_slug }}</td>
                                <td>{{ ucfirst($package->type) }}</td>
                                <td><span class="tv-price-badge">₹{{ number_format($package->price) }}</span></td>
                                <td>{{ $package->delivery_hours }}h</td>
                                <td>{{ $included }}/{{ $total }}</td>
                                <td>{{ $package->orders_count }}</td>
                                <td>
                                    @if($package->is_active)
                                        <span class="tv-chip-active">Active</span>
                                    @else
                                        <span class="tv-chip-draft">Inactive</span>
                                    @endif
                                </td>
                                <td>{{ $package->sort_order }}</td>
                                <td>
                                    <a href="{{ route('trust-verification.packages.edit', $package) }}" class="btn btn-sm tv-btn-secondary">Edit</a>
                                </td>
                            </tr>
                        @empty
                            <tr><td colspan="10" class="text-center text-muted py-4">
                                @if(($filters['q'] ?? '') !== '' || ($filters['city_slug'] ?? '') !== '' || ($filters['type'] ?? '') !== '' || ($filters['is_active'] ?? '') !== '')
                                    No packages match these filters.
                                @else
                                    No packages — run seeder or create one.
                                @endif
                            </td></tr>
                        @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
@endsection
