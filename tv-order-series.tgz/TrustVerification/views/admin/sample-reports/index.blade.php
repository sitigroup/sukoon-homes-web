@extends('layouts.main')

@section('title')
    Trust Verification — Sample Reports
@endsection

@section('content')
    <section class="section tv-admin">
        @include('trust-verification::admin.partials.tv-admin-theme')
        @include('trust-verification::admin.partials.nav')

        <div class="tv-card">
            <div class="tv-card__header">
                <div>
                    <h4 class="tv-page-header__title mb-0">Sample reports</h4>
                    <p class="tv-page-header__meta mb-0 mt-1">Reports → Sample PDFs shown before purchase (fictional data only).</p>
                </div>
                <a href="{{ route('trust-verification.sample-reports.create') }}" class="btn tv-btn-primary">
                    <i class="bi bi-plus-lg"></i> Add sample
                </a>
            </div>
            <div class="tv-card__body">
                @if(session('success'))
                    <div class="alert alert-success">{{ session('success') }}</div>
                @endif
                @if(session('error'))
                    <div class="alert alert-danger">{{ session('error') }}</div>
                @endif

                <div class="tv-help-block mb-3">
                    Upload <strong>PDF only</strong> (max 10 MB). Use tenant and owner samples; optional city/package scopes more specific rows.
                    Button copy is editable under <a href="{{ route('trust-verification.content.index', ['tab' => 'hub']) }}">Content → Hub</a>
                    (<code>sample_report_*</code> keys).
                </div>

                <form method="get" class="tv-filter row g-2 mb-3">
                    <div class="col-md-3">
                        <label class="form-label small text-muted mb-0">Type</label>
                        <select name="report_type" class="form-select form-select-sm">
                            <option value="">All</option>
                            <option value="tenant" @selected(($filters['report_type'] ?? '') === 'tenant')>Tenant</option>
                            <option value="owner" @selected(($filters['report_type'] ?? '') === 'owner')>Owner</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small text-muted mb-0">Status</label>
                        <select name="is_active" class="form-select form-select-sm">
                            <option value="">All</option>
                            <option value="1" @selected(($filters['is_active'] ?? '') === '1')>Active</option>
                            <option value="0" @selected(($filters['is_active'] ?? '') === '0')>Inactive</option>
                        </select>
                    </div>
                    <div class="col-md-3 d-flex align-items-end gap-2">
                        <button type="submit" class="btn tv-btn-primary flex-grow-1">Apply</button>
                        <a href="{{ route('trust-verification.sample-reports.index') }}" class="btn tv-btn-secondary">Reset</a>
                    </div>
                </form>

                <p class="tv-section-label">Included checks (shown in preview modal)</p>
                <ul class="small text-muted mb-3">
                    @foreach($defaultChecks as $check)
                        <li>{{ $check }}</li>
                    @endforeach
                </ul>

                <div class="table-responsive">
                    <table class="table table-striped align-middle mb-0">
                        <thead>
                        <tr>
                            <th>Title</th>
                            <th>Type</th>
                            <th>Scope</th>
                            <th>PDF</th>
                            <th>Status</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                        @forelse($samples as $sample)
                            <tr>
                                <td>
                                    <strong>{{ $sample->title }}</strong>
                                    @if($sample->description)
                                        <br><span class="small text-muted">{{ \Illuminate\Support\Str::limit($sample->description, 80) }}</span>
                                    @endif
                                </td>
                                <td>{{ ucfirst($sample->report_type) }}</td>
                                <td class="small">
                                    @if($sample->city_slug)
                                        {{ $cityCatalog[$sample->city_slug] ?? $sample->city_slug }}
                                    @else
                                        <span class="text-muted">All cities</span>
                                    @endif
                                    <br>
                                    @if($sample->package)
                                        {{ $sample->package->name }}
                                    @else
                                        <span class="text-muted">All packages</span>
                                    @endif
                                </td>
                                <td>
                                    @if($sample->file_path)
                                        <span class="tv-chip-active">Uploaded</span>
                                        <br><span class="small text-muted">{{ number_format(($sample->file_size_bytes ?? 0) / 1024, 1) }} KB</span>
                                    @else
                                        <span class="tv-chip-draft">Missing</span>
                                    @endif
                                </td>
                                <td>
                                    @if($sample->is_active)
                                        <span class="tv-chip-active">Active</span>
                                    @else
                                        <span class="tv-chip-draft">Inactive</span>
                                    @endif
                                </td>
                                <td class="text-nowrap">
                                    @if($sample->file_path)
                                        <a href="{{ route('trust-verification.sample-reports.download', $sample) }}" class="btn btn-sm tv-btn-secondary" target="_blank" rel="noopener">Preview</a>
                                    @endif
                                    <a href="{{ route('trust-verification.sample-reports.edit', $sample) }}" class="btn btn-sm tv-btn-secondary">Edit</a>
                                    <form method="post" action="{{ route('trust-verification.sample-reports.destroy', $sample) }}" class="d-inline" onsubmit="return confirm('Delete this sample report?');">
                                        @csrf
                                        <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" class="text-center text-muted py-4">
                                    No sample reports yet. Add tenant and owner PDFs so customers can preview before purchase.
                                </td>
                            </tr>
                        @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
@endsection
