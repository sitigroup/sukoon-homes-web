@php use Illuminate\Support\Facades\Storage; @endphp
@extends('layouts.main')

@section('title')
    Order {{ $order->order_number }}
@endsection

@section('content')
    <section class="section tv-admin">
        @include('trust-verification::admin.partials.tv-admin-theme')
        @include('trust-verification::admin.partials.nav')

        <a href="{{ route('trust-verification.index') }}" class="tv-link-back">
            <i class="bi bi-arrow-left"></i> All orders
        </a>

        @if(session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif
        @if($errors->any())
            <div class="alert alert-danger">{{ $errors->first() }}</div>
        @endif

        <div class="alert tv-alert-privacy mb-3" role="alert">
            <strong>Privacy reminder:</strong> Handle personal documents carefully. Download only when required.
        </div>

        @if($reportMissingForCompleted ?? false)
            <div class="alert alert-warning border-start border-4 mb-3" role="alert">
                <strong>Report file missing:</strong> This order is completed and paid, but no valid PDF is on disk.
                Upload a report below — customers will see “not available yet” until a PDF is uploaded.
            </div>
        @endif

        <div class="row g-3">
            <div class="col-lg-5">
                <div class="tv-card">
                    <div class="tv-card__header"><strong class="tv-page-header__title">Order summary</strong></div>
                    <div class="tv-card__body">
                        <p><strong>Number:</strong> <code>{{ $order->order_number }}</code></p>
                        <p><strong>Type:</strong> {{ ucfirst($order->order_type) }} verification — {{ $cityLabel }}</p>
                        <p><strong>City:</strong> {{ $cityLabel }} <span class="text-muted">({{ $order->city_slug }})</span></p>
                        <p><strong>Package:</strong> {{ $order->package?->name }} — ₹{{ number_format($order->amount) }}
                            @if($order->package?->delivery_hours)
                                <span class="text-muted">· SLA {{ $order->package->delivery_hours }}h</span>
                            @endif
                        </p>
                        <p><strong>Customer ID:</strong> {{ $order->customer_id ?: '—' }}</p>
                        <p><strong>Requester:</strong> {{ $order->requester_name ?: '—' }}<br>
                            {{ $order->requester_phone ?: '—' }} · {{ $order->requester_email ?: '—' }}</p>
                        @if($order->requester_notes)
                            <p><strong>Notes:</strong> {{ $order->requester_notes }}</p>
                        @endif
                        <hr>
                        <p><strong>Subject:</strong> {{ $order->subject?->full_name }}</p>
                        <p>{{ $order->subject?->phone }} @if($order->subject?->email)· {{ $order->subject->email }}@endif</p>
                        @if($order->subject?->current_address)<p><strong>Current:</strong> {{ $order->subject->current_address }}</p>@endif
                        @if($order->subject?->permanent_address)<p><strong>Permanent:</strong> {{ $order->subject->permanent_address }}</p>@endif
                        @if($order->subject?->property_address)<p><strong>Property:</strong> {{ $order->subject->property_address }}</p>@endif
                        @if($order->subject?->employment_company)<p><strong>Employment:</strong> {{ $order->subject->employment_company }} — {{ $order->subject->employment_role }}</p>@endif
                        @if($order->subject?->id_type)<p><strong>ID:</strong> {{ $order->subject->id_type }} — {{ $order->subject->id_number_hint }}</p>@endif
                        <p><strong>Requester consent (order):</strong>
                            @if($order->consent_given)
                                Yes
                                @if($order->consent_given_at)
                                    <span class="text-muted">({{ $order->consent_given_at->format('d M Y H:i') }})</span>
                                @endif
                                @if($order->legal_version)
                                    <span class="text-muted">· v{{ $order->legal_version }}</span>
                                @endif
                            @else
                                <span class="text-warning">Not recorded (legacy order)</span>
                            @endif
                        </p>
                        @if($order->consent_given && $order->consent_ip)
                            <p class="small text-muted mb-0"><strong>Consent IP:</strong> {{ $order->consent_ip }}</p>
                        @endif
                        @if($order->consent_text)
                            <p class="small text-muted mt-1 mb-0"><strong>Consent text:</strong> {{ $order->consent_text }}</p>
                        @endif
                        <p class="mt-2 mb-0"><strong>Subject consent flag:</strong> {{ $order->subject?->consent_given ? 'Yes' : 'No' }}
                            @if($order->subject?->consent_at)
                                <span class="text-muted">({{ $order->subject->consent_at->format('d M Y H:i') }})</span>
                            @endif
                        </p>
                    </div>
                </div>

                @php
                    use App\Plugins\TrustVerification\Services\TrustVerificationOrderTimestampsService as TvTs;
                    $ts = $orderTimestamps ?? [];
                    $fmt = fn ($iso) => $iso
                        ? TvTs::formatDisplay(\Carbon\Carbon::parse($iso))
                        : 'Not recorded';
                @endphp
                <div class="tv-card mt-3">
                    <div class="tv-card__header"><strong class="tv-page-header__title">Key timestamps</strong>
                        <span class="text-muted small">(Asia/Kolkata)</span>
                    </div>
                    <div class="tv-card__body small">
                        <p><strong>Created at:</strong> {{ $fmt($ts['created_at'] ?? null) }}</p>
                        <p><strong>Consent given at:</strong> {{ $fmt($ts['consent_given_at'] ?? null) }}</p>
                        <p><strong>Payment paid at:</strong> {{ $fmt($ts['paid_at'] ?? null) }}</p>
                        <p><strong>Document uploaded at:</strong> {{ $fmt($ts['document_uploaded_at'] ?? null) }}</p>
                        <p><strong>Automation run:</strong>
                            @if(!empty($ts['automation_started_at']))
                                Started {{ $fmt($ts['automation_started_at']) }}
                                @if(!empty($ts['automation_completed_at']))
                                    · Completed {{ $fmt($ts['automation_completed_at']) }}
                                @else
                                    · <span class="text-muted">In progress / not completed</span>
                                @endif
                            @else
                                Not recorded
                            @endif
                        </p>
                        <p><strong>Report uploaded at:</strong> {{ $fmt($ts['report_uploaded_at'] ?? null) }}</p>
                        <p><strong>Review completed at:</strong> {{ $fmt($ts['review_completed_at'] ?? null) }}</p>
                        <p class="mb-0"><strong>Last updated:</strong> {{ $fmt($ts['updated_at'] ?? null) }}</p>
                    </div>
                </div>

                <div class="tv-card mt-3">
                    <div class="tv-card__header"><strong class="tv-page-header__title">SLA &amp; checks</strong></div>
                    <div class="tv-card__body small">
                        <p><strong>SLA due:</strong> {{ $dueAt ? TvTs::formatDisplay($dueAt) : '—' }}
                            @if($dueAt && $dueAt->isPast() && in_array($order->status, ['submitted', 'in_progress']))
                                <span class="tv-chip-danger">Overdue</span>
                                @if($overdue = TvTs::overdueDuration($order, $dueAt))
                                    <span class="text-danger">({{ $overdue }})</span>
                                @endif
                            @endif
                        </p>
                        <p><strong>Checks:</strong>
                            {{ $checkSummary['pass'] }} pass · {{ $checkSummary['fail'] }} fail ·
                            {{ $checkSummary['pending'] }} pending · {{ $checkSummary['na'] }} n/a
                            ({{ $checkSummary['total'] }} total)
                        </p>
                        @if($order->automation_status)
                            <p class="mb-0"><strong>Automation status:</strong> <span class="tv-chip-neutral">{{ $order->automation_status }}</span></p>
                        @endif
                    </div>
                </div>

                @if(($tvPermissions['update'] ?? false) || ($tvPermissions['payments'] ?? false))
                    <div class="tv-card mt-3">
                        <div class="tv-card__header"><strong class="tv-page-header__title">Status &amp; payment</strong></div>
                        <div class="tv-card__body">
                            @if($tvPermissions['update'] ?? false)
                                <form method="post" action="{{ route('trust-verification.orders.status', $order) }}">
                                    @csrf
                                    <div class="mb-2">
                                        <label class="form-label">Order status</label>
                                        <select name="status" class="form-select">
                                            @foreach(['submitted','in_progress','completed','cancelled'] as $s)
                                                <option value="{{ $s }}" @selected($order->status === $s)>{{ $s }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="mb-2">
                                        <label class="form-label">Admin notes</label>
                                        <textarea name="admin_notes" class="form-control" rows="3">{{ old('admin_notes', $order->admin_notes) }}</textarea>
                                    </div>
                                    <button type="submit" class="btn btn-sm tv-btn-primary">Save status</button>
                                </form>
                            @else
                                <p class="small mb-2"><strong>Order status:</strong> {{ $order->status }}</p>
                                @if($order->admin_notes)
                                    <p class="small text-muted">{{ $order->admin_notes }}</p>
                                @endif
                            @endif

                            @if($tvPermissions['payments'] ?? false)
                                @if($tvPermissions['update'] ?? false)
                                    <hr>
                                @endif
                                <form method="post" action="{{ route('trust-verification.orders.payment', $order) }}">
                                    @csrf
                                    <label class="form-label">Payment (manual v1)</label>
                                    <div class="input-group">
                                        <select name="payment_status" class="form-select">
                                            @foreach(['pending','paid','waived'] as $p)
                                                <option value="{{ $p }}" @selected($order->payment_status === $p)>{{ $p }}</option>
                                            @endforeach
                                        </select>
                                        <button type="submit" class="btn tv-btn-secondary">Update</button>
                                    </div>
                                </form>
                            @elseif($tvPermissions['update'] ?? false)
                                <hr>
                                <p class="small mb-0"><strong>Payment:</strong> {{ $order->payment_status }}</p>
                            @endif
                        </div>
                    </div>
                @endif

                @include('trust-verification::admin.partials.order-documents-automation')

            </div>

            <div class="col-lg-7">
                <div class="tv-card">
                    <div class="tv-card__header"><strong class="tv-page-header__title">Verification checks</strong></div>
                    <div class="tv-card__body">
                        @if(!($tvPermissions['update'] ?? false))
                            @include('trust-verification::admin.partials.permission-denied')
                        @else
                        <form method="post" action="{{ route('trust-verification.orders.checks', $order) }}">
                            @csrf
                            <table class="table table-sm">
                                <thead><tr><th>Check</th><th>Status</th><th>Notes</th></tr></thead>
                                <tbody>
                                @foreach($order->checkItems as $item)
                                    <tr>
                                        <td>{{ $item->label }}</td>
                                        <td>
                                            <select name="checks[{{ $item->id }}][status]" class="form-select form-select-sm">
                                                @foreach($checkStatuses as $st)
                                                    <option value="{{ $st }}" @selected($item->status === $st)>{{ $st }}</option>
                                                @endforeach
                                            </select>
                                        </td>
                                        <td>
                                            <input type="text" name="checks[{{ $item->id }}][notes]" class="form-control form-control-sm" value="{{ $item->notes }}">
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                            <button type="submit" class="btn btn-sm tv-btn-primary">Save checks</button>
                        </form>
                        @endif
                    </div>
                </div>

                @include('trust-verification::admin.partials.reference-check-panel')

                @if($tvPermissions['reports'] ?? false)
                <div class="tv-card mt-3">
                    <div class="tv-card__header d-flex justify-content-between align-items-center flex-wrap gap-2">
                        <strong class="tv-page-header__title">Report (PDF)</strong>
                        @if($hasReportFile)
                            <form method="post" action="{{ route('trust-verification.orders.report.delete', $order) }}"
                                  onsubmit="return confirm('Delete the verification report PDF for this order? The order record, payments, and audit history will be kept.');">
                                @csrf
                                <button type="submit" class="btn btn-sm btn-outline-danger">Delete report</button>
                            </form>
                        @elseif($order->report?->deleted_at)
                            <span class="tv-chip-draft">File removed {{ $order->report->deleted_at->format('d M Y') }}</span>
                        @endif
                    </div>
                    <div class="tv-card__body">
                        @if($hasReportFile)
                            <p>
                                <a href="{{ route('trust-verification.orders.report.download', $order) }}" class="btn btn-sm tv-btn-primary">Download current report</a>
                            </p>
                            @if($order->report?->risk_level)
                                <p class="small">Risk level: <strong>{{ $order->report->risk_level }}</strong></p>
                            @endif
                        @elseif($order->report)
                            <p class="small text-muted mb-2">Report metadata is kept; PDF file was removed.</p>
                            @if($order->report->risk_level)
                                <p class="small">Risk level: <strong>{{ $order->report->risk_level }}</strong></p>
                            @endif
                        @endif
                        <form method="post" action="{{ route('trust-verification.orders.report', $order) }}" enctype="multipart/form-data">
                            @csrf
                            <div class="mb-2">
                                <label class="form-label">Upload PDF</label>
                                <input type="file" name="report_file" accept="application/pdf" class="form-control">
                            </div>
                            @if(!empty($riskSuggestion['level']))
                                <div class="alert alert-light border small py-2 mb-2">
                                    <strong>Suggested risk:</strong> {{ $riskSuggestion['level'] }}
                                    <span class="text-muted">— {{ $riskSuggestion['reason'] }}</span>
                                </div>
                            @elseif(!empty($riskSuggestion['reason']))
                                <p class="text-muted small mb-2">{{ $riskSuggestion['reason'] }}</p>
                            @endif
                            <div class="mb-2">
                                <label class="form-label">Risk level</label>
                                <select name="risk_level" class="form-select">
                                    <option value="">Auto (from checks)</option>
                                    @foreach($riskLevels as $r)
                                        <option value="{{ $r }}" @selected($order->report?->risk_level === $r || (empty($order->report?->risk_level) && ($riskSuggestion['level'] ?? '') === $r))>{{ $r }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Summary</label>
                                <textarea name="summary" class="form-control" rows="4" placeholder="Auto-generated summary available if left blank">{{ old('summary', $order->report?->summary ?: $riskSummaryDraft) }}</textarea>
                            </div>
                            <button type="submit" class="btn tv-btn-primary">Save report</button>
                        </form>
                    </div>
                </div>
                @endif
            </div>
        </div>

        @if($tvPermissions['audit'] ?? false)
        <div class="tv-card mt-4">
            <div class="tv-card__header"><strong class="tv-page-header__title">Audit History</strong></div>
            <div class="tv-card__body tv-card__body--flush">
                @if($auditLogs->isEmpty())
                    <p class="text-muted small p-3 mb-0">No audit events recorded yet.</p>
                @else
                    <div class="table-responsive">
                        <table class="table table-sm table-striped mb-0">
                            <thead>
                                <tr>
                                    <th>Date / time</th>
                                    <th>User</th>
                                    <th>Action</th>
                                    <th>Description</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($auditLogs as $log)
                                    <tr>
                                        <td class="text-nowrap small">{{ $log->created_at?->format('d M Y H:i') ?? '—' }}</td>
                                        <td class="small">{{ $log->actorLabel() }}</td>
                                        <td class="small"><code>{{ $log->action }}</code></td>
                                        <td class="small">{{ $log->description ?: '—' }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @endif
            </div>
        </div>
        @endif
    </section>
@endsection
