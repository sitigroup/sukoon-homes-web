<style>
    /* Trust Verification — shared admin design system */
    :root {
        --tv-graphite: #1F2937;
        --tv-graphite-hover: #111827;
        --tv-gold: #B89A4A;
        --tv-gold-soft: rgba(184, 154, 74, 0.12);
        --tv-bg: #FFFFFF;
        --tv-section: #F8F9FA;
        --tv-border: #E5E7EB;
        --tv-border-strong: #D1D5DB;
        --tv-muted: #6B7280;
        --tv-shadow: 0 4px 24px rgba(31, 41, 55, 0.06);
        --tv-shadow-sm: 0 1px 3px rgba(31, 41, 55, 0.06);
        --tv-shadow-btn: 0 2px 8px rgba(31, 41, 55, 0.1);
        --tv-radius: 14px;
    }

    .tv-admin {
        color: var(--tv-graphite);
    }
    .tv-admin .text-muted {
        color: var(--tv-muted) !important;
    }
    .tv-admin .card:not(.tv-card) {
        border-radius: var(--tv-radius);
        border-color: var(--tv-border);
        box-shadow: var(--tv-shadow-sm);
    }
    .tv-admin .card-header {
        background: var(--tv-bg);
        border-bottom-color: var(--tv-border);
    }

    /* Page header */
    .tv-page-header {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        align-items: flex-start;
        gap: 0.75rem;
        margin-bottom: 1rem;
    }
    .tv-page-header__title {
        margin: 0;
        font-size: 1.25rem;
        font-weight: 700;
        color: var(--tv-graphite);
    }
    .tv-page-header__meta {
        font-size: 0.8125rem;
        color: var(--tv-muted);
    }

    /* Main nav tabs */
    .tv-tab-nav {
        display: flex;
        flex-wrap: wrap;
        gap: 0.4rem;
        margin-bottom: 1.25rem;
        padding-bottom: 0.25rem;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }
    .tv-tab {
        display: inline-flex;
        align-items: center;
        gap: 0.35rem;
        padding: 0.45rem 0.9rem;
        border-radius: 10px;
        font-size: 0.8125rem;
        font-weight: 600;
        text-decoration: none;
        white-space: nowrap;
        border: 1px solid var(--tv-graphite);
        background: var(--tv-bg);
        color: var(--tv-graphite);
        transition: background 0.15s, color 0.15s, border-color 0.15s, box-shadow 0.15s;
    }
    .tv-tab:hover {
        background: var(--tv-section);
        color: var(--tv-graphite-hover);
    }
    .tv-tab.is-active {
        background: var(--tv-graphite);
        border-color: var(--tv-graphite);
        color: #ffffff;
        box-shadow: var(--tv-shadow-btn);
    }
    .tv-tab.is-active .bi {
        color: rgba(255, 255, 255, 0.9);
    }
    .tv-tab .bi {
        font-size: 0.9rem;
        color: var(--tv-muted);
    }

    /* Buttons */
    .tv-btn-primary,
    .tv-cms-btn--primary,
    .tv-admin .btn.tv-btn-primary {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 0.35rem;
        border-radius: 10px;
        font-size: 0.8125rem;
        font-weight: 600;
        padding: 0.4rem 0.85rem;
        background: var(--tv-graphite) !important;
        border: 1px solid var(--tv-graphite) !important;
        color: #ffffff !important;
        box-shadow: var(--tv-shadow-btn);
        transition: background 0.15s, border-color 0.15s, box-shadow 0.15s;
    }
    .tv-btn-primary:hover,
    .tv-cms-btn--primary:hover,
    .tv-admin .btn.tv-btn-primary:hover {
        background: var(--tv-graphite-hover) !important;
        border-color: var(--tv-graphite-hover) !important;
        color: #ffffff !important;
        box-shadow: 0 4px 12px rgba(31, 41, 55, 0.14);
    }

    .tv-btn-secondary,
    .tv-cms-btn--secondary,
    .tv-cms-btn--outline,
    .tv-admin .btn.tv-btn-secondary {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 0.35rem;
        border-radius: 10px;
        font-size: 0.8125rem;
        font-weight: 600;
        padding: 0.4rem 0.85rem;
        background: var(--tv-section) !important;
        border: 1px solid var(--tv-border-strong) !important;
        color: var(--tv-graphite) !important;
        box-shadow: none;
        transition: background 0.15s, border-color 0.15s;
    }
    .tv-btn-secondary:hover,
    .tv-cms-btn--secondary:hover,
    .tv-cms-btn--outline:hover,
    .tv-admin .btn.tv-btn-secondary:hover {
        background: var(--tv-bg) !important;
        border-color: var(--tv-border-strong) !important;
        color: var(--tv-graphite-hover) !important;
    }

    /* Cards */
    .tv-card {
        background: var(--tv-bg);
        border: 1px solid var(--tv-border);
        border-radius: var(--tv-radius);
        box-shadow: var(--tv-shadow-sm);
        overflow: hidden;
    }
    .tv-card__header {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        align-items: center;
        gap: 0.5rem;
        padding: 0.85rem 1.15rem;
        border-bottom: 1px solid var(--tv-border);
        background: var(--tv-bg);
    }
    .tv-card__header strong,
    .tv-card__header .tv-page-header__title {
        font-size: 1rem;
        font-weight: 600;
        color: var(--tv-graphite);
    }
    .tv-card__body {
        padding: 1rem 1.15rem;
    }
    .tv-card__body--flush {
        padding: 0;
    }

    /* KPI */
    .tv-kpi {
        display: block;
        background: var(--tv-bg);
        border: 1px solid var(--tv-border);
        border-radius: var(--tv-radius);
        box-shadow: var(--tv-shadow-sm);
        padding: 1rem 1.1rem;
        height: 100%;
        text-decoration: none;
        color: inherit;
        transition: border-color 0.15s, box-shadow 0.15s;
    }
    a.tv-kpi:hover {
        border-color: var(--tv-border-strong);
        box-shadow: var(--tv-shadow);
        color: inherit;
    }
    .tv-kpi__label {
        font-size: 0.72rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--tv-muted);
        margin-bottom: 0.35rem;
    }
    .tv-kpi__value {
        font-size: 1.5rem;
        font-weight: 700;
        line-height: 1.1;
        color: var(--tv-graphite);
    }
    .tv-kpi--warning { border-color: rgba(217, 119, 6, 0.35); }
    .tv-kpi--warning .tv-kpi__value { color: #D97706; }
    .tv-kpi--danger { border-color: rgba(220, 38, 38, 0.35); }
    .tv-kpi--danger .tv-kpi__value { color: #DC2626; }
    .tv-kpi--success .tv-kpi__value { color: #059669; }
    .tv-kpi--info .tv-kpi__value { color: #2563EB; }

    /* Filters */
    .tv-filter {
        background: var(--tv-section);
        border: 1px solid var(--tv-border);
        border-radius: var(--tv-radius);
        padding: 1rem;
        margin-bottom: 1rem;
    }
    .tv-filter--chips {
        padding: 0.75rem 1rem;
    }
    .tv-quick-filters {
        display: flex;
        flex-wrap: wrap;
        gap: 0.35rem;
        align-items: center;
        margin-bottom: 1rem;
    }
    .tv-quick-filters__label {
        font-size: 0.75rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.04em;
        color: var(--tv-muted);
        margin-right: 0.25rem;
    }
    .tv-chip-filter {
        display: inline-flex;
        align-items: center;
        padding: 0.3rem 0.65rem;
        border-radius: 999px;
        font-size: 0.75rem;
        font-weight: 600;
        text-decoration: none;
        border: 1px solid var(--tv-border-strong);
        background: var(--tv-bg);
        color: var(--tv-graphite);
        transition: background 0.15s, border-color 0.15s, color 0.15s;
    }
    .tv-chip-filter:hover {
        background: var(--tv-section);
        color: var(--tv-graphite-hover);
    }
    .tv-chip-filter.is-active {
        background: var(--tv-graphite);
        border-color: var(--tv-graphite);
        color: #ffffff;
    }

    /* Status chips */
    .tv-chip,
    .tv-chip-active,
    .tv-chip-draft,
    .tv-chip-warning,
    .tv-chip-danger,
    .tv-chip-info,
    .tv-chip-neutral {
        display: inline-flex;
        align-items: center;
        padding: 0.15rem 0.5rem;
        border-radius: 999px;
        font-size: 0.68rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.03em;
        line-height: 1.3;
    }
    .tv-chip-active {
        background: rgba(5, 150, 105, 0.12);
        color: #059669;
    }
    .tv-chip-draft,
    .tv-chip-neutral {
        background: rgba(107, 114, 128, 0.12);
        color: #6B7280;
    }
    .tv-chip-warning {
        background: rgba(217, 119, 6, 0.12);
        color: #D97706;
    }
    .tv-chip-danger {
        background: rgba(220, 38, 38, 0.12);
        color: #DC2626;
    }
    .tv-chip-info {
        background: rgba(37, 99, 235, 0.1);
        color: #2563EB;
    }
    .tv-chip-gold {
        background: var(--tv-gold-soft);
        color: #8F7840;
        border: 1px solid rgba(184, 154, 74, 0.25);
    }

    .tv-price-badge {
        display: inline-block;
        font-weight: 700;
        color: var(--tv-graphite);
    }
    .tv-price-badge small {
        font-weight: 500;
        color: var(--tv-muted);
    }

    /* Tables */
    .tv-admin .table {
        --bs-table-striped-bg: rgba(248, 249, 250, 0.65);
        font-size: 0.875rem;
    }
    .tv-admin .table thead th {
        font-size: 0.7rem;
        text-transform: uppercase;
        letter-spacing: 0.04em;
        color: var(--tv-muted);
        font-weight: 600;
        border-bottom-color: var(--tv-border-strong);
        white-space: nowrap;
    }
    .tv-admin .table tbody tr:hover {
        background: rgba(248, 249, 250, 0.85);
    }
    .tv-admin .table-warning {
        --bs-table-bg: rgba(217, 119, 6, 0.08);
    }

    /* Help / info blocks */
    .tv-help-block {
        background: var(--tv-section);
        border: 1px solid var(--tv-border);
        border-left: 3px solid var(--tv-gold);
        border-radius: 10px;
        padding: 0.75rem 1rem;
        font-size: 0.8125rem;
        color: var(--tv-muted);
        margin-bottom: 1rem;
    }
    .tv-help-block code {
        color: var(--tv-graphite);
        font-size: 0.75rem;
    }

    .tv-section-label {
        font-size: 0.7rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.06em;
        color: var(--tv-muted);
        margin: 1rem 0 0.5rem;
    }

    .tv-link-back {
        display: inline-flex;
        align-items: center;
        gap: 0.25rem;
        font-size: 0.8125rem;
        color: var(--tv-graphite);
        text-decoration: none;
        margin-bottom: 0.75rem;
    }
    .tv-link-back:hover {
        color: var(--tv-graphite-hover);
        text-decoration: underline;
    }

    .tv-alert-privacy {
        border-left: 4px solid var(--tv-gold);
        background: var(--tv-gold-soft);
        border-radius: 10px;
    }

    @media (max-width: 767.98px) {
        .tv-kpi__value { font-size: 1.25rem; }
        .tv-tab-nav { flex-wrap: nowrap; }
    }
</style>
