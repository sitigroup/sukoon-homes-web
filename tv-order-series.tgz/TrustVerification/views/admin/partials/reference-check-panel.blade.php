@if($hasReferenceCheck ?? false)
<div class="tv-card mt-3">
    <div class="tv-card__header d-flex justify-content-between align-items-center flex-wrap gap-2">
        <strong class="tv-page-header__title">Reference check</strong>
        @if(!empty($referenceProgress['summary']))
            <span class="tv-chip-draft">{{ $referenceProgress['summary'] }}</span>
        @endif
    </div>
    <div class="tv-card__body">
        @if(!($tvPermissions['update'] ?? false))
            @include('trust-verification::admin.partials.permission-denied')
        @else
            @php
                use App\Plugins\TrustVerification\Services\TrustVerificationOrderTimestampsService as TvRefTs;
                $fmtRef = fn ($dt) => $dt ? TvRefTs::formatDisplay($dt) : '—';
            @endphp

            @forelse($order->referenceContacts as $ref)
                <div class="border rounded p-3 mb-3 bg-light">
                    <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-2">
                        <div>
                            <strong>{{ $referenceTypes[$ref->reference_type] ?? $ref->reference_type }}</strong>
                            <span class="text-muted">· {{ $ref->name }}</span>
                            @if($ref->relation)
                                <span class="text-muted small">({{ $ref->relation }})</span>
                            @endif
                        </div>
                        <span class="badge bg-secondary text-uppercase">{{ $referenceStatuses[$ref->status] ?? $ref->status }}</span>
                    </div>
                    <p class="small mb-2 text-muted">
                        {{ $ref->mobile }}
                        @if($ref->email) · {{ $ref->email }} @endif
                    </p>
                    @if($ref->notes)
                        <p class="small mb-2"><strong>Customer notes:</strong> {{ $ref->notes }}</p>
                    @endif
                    <p class="small text-muted mb-2">
                        Contacted: {{ $fmtRef($ref->contacted_at) }}
                        · Verified: {{ $fmtRef($ref->verified_at) }}
                        · Last update: {{ $fmtRef($ref->last_status_at) }}
                    </p>

                    <form method="post" action="{{ route('trust-verification.orders.references.update', [$order, $ref]) }}" class="mt-2">
                        @csrf
                        <div class="row g-2">
                            <div class="col-md-3">
                                <label class="form-label small mb-0">Status</label>
                                <select name="status" class="form-select form-select-sm">
                                    @foreach($referenceStatuses as $key => $label)
                                        <option value="{{ $key }}" @selected($ref->status === $key)>{{ $label }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label small mb-0">Contacted at</label>
                                <input type="datetime-local" name="contacted_at" class="form-control form-control-sm"
                                       value="{{ $ref->contacted_at ? $ref->contacted_at->format('Y-m-d\TH:i') : '' }}">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label small mb-0">Verified at</label>
                                <input type="datetime-local" name="verified_at" class="form-control form-control-sm"
                                       value="{{ $ref->verified_at ? $ref->verified_at->format('Y-m-d\TH:i') : '' }}">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label small mb-0">External ref ID</label>
                                <input type="text" name="external_ref_id" class="form-control form-control-sm"
                                       value="{{ $ref->external_ref_id }}" placeholder="Future API ID">
                            </div>
                            <div class="col-12">
                                <label class="form-label small mb-0">Call outcome</label>
                                <input type="text" name="call_outcome" class="form-control form-control-sm"
                                       value="{{ $ref->call_outcome }}" placeholder="Spoke with reference, confirmed tenancy…">
                            </div>
                            <div class="col-12">
                                <label class="form-label small mb-0">Internal admin notes</label>
                                <textarea name="admin_notes" class="form-control form-control-sm" rows="2">{{ $ref->admin_notes }}</textarea>
                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn btn-sm tv-btn-primary">Save reference</button>
                            </div>
                        </div>
                    </form>
                </div>
            @empty
                <p class="text-muted small mb-3">No reference contacts submitted yet.</p>
            @endforelse

            <hr>
            <p class="small fw-semibold mb-2">Add reference contact (admin)</p>
            <form method="post" action="{{ route('trust-verification.orders.references.store', $order) }}">
                @csrf
                <div class="row g-2">
                    <div class="col-md-4">
                        <label class="form-label small mb-0">Type</label>
                        <select name="reference_type" class="form-select form-select-sm" required>
                            @foreach($referenceTypes as $key => $label)
                                <option value="{{ $key }}">{{ $label }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small mb-0">Name</label>
                        <input type="text" name="name" class="form-control form-control-sm" required maxlength="120">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small mb-0">Relation</label>
                        <input type="text" name="relation" class="form-control form-control-sm" maxlength="80" placeholder="Landlord, Manager…">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small mb-0">Mobile</label>
                        <input type="text" name="mobile" class="form-control form-control-sm" required maxlength="20">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small mb-0">Email</label>
                        <input type="email" name="email" class="form-control form-control-sm" maxlength="190">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small mb-0">Customer notes</label>
                        <input type="text" name="notes" class="form-control form-control-sm" maxlength="2000">
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn btn-sm btn-outline-secondary">Add reference</button>
                    </div>
                </div>
            </form>
        @endif
    </div>
</div>
@endif
