﻿@if($tvPermissions['documents'] ?? false)
    <div class="tv-card mt-3">
        <div class="tv-card__header d-flex justify-content-between align-items-center flex-wrap gap-2">
            <strong class="tv-page-header__title">Uploaded documents</strong>
            <div class="d-flex align-items-center gap-2">
                <span class="tv-chip-neutral">{{ $order->documents->count() }}</span>
                @if($hasActiveDocuments ?? false)
                    <form method="post" action="{{ route('trust-verification.orders.documents.delete', $order) }}"
                          onsubmit="return confirm('Delete all uploaded document files for this order? The order record, payments, and audit history will be kept.');">
                        @csrf
                        <button type="submit" class="btn btn-sm btn-outline-danger">Delete documents</button>
                    </form>
                @endif
            </div>
        </div>
        <div class="tv-card__body">
            @forelse($order->documents as $doc)
                @php
                    $fileAvailable = \App\Plugins\TrustVerification\Services\TrustVerificationPiiRetentionService::documentFileAvailable($doc);
                @endphp
                <div class="d-flex justify-content-between align-items-center border-bottom py-2">
                    <div>
                        <strong>{{ $documentTypes[$doc->doc_type] ?? $doc->doc_type }}</strong><br>
                        @php
                            $safeName = \App\Plugins\TrustVerification\Services\TrustVerificationDocumentUploadValidator::sanitizeDisplayFilename($doc->original_name);
                            $mimeLabel = strtoupper(str_replace('image/', '', (string) $doc->mime_type));
                        @endphp
                        <span class="small text-muted">{{ $safeName }} · {{ $mimeLabel }} · {{ number_format($doc->size_bytes / 1024, 1) }} KB</span>
                        @if($doc->deleted_at)
                            <br><span class="tv-chip-draft">File removed {{ $doc->deleted_at->format('d M Y') }}</span>
                        @endif
                    </div>
                    @if($fileAvailable)
                        <a href="{{ route('trust-verification.orders.documents.download', [$order, $doc]) }}" class="btn btn-sm tv-btn-secondary">Download</a>
                    @else
                        <span class="small text-muted">Unavailable</span>
                    @endif
                </div>
            @empty
                <p class="text-muted small mb-0">No documents uploaded yet.</p>
            @endforelse
        </div>
    </div>
@endif

@if($tvPermissions['update'] ?? false)
    <div class="tv-card mt-3">
        <div class="tv-card__header d-flex justify-content-between align-items-center">
            <strong class="tv-page-header__title">Automation</strong>
            @if($automationSettings['automation_enabled'] ?? false)
                <form method="post" action="{{ route('trust-verification.orders.automation.run', $order) }}" class="m-0">
                    @csrf
                    <button type="submit" class="btn btn-sm tv-btn-primary">Run now</button>
                </form>
            @endif
        </div>
        <div class="tv-card__body small">
            @if(!($automationSettings['automation_enabled'] ?? false))
                <p class="text-muted mb-0">Automation is disabled — enable under <a href="{{ route('trust-verification.automation.index') }}">Automation</a>.</p>
            @else
                <p class="mb-2">Provider: <strong>{{ $automationSettings['providers'][$automationSettings['automation_provider'] ?? 'rules'] ?? 'rules' }}</strong></p>
                @if($order->automationRuns->isEmpty())
                    <p class="text-muted mb-0">No runs yet.</p>
                @else
                    <ul class="list-unstyled mb-0">
                        @foreach($order->automationRuns->take(5) as $run)
                            <li class="mb-1">
                                {{ $run->created_at?->format('d M H:i') }} · {{ $run->provider }} ·
                                @if($run->status === 'completed')<span class="tv-chip-active">ok</span>@elseif($run->status === 'failed')<span class="tv-chip-danger" title="{{ $run->error_message }}">failed</span>@else<span class="tv-chip-neutral">{{ $run->status }}</span>@endif
                                · {{ $run->checks_updated }} checks
                            </li>
                        @endforeach
                    </ul>
                @endif
            @endif
        </div>
    </div>
@endif
