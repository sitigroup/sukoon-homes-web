@extends('layouts.main')

@section('title')
    Trust Verification Cities
@endsection

@section('content')
    <section class="section tv-admin">
        @include('trust-verification::admin.partials.tv-admin-theme')
        @include('trust-verification::admin.partials.nav')

        <div class="row g-3">
            <div class="col-lg-7">
                <div class="tv-card">
                    <div class="tv-card__header">
                        <strong class="tv-page-header__title">Cities</strong>
                        <span class="tv-page-header__meta">{{ $cities->count() }} shown</span>
                    </div>
                    <div class="tv-card__body">
                        @if(session('success'))
                            <div class="alert alert-success">{{ session('success') }}</div>
                        @endif
                        @if(session('error'))
                            <div class="alert alert-danger">{{ session('error') }}</div>
                        @endif

                        <div class="tv-help-block mb-3">
                            Only <strong>enabled</strong> cities appear on the web/API. Add packages for a city before enabling it.
                        </div>

                        <form method="get" class="tv-filter row g-2">
                            <div class="col-md-5">
                                <label class="form-label small mb-0 text-muted">Search</label>
                                <input type="text" name="q" class="form-control form-control-sm" placeholder="Name or slug"
                                       value="{{ $filters['q'] ?? '' }}">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label small mb-0 text-muted">Status</label>
                                <select name="is_enabled" class="form-select form-select-sm">
                                    <option value="">All</option>
                                    <option value="1" @selected(($filters['is_enabled'] ?? '') === '1')>Enabled</option>
                                    <option value="0" @selected(($filters['is_enabled'] ?? '') === '0')>Disabled</option>
                                </select>
                            </div>
                            <div class="col-md-4 d-flex align-items-end gap-2">
                                <button type="submit" class="btn tv-btn-primary flex-grow-1">Apply</button>
                                <a href="{{ route('trust-verification.cities.index') }}" class="btn tv-btn-secondary">Reset</a>
                            </div>
                        </form>

                        <div class="table-responsive">
                            <table class="table table-striped align-middle mb-0">
                                <thead>
                                <tr>
                                    <th>City</th>
                                    <th>Slug</th>
                                    <th>Packages</th>
                                    <th>Sort</th>
                                    <th>Status</th>
                                    <th></th>
                                </tr>
                                </thead>
                                <tbody>
                                @forelse($cities as $city)
                                    <tr>
                                        <td>
                                            <form method="post" action="{{ route('trust-verification.cities.update', $city) }}" class="d-flex gap-2 align-items-center">
                                                @csrf
                                                @method('PUT')
                                                <input type="text" name="label" class="form-control form-control-sm" value="{{ $city->label }}" required>
                                                <input type="hidden" name="sort_order" value="{{ $city->sort_order }}">
                                                <input type="hidden" name="is_enabled" value="{{ $city->is_enabled ? '1' : '0' }}">
                                                <button type="submit" class="btn btn-sm tv-btn-secondary">Save</button>
                                            </form>
                                        </td>
                                        <td><code class="small">{{ $city->slug }}</code></td>
                                        <td>{{ $city->packages_count }}</td>
                                        <td>{{ $city->sort_order }}</td>
                                        <td>
                                            @if($city->is_enabled)
                                                <span class="tv-chip-active">Enabled</span>
                                            @else
                                                <span class="tv-chip-draft">Disabled</span>
                                            @endif
                                        </td>
                                        <td>
                                            <form method="post" action="{{ route('trust-verification.cities.toggle', $city) }}" class="d-inline">
                                                @csrf
                                                <button type="submit" class="btn btn-sm tv-btn-secondary">
                                                    {{ $city->is_enabled ? 'Disable' : 'Enable' }}
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                @empty
                                    <tr><td colspan="6" class="text-center text-muted py-4">
                                        @if(($filters['q'] ?? '') !== '' || ($filters['is_enabled'] ?? '') !== '')
                                            No cities match these filters.
                                        @else
                                            No cities — migration may be pending.
                                        @endif
                                    </td></tr>
                                @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-5">
                <div class="tv-card">
                    <div class="tv-card__header">
                        <strong class="tv-page-header__title">Add city</strong>
                    </div>
                    <div class="tv-card__body">
                        <form method="post" action="{{ route('trust-verification.cities.store') }}">
                            @csrf
                            <div class="mb-2">
                                <label class="form-label">Display name</label>
                                <input type="text" name="label" class="form-control" placeholder="Jodhpur" required maxlength="120">
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Slug (optional)</label>
                                <input type="text" name="slug" class="form-control" placeholder="jodhpur" maxlength="80">
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Sort order</label>
                                <input type="number" name="sort_order" class="form-control" value="10" min="0" max="999">
                            </div>
                            <div class="form-check mb-3">
                                <input type="checkbox" name="is_enabled" value="1" class="form-check-input" id="city_enabled">
                                <label class="form-check-label" for="city_enabled">Enable on web immediately</label>
                            </div>
                            <button type="submit" class="btn tv-btn-primary">Add city</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
