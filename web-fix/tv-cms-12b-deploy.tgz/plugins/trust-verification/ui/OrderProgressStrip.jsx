"use client";

import { cn, tv } from "./trustVerificationTheme";

const DOT = {
  complete: "bg-[#D4AF37] border-[#D4AF37] text-[#111827]",
  current:
    "bg-[#FFFFFF] border-[#D4AF37] text-[#D4AF37] ring-2 ring-[rgba(212,175,55,0.2)]",
  upcoming: "bg-[#F8F9FA] border-[#E5E7EB] text-[#9CA3AF]",
};

/** Compact one-line progress (used on My orders — avoids repeating full vertical timelines). */
export default function OrderProgressStrip({ steps = [], className = "" }) {
  const current = steps.find((s) => s.status === "current");

  return (
    <div className={cn("rounded-[12px] border border-[#E5E7EB] bg-[#F8F9FA] p-3", className)}>
      <div className="flex items-center justify-between gap-2">
        {steps.map((step, index) => (
          <div key={step.id} className="flex min-w-0 flex-1 items-center">
            <span
              className={cn(
                "flex h-6 w-6 shrink-0 items-center justify-center rounded-full border text-[10px] font-bold",
                DOT[step.status] || DOT.upcoming
              )}
              title={step.label}
            >
              {step.status === "complete" ? "✓" : index + 1}
            </span>
            {index < steps.length - 1 && (
              <span
                className={cn(
                  "mx-1 h-0.5 flex-1 rounded",
                  step.status === "complete" ? "bg-[#D4AF37]/50" : "bg-[#E5E7EB]"
                )}
                aria-hidden
              />
            )}
          </div>
        ))}
      </div>
      {current && (
        <p className="mt-2 text-xs font-medium text-[#111827]">
          Current step: <span className="text-[#B8962E]">{current.label}</span>
        </p>
      )}
    </div>
  );
}
