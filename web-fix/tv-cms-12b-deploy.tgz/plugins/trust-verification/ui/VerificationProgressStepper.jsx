"use client";

import { cn, tv } from "./trustVerificationTheme";

const LABELS = ["Package", "Details", "Review", "Pay", "Done"];

export default function VerificationProgressStepper({
  currentStep = 1,
  totalSteps = 4,
  labels = LABELS,
  className = "",
}) {
  const steps = labels.slice(0, totalSteps);

  return (
    <div className={cn("mb-6", className)}>
      <div className="flex gap-1">
        {steps.map((_, i) => {
          const n = i + 1;
          const active = n <= currentStep;
          return (
            <div
              key={n}
              className={cn(
                "h-1 flex-1 rounded-full transition-colors",
                active ? "bg-[#D4AF37]" : "bg-[#E5E7EB]"
              )}
            />
          );
        })}
      </div>
      <div className="mt-2 hidden justify-between text-[10px] text-[#9CA3AF] sm:flex">
        {steps.map((label, i) => (
          <span key={label} className={i + 1 <= currentStep ? "text-[#D4AF37] font-medium" : ""}>
            {label}
          </span>
        ))}
      </div>
      <p className={cn(tv.muted, "mt-1 sm:hidden")}>
        Step {Math.min(currentStep, totalSteps)} of {totalSteps}
      </p>
    </div>
  );
}
