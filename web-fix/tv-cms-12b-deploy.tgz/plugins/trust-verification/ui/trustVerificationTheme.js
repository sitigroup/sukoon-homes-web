/**
 * Sukoon Trust Verification — light premium UI tokens (plugin-only).
 * Matches Sukoon Homes site: white surfaces, gray text, gold accent only.
 */

export const tvColors = {
  bg: {
    base: "#FFFFFF",
    elevated: "#F8F9FA",
    surface: "#FFFFFF",
    surfaceHover: "#F3F4F6",
  },
  text: {
    primary: "#111827",
    muted: "#6B7280",
    dim: "#9CA3AF",
  },
  accent: "#D4AF37",
  accentMuted: "rgba(212, 175, 55, 0.12)",
  accentBorder: "rgba(212, 175, 55, 0.45)",
  border: "#E5E7EB",
  borderStrong: "#D1D5DB",
  success: "#059669",
  warning: "#D97706",
  danger: "#DC2626",
};

export const tvRadius = "16px";
export const tvShadow = "0 4px 20px rgba(0, 0, 0, 0.06)";
export const tvShadowAccent = "0 4px 20px rgba(212, 175, 55, 0.15), 0 0 0 1px rgba(212, 175, 55, 0.2)";

/** Tailwind class bundles (included when src/plugins is in Tailwind content) */
export const tv = {
  page: "min-h-[50vh] bg-[#FFFFFF] text-[#111827]",
  section: "mx-auto w-full max-w-[1180px] px-4 py-6 sm:px-6 sm:py-8 lg:px-8",
  card: "rounded-[16px] border border-[#E5E7EB] bg-[#FFFFFF] shadow-[0_4px_20px_rgba(0,0,0,0.06)]",
  cardHover:
    "transition duration-200 hover:border-[rgba(212,175,55,0.4)] hover:bg-[#F3F4F6] hover:shadow-[0_8px_24px_rgba(0,0,0,0.08)]",
  heading: "text-[#111827] font-semibold tracking-tight",
  subheading: "text-[#6B7280]",
  muted: "text-[#6B7280] text-sm",
  accent: "text-[#D4AF37]",
  btnPrimary:
    "inline-flex items-center justify-center rounded-[16px] bg-[#D4AF37] px-5 py-3 text-sm font-semibold text-[#111827] transition hover:brightness-105 disabled:opacity-50 shadow-sm",
  btnSecondary:
    "inline-flex items-center justify-center rounded-[16px] border border-[#E5E7EB] bg-[#FFFFFF] px-5 py-3 text-sm font-medium text-[#111827] transition hover:border-[rgba(212,175,55,0.45)] hover:bg-[#F3F4F6]",
  btnGhost:
    "inline-flex items-center justify-center rounded-[16px] px-4 py-2 text-sm font-medium text-[#6B7280] transition hover:bg-[#F3F4F6] hover:text-[#111827]",
  input:
    "w-full rounded-[12px] border border-[#E5E7EB] bg-[#FFFFFF] px-3 py-2.5 text-sm text-[#111827] placeholder:text-[#9CA3AF] outline-none focus:border-[rgba(212,175,55,0.55)] focus:ring-1 focus:ring-[rgba(212,175,55,0.2)]",
  badge:
    "inline-flex items-center gap-1.5 rounded-full border border-[rgba(212,175,55,0.4)] bg-[rgba(212,175,55,0.12)] px-3 py-1 text-xs font-medium text-[#B8962E]",
  divider: "border-[#E5E7EB]",
  strong: "font-semibold text-[#111827]",
};

export function cn(...parts) {
  return parts.filter(Boolean).join(" ");
}
