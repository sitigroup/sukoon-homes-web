"use client";

import Link from "next/link";
import { myVerificationOrdersReturnPath } from "../verificationLegalNavigation";
import { trustVerificationLegalLinks, TV_REPORT_DISCLAIMER_TEXT } from "./trustVerificationLegalCopy";
import styles from "./trustVerificationPremium.module.css";

export default function VerificationMyOrdersLegalFooter({ lang = "en", className = "" }) {
  const returnTo = myVerificationOrdersReturnPath(lang);
  const links = trustVerificationLegalLinks(lang, returnTo);

  return (
    <div className={`${styles.myOrdersLegalCard} ${className}`.trim()}>
      <div className={styles.myOrdersLegalAccent} aria-hidden />
      <p className={styles.myOrdersLegalHeading}>Legal &amp; policies</p>
      <nav className={styles.myOrdersLegalChips} aria-label="Verification legal policies">
        {links.map((item) => (
          <Link key={item.href} href={item.href} className={styles.myOrdersLegalChip}>
            {item.label}
          </Link>
        ))}
      </nav>
      <p className={styles.myOrdersLegalDisclaimer} role="note">
        <strong>Disclaimer:</strong> {TV_REPORT_DISCLAIMER_TEXT}
      </p>
    </div>
  );
}
