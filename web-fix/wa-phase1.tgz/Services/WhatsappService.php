<?php

namespace App\Plugins\Whatsapp\Services;

use App\Plugins\Whatsapp\Jobs\SendWhatsappTemplateJob;
use Illuminate\Support\Facades\DB;

class WhatsappService
{
    public function notify(string $eventKey, array $contact, array $vars = []): void
    {
        try {
            SendWhatsappTemplateJob::dispatch($contact, $eventKey, $vars)->onQueue('whatsapp');
        } catch (\Throwable $e) {
            report($e);
            try {
                DB::table('wa_audit_log')->insert([
                    'event' => 'send_failed',
                    'entity_type' => 'event',
                    'meta_json' => json_encode([
                        'event_key' => $eventKey,
                        'contact' => $contact,
                        'error' => $e->getMessage(),
                    ]),
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            } catch (\Throwable) {
                // never block platform flow
            }
        }
    }
}

