<?php

return [
    'settings_title' => 'WhatsApp Settings',
    'templates_title' => 'WhatsApp Templates',
    'inbox_title' => 'WhatsApp Shared Inbox',
    'saved' => 'Saved successfully.',
    'test_connection' => 'Test Connection',
    'connection_ok' => 'Connection successful.',
    'connection_failed' => 'Connection failed.',
    'missing_settings' => 'WhatsApp settings are incomplete.',
    'sync_templates' => 'Sync Templates',
    'templates_synced' => 'Templates synced.',
    'search' => 'Search',
    'conversation' => 'Conversation',
    'select_conversation' => 'Select a conversation.',
    'reply_placeholder' => 'Type your reply',
    'window_expired' => '24-hour WhatsApp window expired. Use an approved template.',
    'send' => 'Send',
    'sent' => 'Message queued/sent.',
    'contact_missing' => 'Contact phone missing.',
    'save' => 'Save',
    'webhook_verified' => 'Webhook Verified',
    'webhook_pending' => 'Webhook Pending',
];

