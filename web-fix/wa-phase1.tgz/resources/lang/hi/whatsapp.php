<?php

return [
    'settings_title' => 'व्हाट्सऐप सेटिंग्स',
    'templates_title' => 'व्हाट्सऐप टेम्पलेट्स',
    'inbox_title' => 'व्हाट्सऐप साझा इनबॉक्स',
    'saved' => 'सफलतापूर्वक सहेजा गया।',
    'test_connection' => 'कनेक्शन जाँचें',
    'connection_ok' => 'कनेक्शन सफल।',
    'connection_failed' => 'कनेक्शन असफल।',
    'missing_settings' => 'व्हाट्सऐप सेटिंग्स अधूरी हैं।',
    'sync_templates' => 'टेम्पलेट सिंक करें',
    'templates_synced' => 'टेम्पलेट सिंक हो गए।',
    'search' => 'खोज',
    'conversation' => 'वार्तालाप',
    'select_conversation' => 'एक वार्तालाप चुनें।',
    'reply_placeholder' => 'उत्तर लिखें',
    'window_expired' => '24 घंटे की व्हाट्सऐप विंडो समाप्त हो गई है। स्वीकृत टेम्पलेट का उपयोग करें।',
    'send' => 'भेजें',
    'sent' => 'संदेश कतार/भेजा गया।',
    'contact_missing' => 'संपर्क फोन उपलब्ध नहीं है।',
    'save' => 'सहेजें',
    'webhook_verified' => 'वेबहुक सत्यापित',
    'webhook_pending' => 'वेबहुक लंबित',
];

