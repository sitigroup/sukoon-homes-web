@extends('layouts.main')

@section('title', __('whatsapp::whatsapp.inbox_title'))

@section('content')
<div class="container-fluid">
    @if(session('success')) <div class="alert alert-success">{{ session('success') }}</div> @endif
    @if(session('error')) <div class="alert alert-danger">{{ session('error') }}</div> @endif
    <div class="row g-3">
        <div class="col-12 col-lg-4">
            <div class="card">
                <div class="card-header" style="background:#1F2937;color:#fff;">{{ __('whatsapp::whatsapp.inbox_title') }}</div>
                <div class="card-body">
                    <form class="mb-3"><input class="form-control" name="search" value="{{ $search }}" placeholder="{{ __('whatsapp::whatsapp.search') }}"></form>
                    <div class="list-group">
                        @foreach($conversations as $c)
                            <a class="list-group-item list-group-item-action" href="{{ route('whatsapp.inbox.index', ['conversation_id'=>$c->id]) }}">
                                #{{ $c->id }} · {{ optional($c->contact)->phone }}<br>
                                <small>{{ $c->status }} · {{ $c->last_message_at }}</small>
                            </a>
                        @endforeach
                    </div>
                    {{ $conversations->links() }}
                </div>
            </div>
        </div>
        <div class="col-12 col-lg-8">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center" style="background:#1F2937;color:#fff;">
                    <span>{{ __('whatsapp::whatsapp.conversation') }}</span>
                    @if($conversation)
                    <form method="POST" action="{{ route('whatsapp.inbox.status', $conversation->id) }}" class="d-flex gap-2">@csrf
                        <select name="status" class="form-select form-select-sm">
                            @foreach(['open','pending','resolved'] as $status)
                            <option value="{{ $status }}" @selected($conversation->status === $status)>{{ ucfirst($status) }}</option>
                            @endforeach
                        </select>
                        <button class="btn btn-sm btn-light">Save</button>
                    </form>
                    @endif
                </div>
                <div class="card-body">
                    @if(!$conversation)
                        <p class="text-muted mb-0">{{ __('whatsapp::whatsapp.select_conversation') }}</p>
                    @else
                        <div class="border rounded p-2 mb-3" style="max-height:320px;overflow:auto;">
                            @foreach($conversation->messages()->latest()->take(50)->get()->reverse() as $m)
                                <div class="mb-2">
                                    <span class="badge {{ $m->direction === 'in' ? 'bg-secondary' : 'bg-dark' }}">{{ $m->direction }}</span>
                                    <span>{{ $m->body }}</span>
                                    <small class="text-muted">({{ $m->status }})</small>
                                </div>
                            @endforeach
                        </div>
                        @php $windowOpen = $conversation->conversation_window_expires_at && now()->lte($conversation->conversation_window_expires_at); @endphp
                        <form method="POST" action="{{ route('whatsapp.inbox.reply', $conversation->id) }}" class="row g-2">
                            @csrf
                            @if($windowOpen)
                                <div class="col-12"><textarea name="message" class="form-control" rows="3" placeholder="{{ __('whatsapp::whatsapp.reply_placeholder') }}"></textarea></div>
                            @else
                                <div class="col-12"><div class="alert alert-warning mb-2">{{ __('whatsapp::whatsapp.window_expired') }}</div></div>
                                <div class="col-12 col-md-8">
                                    <select name="template_id" class="form-select">
                                        <option value="">-- template --</option>
                                        @foreach($templates as $t)<option value="{{ $t->id }}">{{ $t->meta_template_name }} ({{ $t->language }})</option>@endforeach
                                    </select>
                                </div>
                            @endif
                            <div class="col-12"><button class="btn" style="background:#B89A4A;color:#fff;">{{ __('whatsapp::whatsapp.send') }}</button></div>
                        </form>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

