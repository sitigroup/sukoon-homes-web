@extends('layouts.main')

@section('title', __('whatsapp::whatsapp.templates_title'))

@section('content')
<div class="container-fluid">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center" style="background:#1F2937;color:#fff;">
            <h4 class="mb-0">{{ __('whatsapp::whatsapp.templates_title') }}</h4>
            <form method="POST" action="{{ route('whatsapp.templates.sync') }}">@csrf <button class="btn btn-sm btn-light">{{ __('whatsapp::whatsapp.sync_templates') }}</button></form>
        </div>
        <div class="card-body table-responsive">
            @if(session('success')) <div class="alert alert-success">{{ session('success') }}</div> @endif
            <table class="table table-striped">
                <thead><tr><th>Name</th><th>Lang</th><th>Category</th><th>Status</th><th>Internal Key</th><th>Enabled</th><th></th></tr></thead>
                <tbody>
                @foreach($templates as $t)
                    <tr>
                        <td>{{ $t->meta_template_name }}</td>
                        <td>{{ $t->language }}</td>
                        <td>{{ $t->category }}</td>
                        <td>{{ $t->status }}</td>
                        <td>
                            <form method="POST" action="{{ route('whatsapp.templates.map', $t->id) }}" class="d-flex gap-2">
                                @csrf
                                <input type="text" name="internal_key" value="{{ $t->internal_key }}" class="form-control form-control-sm">
                                <button class="btn btn-sm btn-dark">Save</button>
                            </form>
                        </td>
                        <td>{{ $t->enabled ? 'Yes' : 'No' }}</td>
                        <td>
                            <form method="POST" action="{{ route('whatsapp.templates.toggle', $t->id) }}">@csrf<button class="btn btn-sm" style="background:#B89A4A;color:#fff;">Toggle</button></form>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
            {{ $templates->links() }}
        </div>
    </div>
</div>
@endsection

