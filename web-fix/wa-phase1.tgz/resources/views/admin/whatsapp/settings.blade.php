@extends('layouts.main')

@section('title', __('whatsapp::whatsapp.settings_title'))

@section('content')
<div class="container-fluid">
    <div class="card">
        <div class="card-header" style="background:#1F2937;color:#fff;">
            <h4 class="mb-0">{{ __('whatsapp::whatsapp.settings_title') }}</h4>
        </div>
        <div class="card-body">
            @if(session('success')) <div class="alert alert-success">{{ session('success') }}</div> @endif
            @if(session('error')) <div class="alert alert-danger">{{ session('error') }}</div> @endif
            <form method="POST" action="{{ route('whatsapp.settings.store') }}" class="row g-3">
                @csrf
                <div class="col-md-4"><label class="form-label">Meta App ID</label><input name="meta_app_id" class="form-control" value="{{ old('meta_app_id', $settings->meta_app_id ?? '') }}"></div>
                <div class="col-md-4"><label class="form-label">WABA ID</label><input name="waba_id" class="form-control" value="{{ old('waba_id', $settings->waba_id ?? '') }}"></div>
                <div class="col-md-4"><label class="form-label">Phone Number ID</label><input name="phone_number_id" class="form-control" value="{{ old('phone_number_id', $settings->phone_number_id ?? '') }}"></div>
                <div class="col-md-6"><label class="form-label">Access Token</label><textarea name="access_token" class="form-control" rows="2">{{ old('access_token', $settings->access_token ?? '') }}</textarea></div>
                <div class="col-md-6"><label class="form-label">App Secret</label><textarea name="app_secret" class="form-control" rows="2">{{ old('app_secret', $settings->app_secret ?? '') }}</textarea></div>
                <div class="col-md-6"><label class="form-label">Verify Token</label><input name="verify_token" class="form-control" value="{{ old('verify_token', $settings->verify_token ?? '') }}"></div>
                <div class="col-md-6">
                    <label class="form-label">Environment</label>
                    <select name="environment_mode" class="form-select">
                        @foreach(['test_number','sandbox_waba','production_waba'] as $mode)
                            <option value="{{ $mode }}" @selected(old('environment_mode', $settings->environment_mode ?? 'test_number') === $mode)>{{ $mode }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-12 d-flex gap-2 flex-wrap">
                    <button class="btn btn-dark">{{ __('whatsapp::whatsapp.save') }}</button>
                </div>
            </form>
            <form method="POST" action="{{ route('whatsapp.settings.test') }}" class="mt-3">
                @csrf
                <button class="btn" style="background:#B89A4A;color:#fff;">{{ __('whatsapp::whatsapp.test_connection') }}</button>
                <span class="ms-2 badge {{ ($settings->webhook_verified ?? false) ? 'bg-success' : 'bg-secondary' }}">
                    {{ ($settings->webhook_verified ?? false) ? __('whatsapp::whatsapp.webhook_verified') : __('whatsapp::whatsapp.webhook_pending') }}
                </span>
            </form>
        </div>
    </div>
</div>
@endsection

