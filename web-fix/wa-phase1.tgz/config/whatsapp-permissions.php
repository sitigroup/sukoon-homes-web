<?php

return [
    'module' => 'whatsapp',
    'roles' => [
        'settings' => 'Manage WhatsApp settings',
        'templates' => 'Manage WhatsApp templates',
        'inbox' => 'Use shared WhatsApp inbox',
        'audit' => 'View WhatsApp audit logs',
    ],
];

