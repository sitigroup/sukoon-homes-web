<?php

use Illuminate\Support\Facades\Route;
use App\Plugins\Whatsapp\Http\Controllers\Admin\WhatsappSettingsController;
use App\Plugins\Whatsapp\Http\Controllers\Admin\WhatsappTemplateController;
use App\Plugins\Whatsapp\Http\Controllers\Admin\WhatsappInboxController;

Route::middleware(['auth:sanctum'])->group(function () {
    Route::prefix('whatsapp')->group(function () {
        Route::get('/settings', [WhatsappSettingsController::class, 'index'])
            ->middleware('permission:whatsapp_settings')
            ->name('whatsapp.settings.index');
        Route::post('/settings', [WhatsappSettingsController::class, 'store'])
            ->middleware('permission:whatsapp_settings')
            ->name('whatsapp.settings.store');
        Route::post('/settings/test-connection', [WhatsappSettingsController::class, 'testConnection'])
            ->middleware('permission:whatsapp_settings')
            ->name('whatsapp.settings.test');

        Route::get('/templates', [WhatsappTemplateController::class, 'index'])
            ->middleware('permission:whatsapp_templates')
            ->name('whatsapp.templates.index');
        Route::post('/templates/sync', [WhatsappTemplateController::class, 'sync'])
            ->middleware('permission:whatsapp_templates')
            ->name('whatsapp.templates.sync');
        Route::post('/templates/{template}/toggle', [WhatsappTemplateController::class, 'toggle'])
            ->middleware('permission:whatsapp_templates')
            ->name('whatsapp.templates.toggle');
        Route::post('/templates/{template}/map', [WhatsappTemplateController::class, 'mapInternalKey'])
            ->middleware('permission:whatsapp_templates')
            ->name('whatsapp.templates.map');

        Route::get('/inbox', [WhatsappInboxController::class, 'index'])
            ->middleware('permission:whatsapp_inbox')
            ->name('whatsapp.inbox.index');
        Route::post('/inbox/{conversation}/assign', [WhatsappInboxController::class, 'assign'])
            ->middleware('permission:whatsapp_inbox')
            ->name('whatsapp.inbox.assign');
        Route::post('/inbox/{conversation}/status', [WhatsappInboxController::class, 'setStatus'])
            ->middleware('permission:whatsapp_inbox')
            ->name('whatsapp.inbox.status');
        Route::post('/inbox/{conversation}/reply', [WhatsappInboxController::class, 'reply'])
            ->middleware('permission:whatsapp_inbox')
            ->name('whatsapp.inbox.reply');
    });
});

