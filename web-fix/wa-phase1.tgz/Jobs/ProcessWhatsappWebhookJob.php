<?php

namespace App\Plugins\Whatsapp\Jobs;

use App\Plugins\Whatsapp\Models\WaContact;
use App\Plugins\Whatsapp\Models\WaConversation;
use App\Plugins\Whatsapp\Models\WaMessage;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;

class ProcessWhatsappWebhookJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 3;
    public array $backoff = [5, 20, 60];

    public function __construct(public array $payload)
    {
        $this->queue = 'whatsapp';
    }

    public function handle(): void
    {
        DB::table('wa_audit_log')->insert([
            'event' => 'webhook_received',
            'entity_type' => 'webhook',
            'meta_json' => json_encode($this->payload),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $entries = $this->payload['entry'] ?? [];
        foreach ($entries as $entry) {
            foreach (($entry['changes'] ?? []) as $change) {
                $value = $change['value'] ?? [];

                foreach (($value['messages'] ?? []) as $incoming) {
                    $phone = $incoming['from'] ?? null;
                    if (! $phone) {
                        continue;
                    }
                    $contact = WaContact::query()->firstOrCreate(['phone' => $phone], ['opted_in' => true]);
                    $conversation = WaConversation::query()->firstOrCreate(['contact_id' => $contact->id]);

                    $lastInbound = Carbon::now();
                    $conversation->last_customer_message_at = $lastInbound;
                    $conversation->conversation_window_expires_at = $lastInbound->copy()->addHours(24);
                    $conversation->last_message_at = $lastInbound;
                    $conversation->save();

                    WaMessage::query()->create([
                        'conversation_id' => $conversation->id,
                        'contact_id' => $contact->id,
                        'wamid' => $incoming['id'] ?? null,
                        'direction' => 'in',
                        'type' => $incoming['type'] ?? 'text',
                        'body' => data_get($incoming, 'text.body'),
                        'status' => 'sent',
                    ]);
                }

                foreach (($value['statuses'] ?? []) as $statusEvent) {
                    $wamid = $statusEvent['id'] ?? null;
                    if (! $wamid) {
                        continue;
                    }
                    $status = $statusEvent['status'] ?? 'sent';
                    $msg = WaMessage::query()->where('wamid', $wamid)->first();
                    if ($msg) {
                        $msg->status = in_array($status, ['delivered', 'read', 'failed', 'sent']) ? $status : 'sent';
                        $msg->error_json = $status === 'failed' ? ($statusEvent['errors'] ?? null) : $msg->error_json;
                        $msg->save();
                    }

                    DB::table('wa_message_status_log')->insert([
                        'message_id' => $msg?->id,
                        'wamid' => $wamid,
                        'status' => $status,
                        'payload_json' => json_encode($statusEvent),
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);
                }
            }
        }
    }
}

