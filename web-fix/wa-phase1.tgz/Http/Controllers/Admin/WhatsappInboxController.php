<?php

namespace App\Plugins\Whatsapp\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Plugins\Whatsapp\Models\WaConversation;
use App\Plugins\Whatsapp\Models\WaMessage;
use App\Plugins\Whatsapp\Models\WaTemplate;
use App\Plugins\Whatsapp\Services\MetaGraphClient;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class WhatsappInboxController extends Controller
{
    public function index(Request $request): View
    {
        $search = (string) $request->query('search', '');
        $conversations = WaConversation::query()
            ->with('messages')
            ->when($search, fn ($q) => $q->whereHas('messages', fn ($mq) => $mq->where('body', 'like', "%{$search}%")))
            ->orderByDesc('last_message_at')
            ->paginate(30);

        $conversation = null;
        if ($request->filled('conversation_id')) {
            $conversation = WaConversation::query()->with('messages')->find($request->integer('conversation_id'));
        }

        $templates = WaTemplate::query()->where('enabled', true)->whereNotNull('internal_key')->get();
        return view('whatsapp::admin.whatsapp.inbox', compact('conversations', 'conversation', 'templates', 'search'));
    }

    public function assign(Request $request, WaConversation $conversation): RedirectResponse
    {
        $conversation->assigned_agent_id = $request->integer('assigned_agent_id') ?: null;
        $conversation->save();

        DB::table('wa_audit_log')->insert([
            'actor_id' => auth()->id(),
            'event' => 'assignment_change',
            'entity_type' => 'conversation',
            'entity_id' => $conversation->id,
            'meta_json' => json_encode(['assigned_agent_id' => $conversation->assigned_agent_id]),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return back()->with('success', __('whatsapp::whatsapp.saved'));
    }

    public function setStatus(Request $request, WaConversation $conversation): RedirectResponse
    {
        $request->validate(['status' => ['required', 'in:open,pending,resolved']]);
        $conversation->status = $request->string('status')->toString();
        $conversation->save();
        return back()->with('success', __('whatsapp::whatsapp.saved'));
    }

    public function reply(Request $request, WaConversation $conversation, MetaGraphClient $meta): RedirectResponse
    {
        $request->validate([
            'message' => ['nullable', 'string'],
            'template_id' => ['nullable', 'integer'],
        ]);
        $now = now();
        $windowOpen = $conversation->conversation_window_expires_at && $now->lessThanOrEqualTo($conversation->conversation_window_expires_at);
        $phone = optional($conversation->contact)->phone ?? null;

        if (! $phone) {
            return back()->with('error', __('whatsapp::whatsapp.contact_missing'));
        }

        if ($windowOpen && $request->filled('message')) {
            $result = $meta->sendText($phone, $request->string('message')->toString());
            $status = ($result['ok'] ?? false) ? 'sent' : 'failed';
            $msg = WaMessage::query()->create([
                'conversation_id' => $conversation->id,
                'contact_id' => $conversation->contact_id,
                'wamid' => data_get($result, 'json.messages.0.id'),
                'direction' => 'out',
                'type' => 'text',
                'body' => $request->string('message')->toString(),
                'status' => $status,
                'error_json' => $status === 'failed' ? ($result['json'] ?? ['error' => 'send_failed']) : null,
            ]);
            DB::table('wa_audit_log')->insert([
                'actor_id' => auth()->id(),
                'event' => 'manual_reply',
                'entity_type' => 'message',
                'entity_id' => $msg->id,
                'meta_json' => json_encode(['window_open' => true, 'status' => $status]),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            return back()->with('success', __('whatsapp::whatsapp.sent'));
        }

        if (! $windowOpen) {
            $template = WaTemplate::query()->find($request->integer('template_id'));
            if (! $template) {
                return back()->with('error', __('whatsapp::whatsapp.window_expired'));
            }
            $result = $meta->sendTemplate($phone, $template->meta_template_name, $template->language ?? 'en');
            $status = ($result['ok'] ?? false) ? 'sent' : 'failed';
            $msg = WaMessage::query()->create([
                'conversation_id' => $conversation->id,
                'contact_id' => $conversation->contact_id,
                'wamid' => data_get($result, 'json.messages.0.id'),
                'direction' => 'out',
                'type' => 'template',
                'template_key' => $template->internal_key,
                'body' => $template->meta_template_name,
                'status' => $status,
                'error_json' => $status === 'failed' ? ($result['json'] ?? ['error' => 'send_failed']) : null,
            ]);
            DB::table('wa_audit_log')->insert([
                'actor_id' => auth()->id(),
                'event' => 'template_fallback_reply',
                'entity_type' => 'message',
                'entity_id' => $msg->id,
                'meta_json' => json_encode(['window_open' => false, 'status' => $status]),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            return back()->with('success', __('whatsapp::whatsapp.sent'));
        }

        return back()->with('error', __('whatsapp::whatsapp.window_expired'));
    }
}

