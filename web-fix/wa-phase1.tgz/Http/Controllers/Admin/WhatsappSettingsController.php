<?php

namespace App\Plugins\Whatsapp\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Plugins\Whatsapp\Models\WaSetting;
use App\Plugins\Whatsapp\Services\MetaGraphClient;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class WhatsappSettingsController extends Controller
{
    public function index(): View
    {
        $settings = WaSetting::query()->latest('id')->first();
        return view('whatsapp::admin.whatsapp.settings', compact('settings'));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'meta_app_id' => ['nullable', 'string', 'max:255'],
            'waba_id' => ['nullable', 'string', 'max:255'],
            'phone_number_id' => ['nullable', 'string', 'max:255'],
            'access_token' => ['nullable', 'string'],
            'verify_token' => ['nullable', 'string', 'max:255'],
            'app_secret' => ['nullable', 'string'],
            'environment_mode' => ['required', 'in:test_number,sandbox_waba,production_waba'],
        ]);

        $settings = WaSetting::query()->latest('id')->first() ?? new WaSetting();
        $settings->fill($validated);
        $settings->save();

        return back()->with('success', __('whatsapp::whatsapp.saved'));
    }

    public function testConnection(MetaGraphClient $meta): RedirectResponse
    {
        $result = $meta->testConnection();
        $settings = WaSetting::query()->latest('id')->first();
        if ($settings) {
            $settings->webhook_verified = (bool) ($result['ok'] ?? false);
            $settings->last_tested_at = now();
            $settings->save();
        }

        if ($result['ok'] ?? false) {
            return back()->with('success', __('whatsapp::whatsapp.connection_ok'));
        }
        return back()->with('error', __('whatsapp::whatsapp.connection_failed'));
    }
}

