<?php

namespace App\Plugins\Whatsapp\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Plugins\Whatsapp\Models\WaTemplate;
use App\Plugins\Whatsapp\Services\MetaGraphClient;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class WhatsappTemplateController extends Controller
{
    public function index(): View
    {
        $templates = WaTemplate::query()->orderBy('meta_template_name')->paginate(40);
        return view('whatsapp::admin.whatsapp.templates', compact('templates'));
    }

    public function sync(MetaGraphClient $meta): RedirectResponse
    {
        $items = $meta->fetchTemplates();
        foreach ($items as $item) {
            $category = (string) ($item['category'] ?? '');
            if (! in_array(strtolower($category), ['utility', 'authentication'], true)) {
                continue;
            }
            $lang = strtolower((string) data_get($item, 'language', 'en'));
            if (! in_array($lang, ['en', 'hi'], true)) {
                continue;
            }

            WaTemplate::query()->updateOrCreate(
                [
                    'meta_template_name' => (string) ($item['name'] ?? ''),
                    'language' => $lang,
                ],
                [
                    'category' => $category,
                    'status' => (string) ($item['status'] ?? ''),
                    'components_json' => $item['components'] ?? [],
                ]
            );
        }
        return back()->with('success', __('whatsapp::whatsapp.templates_synced'));
    }

    public function toggle(WaTemplate $template): RedirectResponse
    {
        $template->enabled = ! $template->enabled;
        $template->save();
        return back()->with('success', __('whatsapp::whatsapp.saved'));
    }

    public function mapInternalKey(Request $request, WaTemplate $template): RedirectResponse
    {
        $request->validate(['internal_key' => ['nullable', 'string', 'max:255']]);
        $template->internal_key = $request->string('internal_key')->toString();
        $template->save();
        return back()->with('success', __('whatsapp::whatsapp.saved'));
    }
}

