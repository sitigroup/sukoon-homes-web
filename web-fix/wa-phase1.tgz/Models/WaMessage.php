<?php

namespace App\Plugins\Whatsapp\Models;

use Illuminate\Database\Eloquent\Model;

class WaMessage extends Model
{
    protected $table = 'wa_messages';

    protected $guarded = [];

    protected $casts = [
        'error_json' => 'array',
    ];
}

