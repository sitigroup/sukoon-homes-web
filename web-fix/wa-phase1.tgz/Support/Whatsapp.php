<?php

namespace App\Plugins\Whatsapp\Support;

use App\Plugins\Whatsapp\Services\WhatsappService;

class Whatsapp
{
    public static function notify(string $eventKey, array $contact, array $vars = []): void
    {
        try {
            app(WhatsappService::class)->notify($eventKey, $contact, $vars);
        } catch (\Throwable $e) {
            report($e);
        }
    }
}

