"use client";

import styles from "./trustVerificationPremium.module.css";

export default function VerificationEmptyState({ title, description, className = "" }) {
  return (
    <div className={`${styles.emptyState} ${className}`.trim()}>
      <p className={styles.emptyTitle}>{title}</p>
      {description && <p className={styles.emptyDesc}>{description}</p>}
    </div>
  );
}
