/**
 * Trust Verification — legal copy (UI only, single source of truth).
 */

export const TV_CONSENT_TEXT =
  "I confirm that I have permission to request this verification and the information/documents provided are correct.";

export const TV_DATA_USAGE_TEXT =
  "Your documents are used only for verification. Sukoon Homes stores them securely and may share them with verification partners only for this request.";

export const TV_REPORT_DISCLAIMER_TEXT =
  "Verification reports are informational and do not guarantee future conduct, legal status, or transaction safety.";

export const TV_ADMIN_DOCUMENT_REMINDER =
  "Handle personal documents carefully. Download only when required.";

/** @param {string} [lang] */
export function trustVerificationLegalLinks(lang = "en") {
  const q = lang ? `?lang=${lang}` : "";
  return [
    { label: "Privacy Policy", href: `/verification-privacy${q}` },
    { label: "Verification Terms", href: `/verification-terms${q}` },
    { label: "Refund Policy", href: `/verification-refund-policy${q}` },
  ];
}
