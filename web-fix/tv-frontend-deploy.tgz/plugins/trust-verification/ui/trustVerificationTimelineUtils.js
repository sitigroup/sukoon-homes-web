/**
 * Maps API order shape → premium timeline steps (UI-only, no API changes).
 */

export const TIMELINE_STEP_IDS = [
  "submitted",
  "payment",
  "verification",
  "review",
  "report",
];

export const TIMELINE_STEP_LABELS = {
  submitted: "Submitted",
  payment: "Payment",
  verification: "Verification running",
  review: "Analyst review",
  report: "Report ready",
};

export function isOrderPaid(order) {
  return ["paid", "waived"].includes(String(order?.payment_status || "pending").toLowerCase());
}

/**
 * Step label reflects actual payment state (avoids "Payment Confirmed" while still unpaid).
 */
export function getTimelineStepLabel(stepId, order) {
  const paid = isOrderPaid(order);
  const status = order?.status || "submitted";

  switch (stepId) {
    case "submitted":
      return TIMELINE_STEP_LABELS.submitted;
    case "payment":
      if (!paid) return "Payment pending";
      return "Payment confirmed";
    case "verification":
      if (status === "completed") return TIMELINE_STEP_LABELS.verification;
      return paid ? TIMELINE_STEP_LABELS.verification : "Verification";
    case "review":
      return TIMELINE_STEP_LABELS.review;
    case "report":
      return TIMELINE_STEP_LABELS.report;
    default:
      return stepId;
  }
}

/**
 * @param {object} order
 * @returns {Array<{id:string,label:string,status:'complete'|'current'|'upcoming'}>}
 */
export function buildVerificationTimeline(order) {
  return buildVerificationTimelineSimple(order);
}

/** Deterministic timeline — payment step only completes when payment_status is paid/waived */
export function buildVerificationTimelineSimple(order) {
  const steps = TIMELINE_STEP_IDS.map((id) => ({
    id,
    label: getTimelineStepLabel(id, order),
    status: "upcoming",
  }));

  if (!order) {
    steps[0].status = "current";
    return steps;
  }

  if (order.status === "cancelled") {
    steps[0].status = "complete";
    return steps;
  }

  const status = order.status || "submitted";
  const paid = isOrderPaid(order);
  const hasReport = !!order.report?.download_available;

  steps[0].status = "complete";

  if (!paid) {
    steps[1].status = "current";
    return steps;
  }

  steps[1].status = "complete";

  if (hasReport) {
    steps.forEach((s) => {
      s.status = "complete";
    });
    return steps;
  }

  if (status === "submitted") {
    steps[2].status = "current";
    return steps;
  }

  if (status === "in_progress") {
    steps[2].status = "current";
    steps[3].status = "upcoming";
    return steps;
  }

  if (status === "completed") {
    steps[2].status = "complete";
    steps[3].status = "complete";
    steps[4].status = "current";
    return steps;
  }

  steps[2].status = "current";
  return steps;
}
