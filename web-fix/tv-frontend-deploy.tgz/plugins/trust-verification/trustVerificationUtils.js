export const TRUST_VERIFICATION_DEFAULT_CITY = {
  slug: "barmer",
  label: "Barmer",
};

/** @deprecated use resolveCity() */
export const TRUST_VERIFICATION_CITY = TRUST_VERIFICATION_DEFAULT_CITY;

export const slugifyCity = (name) =>
  String(name || "")
    .trim()
    .toLowerCase()
    .replace(/[^\w\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-");

export const humanizeSlug = (slug) =>
  String(slug || "")
    .split("-")
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");

/**
 * @param {string} citySlugRaw
 * @param {Array<{slug:string,label:string}>} knownCities from API
 */
export const resolveCity = (citySlugRaw = "", knownCities = []) => {
  const raw = slugifyCity(citySlugRaw);

  if (knownCities.length) {
    const match = knownCities.find((c) => c.slug === raw);
    if (match) {
      return { ...match, unknown: false };
    }
    if (!raw) {
      return { ...knownCities[0], unknown: false };
    }
    return { slug: raw, label: humanizeSlug(raw), unknown: true };
  }

  if (raw === TRUST_VERIFICATION_DEFAULT_CITY.slug) {
    return { ...TRUST_VERIFICATION_DEFAULT_CITY, unknown: false };
  }
  if (raw) {
    return { slug: raw, label: humanizeSlug(raw), unknown: false };
  }
  return { ...TRUST_VERIFICATION_DEFAULT_CITY, unknown: false };
};

export const resolvePropertyCitySlug = (property) => {
  const name =
    property?.area_listing?.city_name ||
    property?.city_name ||
    property?.city ||
  "";
  return slugifyCity(name);
};

export const verificationWizardPath = (orderType, citySlug, lang = "en") => {
  const q = lang ? `?lang=${lang}` : "";
  return `/${orderType}-verification-in-${citySlug}${q}`;
};

export const formatInr = (amount, symbol = "₹") =>
  `${symbol}${Number(amount || 0).toLocaleString("en-IN")}`;

export const verificationCopy = {
  tenant: {
    title: (city) => `Online Tenant Verification in ${city}`,
    lead: "Ensure safety before handing over keys — background checks with a detailed PDF report delivered by email.",
    subjectLabel: "Tenant",
    cta: "Submit tenant verification request",
  },
  owner: {
    title: (city) => `Online Owner Verification in ${city}`,
    lead: "Confirm the landlord is genuine before you pay token or rent — ownership and identity checks with a PDF report.",
    subjectLabel: "Owner / landlord",
    cta: "Submit owner verification request",
  },
};
