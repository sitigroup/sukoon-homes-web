"use client";

import Link from "next/link";
import { useAuthStatus } from "@/hooks/useAuthStatus";

export default function MyVerificationOrdersLink({ lang = "en", className = "" }) {
  const isLoggedIn = useAuthStatus();
  if (!isLoggedIn) return null;

  const href = `/my-verification-orders?lang=${lang || "en"}`;

  if (className) {
    return (
      <Link href={href} className={className}>
        My verification orders
      </Link>
    );
  }

  return (
    <Link
      href={href}
      className="inline-flex items-center rounded-lg border brandBorder px-4 py-2 text-sm font-medium brandColor bg-white hover:brandBgLight"
    >
      My verification orders
    </Link>
  );
}
