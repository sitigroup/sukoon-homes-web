import api from "@/api/axiosMiddleware";

const BASE = "trust-verification";

export const getTrustVerificationPublicContent = async () => {
  const res = await api.get(`${BASE}/content/public`);
  return res.data;
};

export const getTrustVerificationCities = async () => {
  const res = await api.get(`${BASE}/cities`);
  return res.data;
};

export const getTrustVerificationPackages = async ({ type = "tenant", city = "barmer" } = {}) => {
  const res = await api.get(`${BASE}/packages`, { params: { type, city } });
  return res.data;
};

export const getTrustVerificationPaymentSettings = async () => {
  const res = await api.get(`${BASE}/payment-settings`);
  return res.data;
};

export const getTrustVerificationOrders = async () => {
  const res = await api.get(`${BASE}/orders`);
  return res.data;
};

export const getTrustVerificationOrder = async (orderId) => {
  const res = await api.get(`${BASE}/orders/${orderId}`);
  return res.data;
};

export const submitTrustVerificationOrder = async (payload) => {
  const res = await api.post(`${BASE}/orders`, payload);
  return res.data;
};

export const createTrustVerificationPaymentIntent = async (orderId, payload = {}) => {
  const res = await api.post(`${BASE}/orders/${orderId}/payment-intent`, {
    payment_method: "cashfree",
    platform_type: "web",
    ...payload,
  });
  return res.data;
};

export const confirmTrustVerificationPayment = async (orderId, paymentTransactionId) => {
  const res = await api.post(`${BASE}/orders/${orderId}/confirm-payment`, {
    payment_transaction_id: paymentTransactionId,
  });
  return res.data;
};

export const downloadTrustVerificationReport = async (orderId) => {
  const res = await api.get(`${BASE}/orders/${orderId}/report/download`, {
    responseType: "blob",
  });
  const blob = res.data;
  const type = String(blob?.type || "");

  if (type.includes("json") || (blob?.size ?? 0) < 500) {
    let message = "Report is not available yet.";
    try {
      const text = await blob.text();
      const parsed = JSON.parse(text);
      message = parsed?.message || message;
    } catch {
      message =
        "Downloaded file is not a valid PDF. Ask admin to upload a full report for this order.";
    }
    throw new Error(message);
  }

  const header = await blob.slice(0, 5).text();
  if (!header.startsWith("%PDF")) {
    throw new Error(
      "This report file is invalid or was a test placeholder. A real PDF must be uploaded in admin."
    );
  }

  return blob;
};

export const cancelTrustVerificationOrder = async (orderId) => {
  const res = await api.post(`${BASE}/orders/${orderId}/cancel`);
  return res.data;
};

export const uploadTrustVerificationDocument = async (orderId, docType, file) => {
  const form = new FormData();
  form.append("doc_type", docType);
  form.append("file", file);
  const res = await api.post(`${BASE}/orders/${orderId}/documents`, form, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return res.data;
};
