Area Listing Plugin — working backup
Created: 2026-05-23T05:10:36Z
Status: Area/sub-area flows verified working — do not modify without explicit approval

  echo Contents:
  echo  admin-homes/app/Plugins/AreaListing/ Laravel plugin (controllers, models, services, views, routes)
  echo  admin-homes/database/migrations/ area_listing_* migrations
  echo  frontend/area-listing/ Next.js plugin (selector, API, permissions)
  echo 
Restore backend plugin:
cp -a admin-homes/app/Plugins/AreaListing /www/wwwroot/admin-homes/app/Plugins/
Restore frontend:
cp -a frontend/area-listing/* /www/wwwroot/homes.sukoon.group/src/plugins/area-listing/
cd /www/wwwroot/homes.sukoon.group
cd /www/wwwroot/admin-homes
