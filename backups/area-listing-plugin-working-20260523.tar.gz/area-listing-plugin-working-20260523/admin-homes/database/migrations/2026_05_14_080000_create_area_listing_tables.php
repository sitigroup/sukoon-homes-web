<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('area_listing_areas')) {
            Schema::create('area_listing_areas', function (Blueprint $table) {
                $table->id();
                $table->string('city')->nullable()->index();
                $table->string('state')->nullable()->index();
                $table->string('country')->nullable()->index();
                $table->string('name')->index();
                $table->string('slug')->index();
                $table->decimal('center_lat', 10, 7)->nullable();
                $table->decimal('center_lng', 10, 7)->nullable();
                $table->unsignedInteger('radius_meters')->nullable();
                $table->json('polygon_json')->nullable();
                $table->unsignedInteger('sort_order')->default(0);
                $table->boolean('status')->default(true)->index();
                $table->string('seo_title')->nullable();
                $table->text('seo_description')->nullable();
                $table->timestamps();
                $table->unique(['city', 'state', 'name'], 'area_listing_areas_city_state_name_unique');
            });
        }

        if (! Schema::hasTable('area_listing_sub_areas')) {
            Schema::create('area_listing_sub_areas', function (Blueprint $table) {
                $table->id();
                $table->foreignId('area_id')->constrained('area_listing_areas')->cascadeOnDelete();
                $table->string('name')->index();
                $table->string('slug')->index();
                $table->decimal('center_lat', 10, 7)->nullable();
                $table->decimal('center_lng', 10, 7)->nullable();
                $table->unsignedInteger('radius_meters')->nullable();
                $table->json('polygon_json')->nullable();
                $table->unsignedInteger('sort_order')->default(0);
                $table->boolean('status')->default(true)->index();
                $table->string('seo_title')->nullable();
                $table->text('seo_description')->nullable();
                $table->timestamps();
                $table->unique(['area_id', 'slug'], 'area_listing_sub_areas_area_slug_unique');
            });
        }

        if (! Schema::hasTable('area_listing_property_locations')) {
            Schema::create('area_listing_property_locations', function (Blueprint $table) {
                $table->id();
                $table->foreignId('property_id')->unique()->constrained('propertys')->cascadeOnDelete();
                $table->foreignId('area_id')->nullable()->constrained('area_listing_areas')->nullOnDelete();
                $table->foreignId('sub_area_id')->nullable()->constrained('area_listing_sub_areas')->nullOnDelete();
                $table->string('detected_area_name')->nullable();
                $table->string('detected_sub_area_name')->nullable();
                $table->string('source')->default('manual');
                $table->timestamps();
                $table->index(['area_id', 'sub_area_id']);
            });
        }

        if (! Schema::hasTable('area_listing_project_locations')) {
            Schema::create('area_listing_project_locations', function (Blueprint $table) {
                $table->id();
                $table->foreignId('project_id')->unique()->constrained('projects')->cascadeOnDelete();
                $table->foreignId('area_id')->nullable()->constrained('area_listing_areas')->nullOnDelete();
                $table->foreignId('sub_area_id')->nullable()->constrained('area_listing_sub_areas')->nullOnDelete();
                $table->string('detected_area_name')->nullable();
                $table->string('detected_sub_area_name')->nullable();
                $table->string('source')->default('manual');
                $table->timestamps();
                $table->index(['area_id', 'sub_area_id']);
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('area_listing_project_locations');
        Schema::dropIfExists('area_listing_property_locations');
        Schema::dropIfExists('area_listing_sub_areas');
        Schema::dropIfExists('area_listing_areas');
    }
};
