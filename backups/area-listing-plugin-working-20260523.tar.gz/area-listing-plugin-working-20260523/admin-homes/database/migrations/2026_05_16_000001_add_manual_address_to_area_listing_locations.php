<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        foreach (['area_listing_property_locations', 'area_listing_project_locations'] as $tableName) {
            if (Schema::hasTable($tableName) && ! Schema::hasColumn($tableName, 'manual_address')) {
                Schema::table($tableName, function (Blueprint $table) {
                    $table->text('manual_address')->nullable()->after('full_address');
                });
            }
        }
    }

    public function down(): void
    {
        foreach (['area_listing_property_locations', 'area_listing_project_locations'] as $tableName) {
            if (Schema::hasTable($tableName) && Schema::hasColumn($tableName, 'manual_address')) {
                Schema::table($tableName, function (Blueprint $table) {
                    $table->dropColumn('manual_address');
                });
            }
        }
    }
};