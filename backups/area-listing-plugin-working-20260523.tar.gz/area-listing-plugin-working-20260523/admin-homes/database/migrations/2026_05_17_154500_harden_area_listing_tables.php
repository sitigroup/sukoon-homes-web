<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('area_listing_areas', function (Blueprint $table) {
            if (! Schema::hasColumn('area_listing_areas', 'normalized_name')) {
                $table->string('normalized_name')->nullable()->after('name');
            }
            if (! Schema::hasColumn('area_listing_areas', 'workflow_status')) {
                $table->string('workflow_status', 20)->default('active')->index()->after('status');
            }
            if (! Schema::hasColumn('area_listing_areas', 'archived_at')) {
                $table->timestamp('archived_at')->nullable()->after('workflow_status');
            }
        });

        Schema::table('area_listing_sub_areas', function (Blueprint $table) {
            if (! Schema::hasColumn('area_listing_sub_areas', 'normalized_name')) {
                $table->string('normalized_name')->nullable()->after('name');
            }
            if (! Schema::hasColumn('area_listing_sub_areas', 'workflow_status')) {
                $table->string('workflow_status', 20)->default('active')->index()->after('status');
            }
            if (! Schema::hasColumn('area_listing_sub_areas', 'archived_at')) {
                $table->timestamp('archived_at')->nullable()->after('workflow_status');
            }
        });

        if (! Schema::hasTable('area_listing_merge_audits')) {
            Schema::create('area_listing_merge_audits', function (Blueprint $table) {
                $table->id();
                $table->string('entity_type', 20);
                $table->unsignedBigInteger('old_id');
                $table->unsignedBigInteger('new_id');
                $table->unsignedInteger('affected_properties')->default(0);
                $table->unsignedInteger('affected_projects')->default(0);
                $table->unsignedBigInteger('admin_user_id')->nullable();
                $table->json('snapshot')->nullable();
                $table->timestamps();
                $table->index(['entity_type', 'old_id', 'new_id'], 'area_listing_merge_audit_lookup');
            });
        }

        if (! Schema::hasTable('area_listing_suggestions')) {
            Schema::create('area_listing_suggestions', function (Blueprint $table) {
                $table->id();
                $table->string('type', 20);
                $table->unsignedBigInteger('area_id')->nullable();
                $table->string('name');
                $table->string('normalized_name');
                $table->string('slug');
                $table->string('city')->nullable();
                $table->string('state')->nullable();
                $table->string('country')->nullable();
                $table->unsignedBigInteger('suggested_by')->nullable();
                $table->string('status', 20)->default('pending')->index();
                $table->text('review_note')->nullable();
                $table->unsignedBigInteger('reviewed_by')->nullable();
                $table->timestamp('reviewed_at')->nullable();
                $table->timestamps();
                $table->index(['type', 'status'], 'area_listing_suggestions_type_status');
            });
        }

        foreach (['area_listing_property_locations', 'area_listing_project_locations'] as $tableName) {
            Schema::table($tableName, function (Blueprint $table) use ($tableName) {
                if (! Schema::hasColumn($tableName, 'area_name')) {
                    $table->string('area_name')->nullable()->after('sub_area_id');
                }
                if (! Schema::hasColumn($tableName, 'sub_area_name')) {
                    $table->string('sub_area_name')->nullable()->after('area_name');
                }
                if (! Schema::hasColumn($tableName, 'display_address')) {
                    $table->string('display_address')->nullable()->after('manual_address');
                }
            });
        }

        $this->normalizeExistingRows();
        $this->createUniqueIndexIfMissing('area_listing_areas', 'area_listing_areas_city_state_country_normalized_unique', ['city', 'state', 'country', 'normalized_name']);
        $this->createUniqueIndexIfMissing('area_listing_sub_areas', 'area_listing_sub_areas_area_normalized_unique', ['area_id', 'normalized_name']);
    }

    public function down(): void
    {
        Schema::dropIfExists('area_listing_suggestions');
        Schema::dropIfExists('area_listing_merge_audits');
    }

    private function normalizeExistingRows(): void
    {
        DB::table('area_listing_areas')->orderBy('id')->get()->each(function ($area) {
            DB::table('area_listing_areas')->where('id', $area->id)->update([
                'name' => $this->titleName($area->name),
                'city' => $this->titleName($area->city),
                'state' => $this->titleName($area->state),
                'country' => $this->titleName($area->country ?: 'India'),
                'normalized_name' => $this->normalizedName($area->name),
                'slug' => Str::slug($area->name),
                'workflow_status' => $area->status ? 'active' : 'archived',
                'archived_at' => $area->status ? null : now(),
            ]);
        });

        DB::table('area_listing_sub_areas')->orderBy('id')->get()->each(function ($subArea) {
            DB::table('area_listing_sub_areas')->where('id', $subArea->id)->update([
                'name' => $this->titleName($subArea->name),
                'normalized_name' => $this->normalizedName($subArea->name),
                'slug' => Str::slug($subArea->name),
                'workflow_status' => $subArea->status ? 'active' : 'archived',
                'archived_at' => $subArea->status ? null : now(),
            ]);
        });
    }

    private function createUniqueIndexIfMissing(string $table, string $indexName, array $columns): void
    {
        $exists = DB::table('information_schema.statistics')
            ->where('table_schema', DB::getDatabaseName())
            ->where('table_name', $table)
            ->where('index_name', $indexName)
            ->exists();

        if ($exists) {
            return;
        }

        $columnSql = collect($columns)->map(fn ($column) => "`{$column}`")->implode(', ');
        DB::statement("ALTER TABLE `{$table}` ADD UNIQUE `{$indexName}` ({$columnSql})");
    }

    private function titleName($value): string
    {
        $value = trim(preg_replace('/\s+/', ' ', (string) $value));
        return $value === '' ? '' : Str::title(Str::lower($value));
    }

    private function normalizedName($value): string
    {
        return Str::of((string) $value)->lower()->squish()->value();
    }
};
